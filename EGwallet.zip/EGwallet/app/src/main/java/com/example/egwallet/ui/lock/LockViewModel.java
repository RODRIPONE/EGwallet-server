package com.example.egwallet.ui.lock;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.repository.UserRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.PinHasher;

import java.util.Date;

// Gere le cas d'usage "S'authentifier (PIN/Biometrie)", y compris la creation de compte
// au premier lancement. Toutes les lectures Room passent par un thread de fond (jamais
// d'appel *Sync() direct depuis le thread principal).
public class LockViewModel extends AndroidViewModel {

    private final UserRepository userRepository;

    private final MutableLiveData<Event<Boolean>> unlocked = new MutableLiveData<>();
    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Boolean> hasAccount = new MutableLiveData<>();
    private final MutableLiveData<Boolean> biometricAvailable = new MutableLiveData<>();

    public LockViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    public LiveData<Event<Boolean>> getUnlocked() {
        return unlocked;
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    // A observer depuis LockActivity.onCreate() pour choisir entre l'ecran de creation
    // de compte (premier lancement) et l'ecran de saisie du PIN.
    public LiveData<Boolean> getHasAccount() {
        AppExecutors.getInstance().diskIO().execute(() ->
                hasAccount.postValue(userRepository.hasAccountSync()));
        return hasAccount;
    }

    public LiveData<Boolean> getBiometricAvailable() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            User user = userRepository.getCurrentUserSync();
            biometricAvailable.postValue(user != null && user.isBiometricEnabled());
        });
        return biometricAvailable;
    }

    // Premier lancement : creation du compte local avec le PIN choisi
    public void createAccount(String username, String rawPin) {
        String hash = PinHasher.hash(rawPin);
        User user = new User(username, hash, false, new Date());
        userRepository.insert(user); // deja asynchrone en interne
        unlocked.setValue(new Event<>(true));
    }

    // Verifie le PIN saisi contre le hash stocke
    public void verifyPin(String rawPin) {
        AppExecutors.getInstance().diskIO().execute(() -> {
            User user = userRepository.getCurrentUserSync();
            if (user == null) {
                errorMessage.postValue(new Event<>("Aucun compte local. Créez-en un d'abord."));
                return;
            }
            if (PinHasher.matches(rawPin, user.getPinCodeHash())) {
                unlocked.postValue(new Event<>(true));
            } else {
                errorMessage.postValue(new Event<>("Code PIN incorrect"));
            }
        });
    }

    // Appelee apres succes du BiometricPrompt (declenche depuis LockActivity en Phase 3)
    public void onBiometricSuccess() {
        unlocked.setValue(new Event<>(true));
    }
}
