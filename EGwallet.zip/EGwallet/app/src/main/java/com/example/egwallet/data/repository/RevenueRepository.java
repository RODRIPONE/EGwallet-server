package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.RevenueDao;
import com.example.egwallet.data.entity.Revenue;

import java.util.Date;
import java.util.List;

public class RevenueRepository {

    private final RevenueDao revenueDao;

    public RevenueRepository(Application application) {
        revenueDao = AppDatabase.getInstance(application).revenueDao();
    }

    public LiveData<List<Revenue>> getAll() {
        return revenueDao.getAll();
    }

    public LiveData<List<Revenue>> getBetween(Date start, Date end) {
        return revenueDao.getBetween(start, end);
    }

    public LiveData<Double> getTotalBetween(Date start, Date end) {
        return revenueDao.getTotalBetween(start, end);
    }

    // Version synchrone : a appeler uniquement depuis un thread de fond (AppExecutors)
    public double getTotalBetweenSync(Date start, Date end) {
        return revenueDao.getTotalBetweenSync(start, end);
    }

    public void insert(Revenue revenue) {
        AppExecutors.getInstance().diskIO().execute(() -> revenueDao.insert(revenue));
    }

    public void update(Revenue revenue) {
        AppExecutors.getInstance().diskIO().execute(() -> revenueDao.update(revenue));
    }

    public void delete(Revenue revenue) {
        AppExecutors.getInstance().diskIO().execute(() -> revenueDao.delete(revenue));
    }
}
