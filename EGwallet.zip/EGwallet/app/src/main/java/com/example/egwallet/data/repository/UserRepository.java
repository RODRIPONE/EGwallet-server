package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.UserDao;
import com.example.egwallet.data.entity.User;

public class UserRepository {

    private final UserDao userDao;

    public UserRepository(Application application) {
        userDao = AppDatabase.getInstance(application).userDao();
    }

    public LiveData<User> getCurrentUser() {
        return userDao.getCurrentUser();
    }

    public User getCurrentUserSync() {
        return userDao.getCurrentUserSync();
    }

    public boolean hasAccountSync() {
        return userDao.countUsers() > 0;
    }

    public void insert(User user) {
        AppExecutors.getInstance().diskIO().execute(() -> userDao.insert(user));
    }

    public void update(User user) {
        AppExecutors.getInstance().diskIO().execute(() -> userDao.update(user));
    }
}
