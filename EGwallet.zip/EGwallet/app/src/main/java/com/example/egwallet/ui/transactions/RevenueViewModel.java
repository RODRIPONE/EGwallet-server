package com.example.egwallet.ui.transactions;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.data.repository.RevenueRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

// Cas d'usage "Ajouter/Modifier/Supprimer un revenu", "Consulter historique des revenus"
public class RevenueViewModel extends AndroidViewModel {

    private final RevenueRepository revenueRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public RevenueViewModel(@NonNull Application application) {
        super(application);
        revenueRepository = new RevenueRepository(application);
    }

    public LiveData<List<Revenue>> getAll() {
        return revenueRepository.getAll();
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    public void addRevenue(String rawAmount, String source, String category, Date date, String notes) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        String sourceError = ValidationUtils.validateText(source, "La source");
        if (sourceError != null) {
            errorMessage.setValue(new Event<>(sourceError));
            return;
        }
        String dateError = ValidationUtils.validatePastOrTodayDate(date);
        if (dateError != null) {
            errorMessage.setValue(new Event<>(dateError));
            return;
        }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        revenueRepository.insert(new Revenue(amount, source.trim(), category, date, notes));
        saved.setValue(new Event<>(true));
    }

    public void updateRevenue(Revenue revenue) {
        revenueRepository.update(revenue);
    }

    public void deleteRevenue(Revenue revenue) {
        revenueRepository.delete(revenue);
    }
}
