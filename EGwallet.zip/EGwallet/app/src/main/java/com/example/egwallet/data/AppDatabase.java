package com.example.egwallet.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.dao.DebtPaymentDao;
import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.data.dao.DuePaymentDao;
import com.example.egwallet.data.dao.ExpenseDao;
import com.example.egwallet.data.dao.FixedExpenseDao;
import com.example.egwallet.data.dao.GoalDao;
import com.example.egwallet.data.dao.RevenueDao;
import com.example.egwallet.data.dao.SyncQueueDao;
import com.example.egwallet.data.dao.UserDao;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.entity.Due;
import com.example.egwallet.data.entity.DuePayment;
import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.entity.FixedExpense;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.data.entity.SyncQueueEvent;
import com.example.egwallet.data.entity.User;

@Database(
        entities = {
                User.class,
                Revenue.class,
                Expense.class,
                FixedExpense.class,
                Debt.class,
                DebtPayment.class,
                Due.class,
                DuePayment.class,
                Goal.class,
                SyncQueueEvent.class
        },
        version = 1,
        exportSchema = false
)
@TypeConverters({Converters.class})
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public abstract UserDao userDao();
    public abstract RevenueDao revenueDao();
    public abstract ExpenseDao expenseDao();
    public abstract FixedExpenseDao fixedExpenseDao();
    public abstract DebtDao debtDao();
    public abstract DebtPaymentDao debtPaymentDao();
    public abstract DueDao dueDao();
    public abstract DuePaymentDao duePaymentDao();
    public abstract GoalDao goalDao();
    public abstract SyncQueueDao syncQueueDao();

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                            context.getApplicationContext(),
                            AppDatabase.class,
                            "egwallet.db"
                    ).build();
                }
            }
        }
        return INSTANCE;
    }
}
