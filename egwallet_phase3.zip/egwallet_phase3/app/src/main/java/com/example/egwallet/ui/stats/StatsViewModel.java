package com.example.egwallet.ui.stats;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.ExpenseDao;
import com.example.egwallet.data.model.Report;
import com.example.egwallet.data.repository.ExpenseRepository;
import com.example.egwallet.data.repository.RevenueRepository;
import com.example.egwallet.service.ReportService;
import com.example.egwallet.util.DateUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

// Alimente StatsFragment : filtres Ce mois/6 mois/Annee (cartes + repartition + bilan),
// et une serie d'evolution mensuelle fixe sur 7 mois pour le line chart (independante du
// filtre, comme sur la maquette Figma ou le graphique reste identique quel que soit le
// filtre choisi).
public class StatsViewModel extends AndroidViewModel {

    public enum Period { MONTH, SIX_MONTHS, YEAR }

    public static class MonthlyPoint {
        public final String label;
        public final double totalRevenue;
        public final double totalExpense;

        public MonthlyPoint(String label, double totalRevenue, double totalExpense) {
            this.label = label;
            this.totalRevenue = totalRevenue;
            this.totalExpense = totalExpense;
        }
    }

    private final ReportService reportService;
    private final ExpenseRepository expenseRepository;
    private final RevenueRepository revenueRepository;

    private final MutableLiveData<Report> report = new MutableLiveData<>();
    private final MutableLiveData<Period> selectedPeriod = new MutableLiveData<>(Period.MONTH);
    private final MutableLiveData<List<MonthlyPoint>> evolution = new MutableLiveData<>();

    public StatsViewModel(@NonNull Application application) {
        super(application);
        reportService = new ReportService(application);
        expenseRepository = new ExpenseRepository(application);
        revenueRepository = new RevenueRepository(application);
        loadReport(Period.MONTH);
        loadEvolution();
    }

    public LiveData<Report> getReport() {
        return report;
    }

    public LiveData<Period> getSelectedPeriod() {
        return selectedPeriod;
    }

    public LiveData<List<MonthlyPoint>> getEvolution() {
        return evolution;
    }

    // Recalcule le bilan (revenus/depenses/cashflow/taux d'epargne) pour la periode choisie
    public void loadReport(Period period) {
        selectedPeriod.setValue(period);
        Date end = new Date();
        Date start = periodStart(period, end);

        AppExecutors.getInstance().diskIO().execute(() ->
                report.postValue(reportService.generateMonthlyReportSync(start, end)));
    }

    // Repartition par categorie (donut chart "Repartition des depenses") sur la meme periode
    public LiveData<List<ExpenseDao.CategoryTotal>> getCategoryBreakdown(Period period) {
        Date end = new Date();
        Date start = periodStart(period, end);
        return expenseRepository.getTotalsByCategory(start, end);
    }

    // Serie fixe des 7 derniers mois (revenus + depenses), pour le line chart
    private void loadEvolution() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            List<MonthlyPoint> points = new ArrayList<>();
            SimpleDateFormat monthFormat = new SimpleDateFormat("MMM", Locale.FRENCH);
            for (int i = 6; i >= 0; i--) {
                Calendar monthCal = Calendar.getInstance();
                monthCal.add(Calendar.MONTH, -i);
                Date monthRef = monthCal.getTime();
                Date start = DateUtils.startOfMonth(monthRef);
                Date end = DateUtils.endOfMonth(monthRef);

                double rev = revenueRepository.getTotalBetweenSync(start, end);
                double exp = expenseRepository.getTotalBetweenSync(start, end);
                points.add(new MonthlyPoint(monthFormat.format(monthRef), rev, exp));
            }
            evolution.postValue(points);
        });
    }

    private Date periodStart(Period period, Date end) {
        switch (period) {
            case SIX_MONTHS:
                return DateUtils.monthsAgo(6);
            case YEAR:
                return DateUtils.monthsAgo(12);
            case MONTH:
            default:
                return DateUtils.startOfMonth(end);
        }
    }
}
