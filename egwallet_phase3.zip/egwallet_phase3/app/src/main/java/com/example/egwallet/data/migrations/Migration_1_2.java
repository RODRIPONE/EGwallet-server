package com.example.egwallet.data.migrations;

import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

/**
 * Migration Room v1 → v2
 *
 * Modifications :
 * - Supprime pinCodeHash (SHA-256 local) — le PIN part en clair via HTTPS, BCrypt côté backend
 * - Ajoute serverId (Long) — stocke l'ID utilisateur du backend
 *
 * SQLite ne supporte pas DROP COLUMN directement avant API 35 (Android 15).
 * On recrée la table proprement.
 */
public class Migration_1_2 extends Migration {

    public Migration_1_2() {
        super(1, 2);
    }

    @Override
    public void migrate(SupportSQLiteDatabase database) {
        database.execSQL(
            "CREATE TABLE users_new (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            "serverId INTEGER NOT NULL DEFAULT 0, " +
            "username TEXT NOT NULL, " +
            "biometricEnabled INTEGER NOT NULL, " +
            "createdAt INTEGER NOT NULL, " +
            "isPremium INTEGER NOT NULL DEFAULT 0)"
        );

        database.execSQL(
            "INSERT INTO users_new (id, serverId, username, biometricEnabled, createdAt, isPremium) " +
            "SELECT id, 0, username, biometricEnabled, createdAt, isPremium FROM users"
        );

        database.execSQL("DROP TABLE users");
        database.execSQL("ALTER TABLE users_new RENAME TO users");
    }
}
