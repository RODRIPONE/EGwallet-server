package com.example.egwallet.ui.lock;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.egwallet.MainActivity;
import com.example.egwallet.R;

import java.util.concurrent.Executor;

// Ecran de lancement (cf. AndroidManifest). Gere a la fois la creation de compte
// (premier lancement) et la verification du PIN, plus le deverrouillage biometrique.
public class LockActivity extends AppCompatActivity {

    private LockViewModel viewModel;
    private final StringBuilder pinBuffer = new StringBuilder();
    private LinearLayout pinDotsLayout;
    private TextView pinPromptText;
    private EditText usernameInput;
    private TextView biometricText;
    private boolean creatingAccount = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lock);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.lock_root), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        viewModel = new androidx.lifecycle.ViewModelProvider(this).get(LockViewModel.class);

        pinDotsLayout = findViewById(R.id.layout_pin_dots);
        pinPromptText = findViewById(R.id.text_pin_prompt);
        usernameInput = findViewById(R.id.edit_username);
        biometricText = findViewById(R.id.text_biometric);

        setupKeypad();
        observeViewModel();

        viewModel.getHasAccount().observe(this, hasAccount -> {
            creatingAccount = !Boolean.TRUE.equals(hasAccount);
            pinPromptText.setText(creatingAccount
                    ? getString(R.string.lock_create_pin)
                    : getString(R.string.lock_enter_pin));
            usernameInput.setVisibility(creatingAccount ? View.VISIBLE : View.GONE);
        });

        viewModel.getBiometricAvailable().observe(this, available -> {
            boolean canUseBiometric = Boolean.TRUE.equals(available) && isBiometricHardwareReady();
            biometricText.setVisibility(canUseBiometric ? View.VISIBLE : View.GONE);
        });

        biometricText.setOnClickListener(v -> showBiometricPrompt());
    }

    private void setupKeypad() {
        int[] digitIds = {
                R.id.button_1, R.id.button_2, R.id.button_3,
                R.id.button_4, R.id.button_5, R.id.button_6,
                R.id.button_7, R.id.button_8, R.id.button_9,
                R.id.button_0
        };
        String[] digitValues = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
        for (int i = 0; i < digitIds.length; i++) {
            String digit = digitValues[i];
            findViewById(digitIds[i]).setOnClickListener(v -> onDigitPressed(digit));
        }
        findViewById(R.id.button_backspace).setOnClickListener(v -> onBackspacePressed());
    }

    private void onDigitPressed(String digit) {
        if (pinBuffer.length() >= 6) return;
        pinBuffer.append(digit);
        renderPinDots();
        if (pinBuffer.length() == 6) {
            submitPin();
        }
    }

    private void onBackspacePressed() {
        if (pinBuffer.length() > 0) {
            pinBuffer.deleteCharAt(pinBuffer.length() - 1);
            renderPinDots();
        }
    }

    private void renderPinDots() {
        for (int i = 0; i < pinDotsLayout.getChildCount(); i++) {
            pinDotsLayout.getChildAt(i).setSelected(i < pinBuffer.length());
        }
    }

    private void submitPin() {
        String rawPin = pinBuffer.toString();
        if (creatingAccount) {
            String username = usernameInput.getText().toString().trim();
            if (username.isEmpty()) {
                username = "Utilisateur";
            }
            viewModel.createAccount(username, rawPin);
        } else {
            viewModel.verifyPin(rawPin);
        }
    }

    private void observeViewModel() {
        viewModel.getUnlocked().observe(this, event -> {
            Boolean unlocked = event.getContentIfNotHandled();
            if (Boolean.TRUE.equals(unlocked)) {
                goToMain();
            }
        });

        viewModel.getErrorMessage().observe(this, event -> {
            String message = event.getContentIfNotHandled();
            if (message != null) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                pinBuffer.setLength(0);
                renderPinDots();
            }
        });
    }

    private boolean isBiometricHardwareReady() {
        BiometricManager manager = BiometricManager.from(this);
        int result = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        return result == BiometricManager.BIOMETRIC_SUCCESS;
    }

    private void showBiometricPrompt() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        viewModel.onBiometricSuccess();
                    }
                });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(getString(R.string.lock_biometric_prompt_title))
                .setSubtitle(getString(R.string.lock_biometric_prompt_subtitle))
                .setNegativeButtonText(getString(R.string.lock_use_pin))
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    private void goToMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
