package com.example.egwallet.ui.goals;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Goal;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

// Ecran "Objectifs" : progression globale, liste, FAB.
public class GoalsFragment extends Fragment {

    private GoalViewModel viewModel;
    private GoalRowAdapter adapter;

    private TextView textSubtitle, textGlobalPercent;
    private android.widget.ProgressBar progressGlobal;

    public GoalsFragment() {
        super(R.layout.fragment_goals);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(GoalViewModel.class);

        textSubtitle = view.findViewById(R.id.text_subtitle);
        textGlobalPercent = view.findViewById(R.id.text_global_percent);
        progressGlobal = view.findViewById(R.id.progress_global);
        RecyclerView recycler = view.findViewById(R.id.recycler_goals);

        adapter = new GoalRowAdapter(goal -> {
            GoalDetailBottomSheet sheet = GoalDetailBottomSheet.newInstance(goal.getId());
            sheet.show(getChildFragmentManager(), "goal_detail");
        });
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setAdapter(adapter);

        viewModel.getAllGoals().observe(getViewLifecycleOwner(), this::render);

        viewModel.getShowPaywall().observe(getViewLifecycleOwner(), event -> {
            if (Boolean.TRUE.equals(event.getContentIfNotHandled())) {
                new android.app.AlertDialog.Builder(requireContext())
                        .setTitle(getString(R.string.paywall_title))
                        .setMessage(getString(R.string.paywall_message))
                        .setPositiveButton("Voir Premium", (d, w) ->
                                startActivity(new android.content.Intent(requireContext(),
                                        com.example.egwallet.ui.premium.PremiumActivity.class)))
                        .setNegativeButton("Annuler", null)
                        .show();
            }
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> {
            AddGoalBottomSheet sheet = new AddGoalBottomSheet();
            sheet.show(getChildFragmentManager(), "add_goal");
        });
    }

    private void render(List<Goal> goals) {
        adapter.submitList(goals);
        int count = goals != null ? goals.size() : 0;
        textSubtitle.setText(count + (count > 1 ? " objectifs en cours" : " objectif en cours"));

        if (goals == null || goals.isEmpty()) {
            progressGlobal.setProgress(0);
            textGlobalPercent.setText("Aucun objectif pour l'instant");
            return;
        }
        double sum = 0;
        for (Goal g : goals) sum += g.getProgressPercentage();
        int avg = (int) (sum / goals.size());
        progressGlobal.setProgress(avg);
        textGlobalPercent.setText(avg + "% de vos objectifs atteints en moyenne");
    }
}
