package com.example.egwallet.data.model;

import java.util.Date;

// Pas une entite Room (cf. cahier des charges section 3) : calcule a la demande par
// FinancialSummaryService/ReportService, jamais persiste en base.
public class Report {

    private final Date periodStart;
    private final Date periodEnd;
    private final double totalRevenues;
    private final double totalExpenses;
    private final double balance;
    private final double savingsRatePercent;

    public Report(Date periodStart, Date periodEnd, double totalRevenues,
                  double totalExpenses, double balance, double savingsRatePercent) {
        this.periodStart = periodStart;
        this.periodEnd = periodEnd;
        this.totalRevenues = totalRevenues;
        this.totalExpenses = totalExpenses;
        this.balance = balance;
        this.savingsRatePercent = savingsRatePercent;
    }

    public Date getPeriodStart() { return periodStart; }
    public Date getPeriodEnd() { return periodEnd; }
    public double getTotalRevenues() { return totalRevenues; }
    public double getTotalExpenses() { return totalExpenses; }
    public double getBalance() { return balance; }
    public double getSavingsRatePercent() { return savingsRatePercent; }
}
