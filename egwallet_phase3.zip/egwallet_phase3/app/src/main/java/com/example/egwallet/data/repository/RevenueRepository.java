package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.RevenueDao;
import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.data.remote.ApiService;
import com.example.egwallet.data.remote.DateMapper;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.dto.ApiResponseDto;
import com.example.egwallet.data.remote.dto.RevenueDto;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * RevenueRepository — Phase 3 : API-first with local cache.
 *
 * Flux pour chaque opération :
 *   1. Appel API backend
 *   2. En cas de succès → mise à jour Room (cache) → callback onSuccess
 *   3. En cas d'échec  → callback onError (Room non modifié)
 *
 * Les LiveData retournés viennent de Room et sont automatiquement
 * notifiés après chaque insert/update/delete en cache.
 */
public class RevenueRepository {

    private static final String TAG = "RevenueRepository";

    private final RevenueDao revenueDao;
    private final ApiService apiService;

    public RevenueRepository(Application application) {
        revenueDao = AppDatabase.getInstance(application).revenueDao();
        apiService = RetrofitClient.getInstance(application).getApiService();
    }

    // ── Lecture (Room → LiveData) ─────────────────────────────────────────────

    public LiveData<List<Revenue>> getAll() {
        return revenueDao.getAll();
    }

    public LiveData<List<Revenue>> getBetween(Date start, Date end) {
        return revenueDao.getBetween(start, end);
    }

    public LiveData<Double> getTotalBetween(Date start, Date end) {
        return revenueDao.getTotalBetween(start, end);
    }

    public double getTotalBetweenSync(Date start, Date end) {
        return revenueDao.getTotalBetweenSync(start, end);
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * Crée un revenu via l'API, puis le persiste en cache Room.
     *
     * @param amount   montant (double, converti en String pour le backend BigDecimal)
     * @param source   libellé de la source
     * @param category catégorie (nullable)
     * @param date     date du revenu (java.util.Date → ISO-8601 pour l'API)
     * @param notes    notes optionnelles (nullable)
     * @param callback résultat de l'opération
     */
    public void createRevenue(double amount, String source, String category,
                               Date date, String notes, RevenueCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("amount", amount);
        body.put("source", source);
        body.put("category", category);
        body.put("date", DateMapper.formatDate(date));   // "yyyy-MM-dd"
        if (notes != null && !notes.isEmpty()) body.put("notes", notes);

        apiService.createRevenue(body).enqueue(new Callback<ApiResponseDto<RevenueDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<RevenueDto>> call,
                                   Response<ApiResponseDto<RevenueDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess() && response.body().getData() != null) {
                    RevenueDto dto = response.body().getData();
                    // Persistance en cache Room avec l'ID backend comme id local
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        Revenue local = dtoToEntity(dto);
                        local.setId(dto.getId());   // aligner l'ID local sur l'ID backend
                        revenueDao.insert(local);
                        Log.d(TAG, "Revenue créé et mis en cache : id=" + dto.getId());
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<RevenueDto>> call, Throwable t) {
                Log.e(TAG, "createRevenue failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * Met à jour un revenu via l'API, puis synchronise le cache Room.
     *
     * L'ID passé doit être l'ID backend (= Revenue.id après Phase 3,
     * car on aligne les IDs locaux sur les IDs backend à la création).
     */
    public void updateRevenue(long revenueId, double amount, String source,
                               String category, RevenueCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("amount", amount);
        body.put("source", source);
        body.put("category", category);

        apiService.updateRevenue(revenueId, body).enqueue(new Callback<ApiResponseDto<RevenueDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<RevenueDto>> call,
                                   Response<ApiResponseDto<RevenueDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess() && response.body().getData() != null) {
                    RevenueDto dto = response.body().getData();
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        Revenue local = dtoToEntity(dto);
                        local.setId(dto.getId());
                        revenueDao.update(local);
                        Log.d(TAG, "Revenue mis à jour : id=" + dto.getId());
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<RevenueDto>> call, Throwable t) {
                Log.e(TAG, "updateRevenue failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /**
     * Supprime un revenu via l'API, puis supprime du cache Room.
     */
    public void deleteRevenue(long revenueId, RevenueCallback callback) {
        apiService.deleteRevenue(revenueId).enqueue(new Callback<ApiResponseDto<String>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<String>> call,
                                   Response<ApiResponseDto<String>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        revenueDao.deleteById(revenueId);
                        Log.d(TAG, "Revenue supprimé du cache : id=" + revenueId);
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<String>> call, Throwable t) {
                Log.e(TAG, "deleteRevenue failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── Mapper DTO → entité Room ──────────────────────────────────────────────

    private Revenue dtoToEntity(RevenueDto dto) {
        Revenue r = new Revenue(
                dto.getAmount() != null ? dto.getAmount() : 0.0,
                dto.getSource(),
                dto.getCategory(),
                DateMapper.parseDate(dto.getDate()),    // "yyyy-MM-dd" → Date
                null   // notes non exposé dans RevenueResponse (B9)
        );
        return r;
    }

    // ── Callback ─────────────────────────────────────────────────────────────

    public interface RevenueCallback {
        void onSuccess();
        void onError(String message);
    }
}
