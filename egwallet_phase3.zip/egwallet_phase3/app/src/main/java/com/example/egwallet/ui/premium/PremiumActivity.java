package com.example.egwallet.ui.premium;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.egwallet.R;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.repository.UserRepository;

// Ecran Premium / Paywall. Suggestions IA + comparatif des plans sont statiques dans cette
// iteration. "Activer Premium" est un stub (cahier des charges section 11) : pas de vrai
// paiement Mobile Money, mais on bascule quand meme User.isPremium en local pour que la
// limite d'objectifs (Phase 2) se debloque reellement a des fins de demonstration/test.
public class PremiumActivity extends AppCompatActivity {

    private UserRepository userRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_premium);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.premium_root), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userRepository = new UserRepository(getApplication());

        findViewById(R.id.button_back).setOnClickListener(v -> finish());
        findViewById(R.id.button_activate).setOnClickListener(v -> onActivateClicked());
    }

    private void onActivateClicked() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            User user = userRepository.getCurrentUserSync();
            if (user != null) {
                user.setPremium(true);
                userRepository.update(user);
            }
        });
        Toast.makeText(this,
                "Stub : aucun paiement réel effectué. Premium activé localement pour la démo.",
                Toast.LENGTH_LONG).show();
        finish();
    }
}
