package com.example.egwallet.ui.goals;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.repository.GoalRepository;
import com.example.egwallet.data.repository.UserRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

// Couvre "Definir un objectif", "Suivre la progression", "Modifier/supprimer un objectif",
// ainsi que la limite du plan gratuit (section 7 : 3 objectifs actifs max sans Premium).
public class GoalViewModel extends AndroidViewModel {

    private final GoalRepository goalRepository;
    private final UserRepository userRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> showPaywall = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public GoalViewModel(@NonNull Application application) {
        super(application);
        goalRepository = new GoalRepository(application);
        userRepository = new UserRepository(application);
    }

    public LiveData<List<Goal>> getAllGoals() {
        return goalRepository.getAll();
    }

    public LiveData<Goal> getGoal(long id) {
        return goalRepository.getById(id);
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    // Emis quand la limite du plan gratuit est atteinte : la Fragment doit rediriger
    // vers PremiumActivity (cahier des charges section 7).
    public LiveData<Event<Boolean>> getShowPaywall() {
        return showPaywall;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    // Cas d'usage "Definir un objectif" : valide, verifie la limite plan gratuit, insere.
    public void createGoal(String title, String emoji, String rawTargetAmount, Date deadline) {
        String titleError = ValidationUtils.validateText(title, "Le titre");
        if (titleError != null) {
            errorMessage.setValue(new Event<>(titleError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawTargetAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double targetAmount = Double.parseDouble(rawTargetAmount.trim().replace(" ", ""));

        AppExecutors.getInstance().diskIO().execute(() -> {
            int currentCount = goalRepository.countGoalsSync();
            User user = userRepository.getCurrentUserSync();
            boolean isPremium = user != null && user.isPremium();

            if (!isPremium && currentCount >= GoalRepository.FREE_PLAN_MAX_GOALS) {
                showPaywall.postValue(new Event<>(true));
                return;
            }

            Goal goal = new Goal(title.trim(), emoji, targetAmount, 0, deadline);
            goalRepository.insert(goal);
            saved.postValue(new Event<>(true));
        });
    }

    // Cas d'usage "Suivre la progression" (ajout de fonds) : Goal.addContribution() +
    // persistance via GoalRepository.
    public void addFunds(Goal goal, String rawAmount) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        goalRepository.addContribution(goal, amount);
        saved.setValue(new Event<>(true));
    }

    public void updateGoal(Goal goal) {
        goalRepository.update(goal);
    }

    public void deleteGoal(Goal goal) {
        goalRepository.delete(goal);
    }
}
