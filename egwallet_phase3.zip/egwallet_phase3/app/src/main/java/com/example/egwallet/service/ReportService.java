package com.example.egwallet.service;

import android.app.Application;
import android.util.Log;

import com.example.egwallet.data.model.Report;

import java.util.Date;

// Genere les rapports (mensuel/annuel) et gere leur export. La generation PDF reelle n'est
// pas demandee dans cette iteration (cahier des charges section 11) : on logue uniquement,
// en attendant l'implementation reelle (fonctionnalite Premium).
public class ReportService {

    private static final String TAG = "ReportService";

    private final FinancialSummaryService financialSummaryService;

    public ReportService(Application application) {
        financialSummaryService = new FinancialSummaryService(application);
    }

    // A appeler depuis un thread de fond (requetes Room synchrones sous le capot).
    public Report generateMonthlyReportSync(Date periodStart, Date periodEnd) {
        return financialSummaryService.getMonthlyReportSync(periodStart, periodEnd);
    }

    // Stub : pas de generation PDF reelle dans cette iteration.
    public void generatePDF(Report report) {
        Log.d(TAG, "generatePDF() stub - periode " + report.getPeriodStart()
                + " -> " + report.getPeriodEnd() + " (fonctionnalite Premium a implementer)");
    }
}
