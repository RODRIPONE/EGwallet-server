package com.example.egwallet.ui.goals;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Calendar;
import java.util.Date;

public class AddGoalBottomSheet extends BottomSheetDialogFragment {

    private GoalViewModel viewModel;
    // Echeance par defaut : dans 12 mois
    private Date selectedDate = new Date(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000);

    private EditText editTitle, editTarget;
    private Spinner spinnerEmoji;
    private TextView textDate, textError;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_add_goal, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireParentFragment()).get(GoalViewModel.class);

        editTitle = view.findViewById(R.id.edit_title);
        editTarget = view.findViewById(R.id.edit_target);
        spinnerEmoji = view.findViewById(R.id.spinner_emoji);
        textDate = view.findViewById(R.id.text_date);
        textError = view.findViewById(R.id.text_error);

        ArrayAdapter<CharSequence> emojiAdapter = ArrayAdapter.createFromResource(
                requireContext(), R.array.goal_emojis, android.R.layout.simple_spinner_dropdown_item);
        emojiAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerEmoji.setAdapter(emojiAdapter);

        updateDateText();
        textDate.setOnClickListener(v -> showDatePicker());
        view.findViewById(R.id.button_close).setOnClickListener(v -> dismiss());
        view.findViewById(R.id.button_save).setOnClickListener(v -> onSaveClicked());

        viewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null) {
                textError.setVisibility(View.VISIBLE);
                textError.setText(message);
            }
        });
        viewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (Boolean.TRUE.equals(event.getContentIfNotHandled())) dismiss();
        });
        // Si la limite du plan gratuit est atteinte, GoalsFragment affiche deja le dialogue
        // paywall ; on ferme simplement cette feuille pour ne pas la laisser ouverte dessous.
        viewModel.getShowPaywall().observe(getViewLifecycleOwner(), event -> {
            if (event.peekContent() != null && Boolean.TRUE.equals(event.peekContent())) dismiss();
        });
    }

    private void updateDateText() {
        textDate.setText(DateFormat.format("dd/MM/yyyy", selectedDate));
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);
        new DatePickerDialog(requireContext(), (picker, year, month, day) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year, month, day);
            selectedDate = picked.getTime();
            updateDateText();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void onSaveClicked() {
        textError.setVisibility(View.GONE);
        String title = editTitle.getText().toString();
        String target = editTarget.getText().toString();
        String emoji = String.valueOf(spinnerEmoji.getSelectedItem());
        viewModel.createGoal(title, emoji, target, selectedDate);
    }
}
