package com.example.egwallet.ui.credit;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.entity.DuePayment;
import com.example.egwallet.util.CurrencyFormatter;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.List;

// Detail + remboursement d'une dette ou d'un du (partage la meme UI pour les deux, comme
// AddDebtDueBottomSheet). Observe getAllWithRemaining() pour le solde a jour en temps reel
// (se met a jour tout seul juste apres un remboursement, sans fermer/rouvrir la feuille).
public class RepayBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_IS_DEBT = "is_debt";
    private static final String ARG_ID = "id";

    public static RepayBottomSheet newInstance(boolean isDebt, long id) {
        RepayBottomSheet sheet = new RepayBottomSheet();
        Bundle args = new Bundle();
        args.putBoolean(ARG_IS_DEBT, isDebt);
        args.putLong(ARG_ID, id);
        sheet.setArguments(args);
        return sheet;
    }

    private DebtViewModel debtViewModel;
    private DueViewModel dueViewModel;
    private boolean isDebt;
    private long targetId;
    private String currentName = "";

    private TextView textName, textRemainingLabel, textRemainingAmount, textError, textNoHistory;
    private EditText editAmount;
    private LinearLayout layoutHistory;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        isDebt = args == null || args.getBoolean(ARG_IS_DEBT, true);
        targetId = args != null ? args.getLong(ARG_ID) : -1L;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_repay, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        debtViewModel = new ViewModelProvider(requireParentFragment()).get(DebtViewModel.class);
        dueViewModel = new ViewModelProvider(requireParentFragment()).get(DueViewModel.class);

        textName = view.findViewById(R.id.text_name);
        textRemainingLabel = view.findViewById(R.id.text_remaining_label);
        textRemainingAmount = view.findViewById(R.id.text_remaining_amount);
        textError = view.findViewById(R.id.text_error);
        textNoHistory = view.findViewById(R.id.text_no_history);
        editAmount = view.findViewById(R.id.edit_amount);
        layoutHistory = view.findViewById(R.id.layout_history);

        textRemainingLabel.setText(isDebt ? "SOLDE RESTANT" : "MONTANT ENCORE DÛ");

        view.findViewById(R.id.button_close).setOnClickListener(v -> dismiss());
        view.findViewById(R.id.button_repay).setOnClickListener(v -> onRepayClicked());

        if (isDebt) {
            debtViewModel.getAllWithRemaining().observe(getViewLifecycleOwner(), this::bindDebtList);
            debtViewModel.getPayments(targetId).observe(getViewLifecycleOwner(), this::bindDebtHistory);
            debtViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
                String message = event.getContentIfNotHandled();
                if (message != null) showError(message);
            });
            debtViewModel.getRepaymentSuccess().observe(getViewLifecycleOwner(), event -> {
                if (Boolean.TRUE.equals(event.getContentIfNotHandled())) {
                    editAmount.setText("");
                    textError.setVisibility(View.GONE);
                }
            });
        } else {
            dueViewModel.getAllWithRemaining().observe(getViewLifecycleOwner(), this::bindDueList);
            dueViewModel.getPayments(targetId).observe(getViewLifecycleOwner(), this::bindDueHistory);
            dueViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
                String message = event.getContentIfNotHandled();
                if (message != null) showError(message);
            });
            dueViewModel.getReceptionSuccess().observe(getViewLifecycleOwner(), event -> {
                if (Boolean.TRUE.equals(event.getContentIfNotHandled())) {
                    editAmount.setText("");
                    textError.setVisibility(View.GONE);
                }
            });
        }
    }

    private void bindDebtList(List<DebtDao.DebtWithRemaining> debts) {
        for (DebtDao.DebtWithRemaining d : debts) {
            if (d.id == targetId) {
                currentName = d.creditor;
                textName.setText(d.creditor);
                textRemainingAmount.setText(CurrencyFormatter.formatFull(d.getRemainingAmount()));
                return;
            }
        }
    }

    private void bindDueList(List<DueDao.DueWithRemaining> dues) {
        for (DueDao.DueWithRemaining d : dues) {
            if (d.id == targetId) {
                currentName = d.debtorName;
                textName.setText(d.debtorName);
                textRemainingAmount.setText(CurrencyFormatter.formatFull(d.getRemainingAmount()));
                return;
            }
        }
    }

    private void bindDebtHistory(List<DebtPayment> payments) {
        layoutHistory.removeAllViews();
        textNoHistory.setVisibility(payments == null || payments.isEmpty() ? View.VISIBLE : View.GONE);
        if (payments == null) return;
        for (DebtPayment p : payments) {
            layoutHistory.addView(buildHistoryRow(
                    CurrencyFormatter.formatFull(p.getAmountPaid()), p.getPaymentDate()));
        }
    }

    private void bindDueHistory(List<DuePayment> payments) {
        layoutHistory.removeAllViews();
        textNoHistory.setVisibility(payments == null || payments.isEmpty() ? View.VISIBLE : View.GONE);
        if (payments == null) return;
        for (DuePayment p : payments) {
            layoutHistory.addView(buildHistoryRow(
                    CurrencyFormatter.formatFull(p.getAmountReceived()), p.getPaymentDate()));
        }
    }

    private View buildHistoryRow(String amountText, java.util.Date date) {
        LinearLayout row = new LinearLayout(requireContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 12, 0, 12);

        TextView dateView = new TextView(requireContext());
        dateView.setText(DateFormat.format("d MMM yyyy", date));
        dateView.setTextColor(0xFF6B7280);
        dateView.setTextSize(12f);
        LinearLayout.LayoutParams dateParams = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(dateView, dateParams);

        TextView amountView = new TextView(requireContext());
        amountView.setText(amountText);
        amountView.setTextColor(0xFF16A34A);
        amountView.setTextSize(13f);
        row.addView(amountView);

        return row;
    }

    private void showError(String message) {
        textError.setVisibility(View.VISIBLE);
        textError.setText(message);
    }

    private void onRepayClicked() {
        textError.setVisibility(View.GONE);
        String amount = editAmount.getText().toString();
        if (isDebt) {
            debtViewModel.repayDebt(targetId, amount, currentName);
        } else {
            dueViewModel.receivePayment(targetId, amount, currentName);
        }
    }
}
