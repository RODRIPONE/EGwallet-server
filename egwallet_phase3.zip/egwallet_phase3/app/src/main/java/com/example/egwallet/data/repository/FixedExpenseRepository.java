package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.FixedExpenseDao;
import com.example.egwallet.data.entity.FixedExpense;

import java.util.List;

public class FixedExpenseRepository {

    private final FixedExpenseDao fixedExpenseDao;

    public FixedExpenseRepository(Application application) {
        fixedExpenseDao = AppDatabase.getInstance(application).fixedExpenseDao();
    }

    public LiveData<List<FixedExpense>> getAll() {
        return fixedExpenseDao.getAll();
    }

    public FixedExpense getByIdSync(long id) {
        return fixedExpenseDao.getByIdSync(id);
    }

    public void insert(FixedExpense fixedExpense) {
        AppExecutors.getInstance().diskIO().execute(() -> fixedExpenseDao.insert(fixedExpense));
    }

    public void update(FixedExpense fixedExpense) {
        AppExecutors.getInstance().diskIO().execute(() -> fixedExpenseDao.update(fixedExpense));
    }

    public void delete(FixedExpense fixedExpense) {
        AppExecutors.getInstance().diskIO().execute(() -> fixedExpenseDao.delete(fixedExpense));
    }
}
