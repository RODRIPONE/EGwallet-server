package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.UserDao;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.remote.ApiService;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.SecurePreferences;
import com.example.egwallet.data.remote.dto.ApiResponseDto;
import com.example.egwallet.data.remote.dto.AuthResponseDto;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Repository authentification — Phase 2.
 *
 * Stratégie API-first :
 * 1. Appel backend (register/login)
 * 2. Stockage token JWT (SecurePreferences)
 * 3. Persistance utilisateur local (Room) avec serverId
 *
 * Le PIN est envoyé en clair via HTTPS — le backend fait le BCrypt.
 * Aucun hash local (SHA-256 supprimé).
 */
public class UserRepository {

    private static final String TAG = "UserRepository";

    private final UserDao userDao;
    private final ApiService apiService;
    private final SecurePreferences securePreferences;

    public UserRepository(Application application) {
        userDao = AppDatabase.getInstance(application).userDao();
        apiService = RetrofitClient.getInstance(application).getApiService();
        securePreferences = SecurePreferences.getInstance(application);
    }

    // ── Authentification API ──────────────────────────────────────────────────

    public void registerUser(String username, String rawPin, AuthCallback callback) {
        // B4 FIX : construire le Map attendu par @Body Map<String, String>
        Map<String, String> body = new HashMap<>();
        body.put("username", username);
        body.put("pin", rawPin);

        apiService.register(body).enqueue(new Callback<ApiResponseDto<AuthResponseDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<AuthResponseDto>> call,
                                   Response<ApiResponseDto<AuthResponseDto>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponseDto<AuthResponseDto> api = response.body();
                    if (api.isSuccess() && api.getData() != null) {
                        AuthResponseDto data = api.getData();
                        securePreferences.saveToken(data.getToken());
                        securePreferences.saveSession(
                                data.getUserId(),
                                data.getUsername(),
                                Boolean.TRUE.equals(data.getIsPremium()),
                                Boolean.TRUE.equals(data.getBiometricEnabled())
                        );
                        AppExecutors.getInstance().diskIO().execute(() -> {
                            User user = new User(
                                    data.getUsername(),
                                    Boolean.TRUE.equals(data.getBiometricEnabled()),
                                    new Date()
                            );
                            user.setServerId(data.getUserId());
                            user.setPremium(Boolean.TRUE.equals(data.getIsPremium()));
                            userDao.insert(user);
                            Log.d(TAG, "Utilisateur inséré en Room : " + data.getUsername());
                        });
                        callback.onSuccess("Inscription réussie");
                    } else {
                        callback.onError(api.getMessage() != null ? api.getMessage() : "Erreur serveur");
                    }
                } else {
                    callback.onError("Réponse invalide (code " + response.code() + ")");
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<AuthResponseDto>> call, Throwable t) {
                Log.e(TAG, "register failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    public void loginUser(String username, String rawPin, AuthCallback callback) {
        // B4 FIX : construire le Map attendu par @Body Map<String, String>
        Map<String, String> body = new HashMap<>();
        body.put("username", username);
        body.put("pin", rawPin);

        apiService.login(body).enqueue(new Callback<ApiResponseDto<AuthResponseDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<AuthResponseDto>> call,
                                   Response<ApiResponseDto<AuthResponseDto>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponseDto<AuthResponseDto> api = response.body();
                    if (api.isSuccess() && api.getData() != null) {
                        AuthResponseDto data = api.getData();
                        securePreferences.saveToken(data.getToken());
                        securePreferences.saveSession(
                                data.getUserId(),
                                data.getUsername(),
                                Boolean.TRUE.equals(data.getIsPremium()),
                                Boolean.TRUE.equals(data.getBiometricEnabled())
                        );
                        AppExecutors.getInstance().diskIO().execute(() -> {
                            User existing = userDao.getCurrentUserSync();
                            if (existing != null) {
                                existing.setServerId(data.getUserId());
                                existing.setPremium(Boolean.TRUE.equals(data.getIsPremium()));
                                userDao.update(existing);
                            } else {
                                User user = new User(
                                        data.getUsername(),
                                        Boolean.TRUE.equals(data.getBiometricEnabled()),
                                        new Date()
                                );
                                user.setServerId(data.getUserId());
                                user.setPremium(Boolean.TRUE.equals(data.getIsPremium()));
                                userDao.insert(user);
                            }
                            Log.d(TAG, "Session mise à jour : " + data.getUsername());
                        });
                        callback.onSuccess("Connexion réussie");
                    } else {
                        callback.onError(api.getMessage() != null ? api.getMessage() : "Identifiants incorrects");
                    }
                } else {
                    callback.onError("Réponse invalide (code " + response.code() + ")");
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<AuthResponseDto>> call, Throwable t) {
                Log.e(TAG, "login failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── Accès local Room ─────────────────────────────────────────────────────

    public LiveData<User> getCurrentUser()   { return userDao.getCurrentUser(); }
    public User getCurrentUserSync()         { return userDao.getCurrentUserSync(); }
    public boolean hasAccountSync()          { return userDao.countUsers() > 0; }
    public void insert(User user)            { AppExecutors.getInstance().diskIO().execute(() -> userDao.insert(user)); }
    public void update(User user)            { AppExecutors.getInstance().diskIO().execute(() -> userDao.update(user)); }

    // ── Callback ─────────────────────────────────────────────────────────────

    public interface AuthCallback {
        void onSuccess(String message);
        void onError(String errorMessage);
    }
}
