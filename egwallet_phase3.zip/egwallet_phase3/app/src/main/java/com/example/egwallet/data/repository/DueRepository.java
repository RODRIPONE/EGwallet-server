package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.data.dao.DuePaymentDao;
import com.example.egwallet.data.dao.SyncQueueDao;
import com.example.egwallet.data.entity.Due;
import com.example.egwallet.data.entity.DuePayment;
import com.example.egwallet.data.entity.SyncQueueEvent;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

public class DueRepository {

    public interface ReceptionCallback {
        void onSuccess(boolean fullyReceived);
        void onError(String message);
    }

    private final AppDatabase db;
    private final DueDao dueDao;
    private final DuePaymentDao duePaymentDao;
    private final SyncQueueDao syncQueueDao;

    public DueRepository(Application application) {
        db = AppDatabase.getInstance(application);
        dueDao = db.dueDao();
        duePaymentDao = db.duePaymentDao();
        syncQueueDao = db.syncQueueDao();
    }

    public LiveData<List<DueDao.DueWithRemaining>> getAllWithRemaining() {
        return dueDao.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return dueDao.getTotalRemaining();
    }

    public LiveData<Due> getById(long id) {
        return dueDao.getById(id);
    }

    public LiveData<List<DuePayment>> getPaymentsForDue(long dueId) {
        return duePaymentDao.getForDue(dueId);
    }

    public void insert(Due due) {
        AppExecutors.getInstance().diskIO().execute(() -> dueDao.insert(due));
    }

    public void update(Due due) {
        AppExecutors.getInstance().diskIO().execute(() -> dueDao.update(due));
    }

    public void delete(Due due) {
        AppExecutors.getInstance().diskIO().execute(() -> dueDao.delete(due));
    }

    // Symetrique de DebtRepository.repayDebt() : "Recevoir un remboursement de du"
    // (meme logique de validation/transaction/sync_queue, cf. cahier des charges section 6).
    public void receivePayment(long dueId, double amount, ReceptionCallback callback) {
        AppExecutors.getInstance().diskIO().execute(() -> {
            Due due = dueDao.getByIdSync(dueId);
            if (due == null) {
                callback.onError("Dû introuvable");
                return;
            }

            double alreadyReceived = duePaymentDao.getTotalReceivedSync(dueId);
            double remaining = due.getInitialAmount() - alreadyReceived;

            String validationError = ValidationUtils.validateRepaymentAmount(amount, remaining);
            if (validationError != null) {
                callback.onError(validationError);
                return;
            }

            double newRemaining = remaining - amount;
            boolean fullyReceived = newRemaining <= 0.0001;
            String newStatus = fullyReceived ? Due.STATUS_RECEIVED : Due.STATUS_PARTIALLY_RECEIVED;
            due.setStatus(newStatus);

            db.runInTransaction(() -> {
                duePaymentDao.insert(new DuePayment(dueId, amount, new Date(), null));
                dueDao.update(due);
                syncQueueDao.insert(new SyncQueueEvent(
                        SyncQueueEvent.TYPE_DUE_PAYMENT_CREATED,
                        dueId,
                        SyncQueueEvent.STATUS_PENDING,
                        new Date()));
            });

            callback.onSuccess(fullyReceived);
        });
    }
}
