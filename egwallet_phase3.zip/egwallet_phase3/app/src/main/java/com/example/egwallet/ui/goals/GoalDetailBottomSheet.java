package com.example.egwallet.ui.goals;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.util.CurrencyFormatter;
import com.example.egwallet.util.DateUtils;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Date;

public class GoalDetailBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_GOAL_ID = "goal_id";

    public static GoalDetailBottomSheet newInstance(long goalId) {
        GoalDetailBottomSheet sheet = new GoalDetailBottomSheet();
        Bundle args = new Bundle();
        args.putLong(ARG_GOAL_ID, goalId);
        sheet.setArguments(args);
        return sheet;
    }

    private GoalViewModel viewModel;
    private long goalId;
    private Goal currentGoal;

    private TextView textTitle, textPercent, textCurrentAmount, textTargetAmount,
            textMonthsRemaining, textMonthlySavings, textDeadline, textError;
    private ProgressBar progressGoal;
    private EditText editAmount;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        goalId = getArguments() != null ? getArguments().getLong(ARG_GOAL_ID) : -1L;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_goal_detail, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(requireParentFragment()).get(GoalViewModel.class);

        textTitle = view.findViewById(R.id.text_title);
        textPercent = view.findViewById(R.id.text_percent);
        textCurrentAmount = view.findViewById(R.id.text_current_amount);
        textTargetAmount = view.findViewById(R.id.text_target_amount);
        textMonthsRemaining = view.findViewById(R.id.text_months_remaining);
        textMonthlySavings = view.findViewById(R.id.text_monthly_savings);
        textDeadline = view.findViewById(R.id.text_deadline);
        textError = view.findViewById(R.id.text_error);
        progressGoal = view.findViewById(R.id.progress_goal);
        editAmount = view.findViewById(R.id.edit_amount);

        view.findViewById(R.id.button_close).setOnClickListener(v -> dismiss());
        view.findViewById(R.id.button_add_funds).setOnClickListener(v -> onAddFundsClicked());

        viewModel.getGoal(goalId).observe(getViewLifecycleOwner(), this::bind);

        viewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null) {
                textError.setVisibility(View.VISIBLE);
                textError.setText(message);
            }
        });
        viewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (Boolean.TRUE.equals(event.getContentIfNotHandled())) {
                editAmount.setText("");
                textError.setVisibility(View.GONE);
            }
        });
    }

    private void bind(Goal goal) {
        if (goal == null) return;
        currentGoal = goal;

        textTitle.setText(goal.getEmoji() + " " + goal.getTitle());
        int percent = (int) goal.getProgressPercentage();
        textPercent.setText(percent + "%");
        progressGoal.setProgress(percent);
        textCurrentAmount.setText(CurrencyFormatter.formatFull(goal.getCurrentAmount()));
        textTargetAmount.setText(CurrencyFormatter.formatFull(goal.getTargetAmount()));
        textDeadline.setText(DateFormat.format("d MMMM yyyy", goal.getDeadline()));

        int months = DateUtils.monthsBetween(new Date(), goal.getDeadline());
        textMonthsRemaining.setText(months + " mois");

        double remaining = goal.getRemainingAmount();
        double monthlyNeeded = months > 0 ? remaining / months : remaining;
        textMonthlySavings.setText(CurrencyFormatter.formatAbbreviated(monthlyNeeded));
    }

    private void onAddFundsClicked() {
        textError.setVisibility(View.GONE);
        if (currentGoal == null) return;
        String amount = editAmount.getText().toString();
        viewModel.addFunds(currentGoal, amount);
    }
}
