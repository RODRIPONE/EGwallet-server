package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    private long id;

    /** ID côté backend — 0 si pas encore synchronisé */
    private long serverId;

    private String username;
    private boolean biometricEnabled;
    private Date createdAt;
    private boolean isPremium;

    // Constructeur Phase 2 : plus de pinCodeHash (BCrypt côté backend)
    public User(String username, boolean biometricEnabled, Date createdAt) {
        this.username = username;
        this.biometricEnabled = biometricEnabled;
        this.createdAt = createdAt;
        this.serverId = 0;
        this.isPremium = false;
    }

    public long getId()                      { return id; }
    public void setId(long id)               { this.id = id; }

    public long getServerId()                { return serverId; }
    public void setServerId(long serverId)   { this.serverId = serverId; }

    public String getUsername()              { return username; }
    public void setUsername(String username) { this.username = username; }

    public boolean isBiometricEnabled()      { return biometricEnabled; }
    public void setBiometricEnabled(boolean biometricEnabled) { this.biometricEnabled = biometricEnabled; }

    public Date getCreatedAt()               { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public boolean isPremium()               { return isPremium; }
    public void setPremium(boolean premium)  { isPremium = premium; }
}
