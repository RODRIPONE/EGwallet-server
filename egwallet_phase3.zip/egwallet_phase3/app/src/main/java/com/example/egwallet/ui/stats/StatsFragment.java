package com.example.egwallet.ui.stats;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.example.egwallet.data.dao.ExpenseDao;
import com.example.egwallet.data.model.Report;
import com.example.egwallet.util.CurrencyFormatter;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.button.MaterialButtonToggleGroup;

import java.util.ArrayList;
import java.util.List;

// Ecran "Stats" : filtres, cartes resume, evolution (LineChart), repartition (PieChart),
// ratio depenses/revenus, bilan detaille.
public class StatsFragment extends Fragment {

    private StatsViewModel viewModel;
    private LineChart lineChart;
    private PieChart pieChart;

    private TextView textRevenues, textExpenses, textBalance, textRatioPercent, textRatioMessage,
            textSummaryTitle, textSummaryRevenues, textSummaryExpenses, textSummaryCashflow,
            textSummarySavingsRate;
    private ProgressBar progressRatio;

    public StatsFragment() {
        super(R.layout.fragment_stats);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(StatsViewModel.class);

        textRevenues = view.findViewById(R.id.text_revenues);
        textExpenses = view.findViewById(R.id.text_expenses);
        textBalance = view.findViewById(R.id.text_balance);
        textRatioPercent = view.findViewById(R.id.text_ratio_percent);
        textRatioMessage = view.findViewById(R.id.text_ratio_message);
        textSummaryTitle = view.findViewById(R.id.text_summary_title);
        textSummaryRevenues = view.findViewById(R.id.text_summary_revenues);
        textSummaryExpenses = view.findViewById(R.id.text_summary_expenses);
        textSummaryCashflow = view.findViewById(R.id.text_summary_cashflow);
        textSummarySavingsRate = view.findViewById(R.id.text_summary_savings_rate);
        progressRatio = view.findViewById(R.id.progress_ratio);
        lineChart = view.findViewById(R.id.line_chart);
        pieChart = view.findViewById(R.id.pie_chart);

        setupLineChart();
        setupPieChart();

        MaterialButtonToggleGroup toggleGroup = view.findViewById(R.id.toggle_group);
        toggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            StatsViewModel.Period period;
            if (checkedId == R.id.button_6months) {
                period = StatsViewModel.Period.SIX_MONTHS;
            } else if (checkedId == R.id.button_year) {
                period = StatsViewModel.Period.YEAR;
            } else {
                period = StatsViewModel.Period.MONTH;
            }
            viewModel.loadReport(period);
            observeBreakdown(period);
        });

        viewModel.getReport().observe(getViewLifecycleOwner(), this::bindReport);
        viewModel.getEvolution().observe(getViewLifecycleOwner(), this::bindEvolution);
        observeBreakdown(StatsViewModel.Period.MONTH);

        View cardCoach = view.findViewById(R.id.card_coach);
        if (cardCoach != null) {
            cardCoach.setOnClickListener(v -> startActivity(
                    new android.content.Intent(requireContext(),
                            com.example.egwallet.ui.premium.PremiumActivity.class)));
        }
    }

    private void observeBreakdown(StatsViewModel.Period period) {
        viewModel.getCategoryBreakdown(period).observe(getViewLifecycleOwner(), this::bindBreakdown);
    }

    private void bindReport(Report report) {
        if (report == null) return;
        textRevenues.setText(CurrencyFormatter.formatAbbreviated(report.getTotalRevenues()));
        textExpenses.setText(CurrencyFormatter.formatAbbreviated(report.getTotalExpenses()));
        textBalance.setText((report.getBalance() >= 0 ? "+" : "")
                + CurrencyFormatter.formatAbbreviated(report.getBalance()));

        int ratio = report.getTotalRevenues() > 0
                ? (int) ((report.getTotalExpenses() / report.getTotalRevenues()) * 100)
                : 0;
        progressRatio.setProgress(Math.min(ratio, 100));
        textRatioPercent.setText(ratio + "%");
        textRatioMessage.setText(ratio < 50
                ? "✅ Excellente gestion — continuez ainsi"
                : ratio < 80
                    ? "⚠️ Gestion correcte, restez vigilant"
                    : "🚨 Dépenses élevées par rapport aux revenus");

        textSummaryTitle.setText("BILAN — " + periodLabel());
        textSummaryRevenues.setText(CurrencyFormatter.formatFull(report.getTotalRevenues()));
        textSummaryExpenses.setText(CurrencyFormatter.formatFull(report.getTotalExpenses()));
        textSummaryCashflow.setText((report.getBalance() >= 0 ? "+" : "")
                + CurrencyFormatter.formatFull(report.getBalance()));
        textSummarySavingsRate.setText(((int) report.getSavingsRatePercent()) + "%");
    }

    private String periodLabel() {
        StatsViewModel.Period period = viewModel.getSelectedPeriod().getValue();
        if (period == StatsViewModel.Period.SIX_MONTHS) return "6 MOIS";
        if (period == StatsViewModel.Period.YEAR) return "ANNÉE";
        return "CE MOIS";
    }

    private void setupLineChart() {
        lineChart.getDescription().setEnabled(false);
        lineChart.setDrawGridBackground(false);
        lineChart.setTouchEnabled(true);
        lineChart.getAxisRight().setEnabled(false);
        lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        lineChart.getXAxis().setDrawGridLines(false);
        lineChart.getXAxis().setGranularity(1f);
        lineChart.getAxisLeft().setDrawGridLines(true);
        lineChart.getLegend().setEnabled(true);
    }

    private void bindEvolution(List<StatsViewModel.MonthlyPoint> points) {
        if (points == null || points.isEmpty()) return;

        List<Entry> revenueEntries = new ArrayList<>();
        List<Entry> expenseEntries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < points.size(); i++) {
            StatsViewModel.MonthlyPoint p = points.get(i);
            revenueEntries.add(new Entry(i, (float) p.totalRevenue));
            expenseEntries.add(new Entry(i, (float) p.totalExpense));
            labels.add(p.label);
        }

        LineDataSet revenueSet = new LineDataSet(revenueEntries, "Revenus");
        revenueSet.setColor(Color.parseColor("#16A34A"));
        revenueSet.setCircleColor(Color.parseColor("#16A34A"));
        revenueSet.setLineWidth(2f);
        revenueSet.setCircleRadius(3f);
        revenueSet.setDrawValues(false);
        revenueSet.setDrawFilled(false);

        LineDataSet expenseSet = new LineDataSet(expenseEntries, "Dépenses");
        expenseSet.setColor(Color.parseColor("#DC2626"));
        expenseSet.setCircleColor(Color.parseColor("#DC2626"));
        expenseSet.setLineWidth(2f);
        expenseSet.setCircleRadius(3f);
        expenseSet.setDrawValues(false);
        expenseSet.setDrawFilled(false);

        lineChart.setData(new LineData(revenueSet, expenseSet));
        lineChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(labels));
        lineChart.invalidate();
    }

    private void setupPieChart() {
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleRadius(58f);
        pieChart.setTransparentCircleRadius(62f);
        pieChart.setDrawEntryLabels(false);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.getLegend().setEnabled(true);
    }

    private static final int[] CATEGORY_COLORS = {
            Color.parseColor("#E8B923"), Color.parseColor("#2563EB"),
            Color.parseColor("#DC2626"), Color.parseColor("#7C3AED"),
            Color.parseColor("#16A34A"), Color.parseColor("#D97706"),
            Color.parseColor("#0891B2")
    };

    private void bindBreakdown(List<ExpenseDao.CategoryTotal> categories) {
        if (categories == null || categories.isEmpty()) {
            pieChart.clear();
            return;
        }
        List<PieEntry> entries = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        for (int i = 0; i < categories.size(); i++) {
            ExpenseDao.CategoryTotal ct = categories.get(i);
            entries.add(new PieEntry((float) ct.total, ct.category));
            colors.add(CATEGORY_COLORS[i % CATEGORY_COLORS.length]);
        }
        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(colors);
        dataSet.setDrawValues(false);
        dataSet.setSliceSpace(2f);

        pieChart.setData(new PieData(dataSet));
        pieChart.invalidate();
    }
}
