package com.example.egwallet.ui.home;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.util.CurrencyFormatter;

public class HomeFragment extends Fragment {

    private HomeViewModel viewModel;
    private TransactionAdapter transactionAdapter;

    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        TextView textUsername = view.findViewById(R.id.text_username);
        TextView textBalance = view.findViewById(R.id.text_balance);
        TextView textMonthBalance = view.findViewById(R.id.text_month_balance);
        TextView textTotalDebts = view.findViewById(R.id.text_total_debts);
        TextView textTotalDues = view.findViewById(R.id.text_total_dues);
        TextView textTotalSavings = view.findViewById(R.id.text_total_savings);
        TextView textGoalTitle = view.findViewById(R.id.text_goal_title);
        TextView textGoalPercent = view.findViewById(R.id.text_goal_percent);
        ProgressBar progressGoal = view.findViewById(R.id.progress_goal);
        RecyclerView recyclerRecent = view.findViewById(R.id.recycler_recent);

        transactionAdapter = new TransactionAdapter();
        recyclerRecent.setLayoutManager(new LinearLayoutManager(requireContext()));
        recyclerRecent.setAdapter(transactionAdapter);
        recyclerRecent.setNestedScrollingEnabled(false);

        viewModel.getCurrentUser().observe(getViewLifecycleOwner(), user ->
                textUsername.setText(user != null ? user.getUsername() : ""));

        viewModel.getRunningBalance().observe(getViewLifecycleOwner(), balance ->
                textBalance.setText(CurrencyFormatter.formatFull(balance != null ? balance : 0)));

        viewModel.getCurrentMonthBalance().observe(getViewLifecycleOwner(), balance -> {
            double value = balance != null ? balance : 0;
            String sign = value >= 0 ? "+" : "";
            textMonthBalance.setText("Bilan du mois : " + sign + CurrencyFormatter.formatFull(value));
        });

        viewModel.getTotalDebtsRemaining().observe(getViewLifecycleOwner(), total ->
                textTotalDebts.setText(CurrencyFormatter.formatAbbreviated(total != null ? total : 0)));

        viewModel.getTotalDuesRemaining().observe(getViewLifecycleOwner(), total ->
                textTotalDues.setText(CurrencyFormatter.formatAbbreviated(total != null ? total : 0)));

        viewModel.getTotalSavings().observe(getViewLifecycleOwner(), total ->
                textTotalSavings.setText(CurrencyFormatter.formatAbbreviated(total != null ? total : 0)));

        viewModel.getGoals().observe(getViewLifecycleOwner(), goals -> {
            if (goals != null && !goals.isEmpty()) {
                Goal mainGoal = goals.get(0);
                textGoalTitle.setText(mainGoal.getEmoji() + " " + mainGoal.getTitle());
                int percent = (int) mainGoal.getProgressPercentage();
                textGoalPercent.setText(percent + "%");
                progressGoal.setProgress(percent);
            } else {
                textGoalTitle.setText("Aucun objectif pour l'instant");
                textGoalPercent.setText("0%");
                progressGoal.setProgress(0);
            }
        });

        viewModel.getRecentTransactions().observe(getViewLifecycleOwner(),
                transactions -> transactionAdapter.submitList(transactions));

        view.findViewById(R.id.action_revenue).setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.navigation_transactions));
        view.findViewById(R.id.action_expense).setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.navigation_transactions));
        view.findViewById(R.id.action_credit).setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.navigation_credit));
        view.findViewById(R.id.action_stats).setOnClickListener(v ->
                Navigation.findNavController(view).navigate(R.id.navigation_stats));

        View cardPremium = view.findViewById(R.id.card_premium);
        if (cardPremium != null) {
            cardPremium.setOnClickListener(v -> startActivity(
                    new android.content.Intent(requireContext(),
                            com.example.egwallet.ui.premium.PremiumActivity.class)));
        }
    }
}
