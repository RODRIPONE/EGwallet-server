package com.example.egwallet.ui.transactions;

import android.content.res.ColorStateList;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.util.CurrencyFormatter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Adapter generique : affiche une liste de Revenue OU de Expense converties en
// TransactionRow pour un affichage uniforme (utilise par l'ecran Flux complet).
public class TransactionFullAdapter extends RecyclerView.Adapter<TransactionFullAdapter.ViewHolder> {

    public static class TransactionRow {
        public final String label;
        public final String category;
        public final double amount;
        public final boolean isRevenue;
        public final boolean isFixed;
        public final Date date;

        public TransactionRow(String label, String category, double amount, boolean isRevenue,
                               boolean isFixed, Date date) {
            this.label = label;
            this.category = category;
            this.amount = amount;
            this.isRevenue = isRevenue;
            this.isFixed = isFixed;
            this.date = date;
        }
    }

    private List<TransactionRow> rows = new ArrayList<>();

    public void submitList(List<TransactionRow> newRows) {
        rows = newRows != null ? newRows : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction_full, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TransactionRow row = rows.get(position);
        holder.label.setText(row.label);
        holder.categoryDate.setText(row.category + " · " + DateFormat.format("d MMM", row.date));
        holder.badgeFixed.setVisibility(row.isFixed ? View.VISIBLE : View.GONE);

        int color = ContextCompat.getColor(holder.itemView.getContext(),
                row.isRevenue ? R.color.eg_green_positive : R.color.eg_red_negative);
        int pale = ContextCompat.getColor(holder.itemView.getContext(),
                row.isRevenue ? R.color.eg_green_pale_bg : R.color.eg_red_pale_bg);

        String sign = row.isRevenue ? "+" : "-";
        holder.amount.setText(sign + CurrencyFormatter.formatAbbreviated(Math.abs(row.amount)));
        holder.amount.setTextColor(color);
        holder.iconBg.setBackgroundTintList(ColorStateList.valueOf(pale));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView label, categoryDate, amount, badgeFixed;
        View iconBg;

        ViewHolder(View itemView) {
            super(itemView);
            label = itemView.findViewById(R.id.text_label);
            categoryDate = itemView.findViewById(R.id.text_category_date);
            amount = itemView.findViewById(R.id.text_amount);
            badgeFixed = itemView.findViewById(R.id.text_badge_fixed);
            iconBg = itemView.findViewById(R.id.view_icon_bg);
        }
    }
}
