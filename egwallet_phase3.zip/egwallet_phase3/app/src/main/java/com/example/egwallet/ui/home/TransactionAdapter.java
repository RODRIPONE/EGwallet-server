package com.example.egwallet.ui.home;

import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.util.CurrencyFormatter;

import java.util.ArrayList;
import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    private List<TransactionItem> items = new ArrayList<>();

    public void submitList(List<TransactionItem> newItems) {
        items = newItems != null ? newItems : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TransactionItem item = items.get(position);
        holder.label.setText(item.label);
        holder.category.setText(item.category);

        int color = ContextCompat.getColor(holder.itemView.getContext(),
                item.isRevenue ? R.color.eg_green_positive : R.color.eg_red_negative);
        int pale = ContextCompat.getColor(holder.itemView.getContext(),
                item.isRevenue ? R.color.eg_green_pale_bg : R.color.eg_red_pale_bg);

        String sign = item.isRevenue ? "+" : "-";
        holder.amount.setText(sign + CurrencyFormatter.formatAbbreviated(Math.abs(item.amount)));
        holder.amount.setTextColor(color);
        holder.iconBg.setBackgroundTintList(ColorStateList.valueOf(pale));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView label, category, amount;
        View iconBg;

        ViewHolder(View itemView) {
            super(itemView);
            label = itemView.findViewById(R.id.text_label);
            category = itemView.findViewById(R.id.text_category);
            amount = itemView.findViewById(R.id.text_amount);
            iconBg = itemView.findViewById(R.id.view_icon_bg);
        }
    }
}
