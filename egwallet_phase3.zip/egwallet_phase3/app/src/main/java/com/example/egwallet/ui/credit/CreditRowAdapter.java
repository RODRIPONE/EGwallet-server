package com.example.egwallet.ui.credit;

import android.content.res.ColorStateList;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.util.CurrencyFormatter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Adapter generique : affiche une liste de dettes OU de dus (convertis en CreditRow).
// Le statut "En retard" est calcule a l'affichage (echeance passee + non soldee) sans
// modifier la valeur persistee en base -- voir note dans CreditFragment.
public class CreditRowAdapter extends RecyclerView.Adapter<CreditRowAdapter.ViewHolder> {

    public interface OnRowClickListener {
        void onRowClick(long id);
    }

    public static class CreditRow {
        public final long id;
        public final String name;
        public final Date dueDate;
        public final double initialAmount;
        public final double remainingAmount;
        public final String storedStatus;

        public CreditRow(long id, String name, Date dueDate, double initialAmount,
                          double remainingAmount, String storedStatus) {
            this.id = id;
            this.name = name;
            this.dueDate = dueDate;
            this.initialAmount = initialAmount;
            this.remainingAmount = remainingAmount;
            this.storedStatus = storedStatus;
        }

        public boolean isFullyPaid() {
            return remainingAmount <= 0.0001;
        }

        public boolean isLate() {
            return !isFullyPaid() && dueDate.before(new Date());
        }

        public int getProgressPercent() {
            if (initialAmount <= 0) return 0;
            double paid = initialAmount - remainingAmount;
            return (int) Math.min(100, Math.max(0, (paid / initialAmount) * 100.0));
        }
    }

    private List<CreditRow> rows = new ArrayList<>();
    private final OnRowClickListener listener;

    public CreditRowAdapter(OnRowClickListener listener) {
        this.listener = listener;
    }

    public void submitList(List<CreditRow> newRows) {
        rows = newRows != null ? newRows : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_credit_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CreditRow row = rows.get(position);
        holder.name.setText(row.name);
        holder.dueDate.setText("Échéance : " + DateFormat.format("d MMM yyyy", row.dueDate));
        holder.remainingAmount.setText(row.isFullyPaid()
                ? "Soldé ✓"
                : CurrencyFormatter.formatFull(row.remainingAmount));
        holder.initialAmount.setText(CurrencyFormatter.formatAbbreviated(row.initialAmount));
        holder.progress.setProgress(row.getProgressPercent());
        holder.progressPercent.setText(row.getProgressPercent() + "% remboursé");

        String badgeText;
        int badgeColor;
        int badgeBg;
        if (row.isFullyPaid()) {
            badgeText = "Soldée ✓";
            badgeColor = R.color.eg_green_positive;
            badgeBg = R.color.eg_green_pale_bg;
        } else if (row.isLate()) {
            badgeText = "En retard";
            badgeColor = R.color.eg_red_negative;
            badgeBg = R.color.eg_red_pale_bg;
        } else if (Debt.STATUS_PARTIALLY_PAID.equals(row.storedStatus)) {
            badgeText = "Part. payée";
            badgeColor = R.color.eg_amber_pending;
            badgeBg = R.color.eg_amber_pale_bg;
        } else {
            badgeText = "Active";
            badgeColor = R.color.eg_gold_end;
            badgeBg = R.color.eg_amber_pale_bg;
        }
        holder.statusBadge.setText(badgeText);
        holder.statusBadge.setTextColor(holder.itemView.getContext().getColor(badgeColor));
        holder.statusBadge.setBackground(
                holder.itemView.getContext().getDrawable(R.drawable.bg_badge_fixed).mutate());
        holder.statusBadge.getBackground().setTintList(
                ColorStateList.valueOf(holder.itemView.getContext().getColor(badgeBg)));

        holder.itemView.setOnClickListener(v -> listener.onRowClick(row.id));
    }

    @Override
    public int getItemCount() {
        return rows.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, dueDate, remainingAmount, initialAmount, statusBadge, progressPercent;
        ProgressBar progress;

        ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.text_name);
            dueDate = itemView.findViewById(R.id.text_due_date);
            remainingAmount = itemView.findViewById(R.id.text_remaining_amount);
            initialAmount = itemView.findViewById(R.id.text_initial_amount);
            statusBadge = itemView.findViewById(R.id.text_status_badge);
            progress = itemView.findViewById(R.id.progress_repayment);
            progressPercent = itemView.findViewById(R.id.text_progress_percent);
        }
    }
}
