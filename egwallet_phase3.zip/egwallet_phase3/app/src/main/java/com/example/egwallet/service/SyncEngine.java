package com.example.egwallet.service;

import android.app.Application;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.util.Log;

import com.example.egwallet.data.entity.SyncQueueEvent;
import com.example.egwallet.data.repository.SyncQueueRepository;

import java.util.List;

// Stub (cahier des charges section 11) : lit la sync_queue et "envoie" chaque evenement
// pending si une connexion est disponible. Aucun appel reseau reel dans cette iteration -
// l'envoi est simule/logge, en attendant un futur backend EgWallet.
//
// IMPORTANT : processQueue() fait des requetes Room synchrones. Appelle-la depuis un
// thread de fond, par ex. AppExecutors.getInstance().diskIO().execute(syncEngine::processQueue).
public class SyncEngine {

    private static final String TAG = "SyncEngine";

    private final Application application;
    private final SyncQueueRepository syncQueueRepository;

    public SyncEngine(Application application) {
        this.application = application;
        this.syncQueueRepository = new SyncQueueRepository(application);
    }

    public void processQueue() {
        if (!isNetworkAvailable()) {
            Log.d(TAG, "Pas de connexion : les evenements restent en attente (pending)");
            return;
        }
        List<SyncQueueEvent> pending = syncQueueRepository.getPendingSync();
        for (SyncQueueEvent event : pending) {
            sendToBackendStub(event);
            syncQueueRepository.markSynced(event);
        }
    }

    // TODO (phase future) : remplacer par un vrai appel API vers le backend EgWallet.
    private void sendToBackendStub(SyncQueueEvent event) {
        Log.d(TAG, "Envoi simule -> " + event.getEventType()
                + " (entite #" + event.getRelatedEntityId() + ")");
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager)
                application.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        NetworkCapabilities capabilities = cm.getNetworkCapabilities(cm.getActiveNetwork());
        return capabilities != null
                && (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                    || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
    }
}
