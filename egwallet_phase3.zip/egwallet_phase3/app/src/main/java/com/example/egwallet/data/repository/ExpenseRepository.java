package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.ExpenseDao;
import com.example.egwallet.data.entity.Expense;

import java.util.Date;
import java.util.List;

public class ExpenseRepository {

    private final ExpenseDao expenseDao;

    public ExpenseRepository(Application application) {
        expenseDao = AppDatabase.getInstance(application).expenseDao();
    }

    public LiveData<List<Expense>> getAll() {
        return expenseDao.getAll();
    }

    public LiveData<List<Expense>> getBetween(Date start, Date end) {
        return expenseDao.getBetween(start, end);
    }

    public LiveData<Double> getTotalBetween(Date start, Date end) {
        return expenseDao.getTotalBetween(start, end);
    }

    // Version synchrone : a appeler uniquement depuis un thread de fond (AppExecutors)
    public double getTotalBetweenSync(Date start, Date end) {
        return expenseDao.getTotalBetweenSync(start, end);
    }

    public LiveData<List<ExpenseDao.CategoryTotal>> getTotalsByCategory(Date start, Date end) {
        return expenseDao.getTotalsByCategory(start, end);
    }

    public void insert(Expense expense) {
        AppExecutors.getInstance().diskIO().execute(() -> expenseDao.insert(expense));
    }

    public void update(Expense expense) {
        AppExecutors.getInstance().diskIO().execute(() -> expenseDao.update(expense));
    }

    public void delete(Expense expense) {
        AppExecutors.getInstance().diskIO().execute(() -> expenseDao.delete(expense));
    }
}
