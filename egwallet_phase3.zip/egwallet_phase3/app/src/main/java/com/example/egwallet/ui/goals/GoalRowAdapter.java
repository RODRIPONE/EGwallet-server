package com.example.egwallet.ui.goals;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.util.CurrencyFormatter;
import com.example.egwallet.util.DateUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class GoalRowAdapter extends RecyclerView.Adapter<GoalRowAdapter.ViewHolder> {

    public interface OnRowClickListener {
        void onRowClick(Goal goal);
    }

    private List<Goal> goals = new ArrayList<>();
    private final OnRowClickListener listener;

    public GoalRowAdapter(OnRowClickListener listener) {
        this.listener = listener;
    }

    public void submitList(List<Goal> newGoals) {
        goals = newGoals != null ? newGoals : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_goal_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Goal goal = goals.get(position);
        holder.emoji.setText(goal.getEmoji());
        holder.title.setText(goal.getTitle());
        int percent = (int) goal.getProgressPercentage();
        holder.percent.setText(percent + "%");
        holder.progress.setProgress(percent);
        holder.amounts.setText(CurrencyFormatter.formatAbbreviated(goal.getCurrentAmount())
                + " / " + CurrencyFormatter.formatAbbreviated(goal.getTargetAmount()));

        int months = DateUtils.monthsBetween(new Date(), goal.getDeadline());
        holder.monthsRemaining.setText(months + " mois restants");

        holder.itemView.setOnClickListener(v -> listener.onRowClick(goal));
    }

    @Override
    public int getItemCount() {
        return goals.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView emoji, title, percent, amounts, monthsRemaining;
        ProgressBar progress;

        ViewHolder(View itemView) {
            super(itemView);
            emoji = itemView.findViewById(R.id.text_emoji);
            title = itemView.findViewById(R.id.text_title);
            percent = itemView.findViewById(R.id.text_percent);
            amounts = itemView.findViewById(R.id.text_amounts);
            monthsRemaining = itemView.findViewById(R.id.text_months_remaining);
            progress = itemView.findViewById(R.id.progress_goal);
        }
    }
}
