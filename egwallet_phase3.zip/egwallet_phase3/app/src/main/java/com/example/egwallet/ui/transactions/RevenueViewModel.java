package com.example.egwallet.ui.transactions;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.data.repository.RevenueRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

/**
 * RevenueViewModel — Phase 3 : API-first.
 *
 * Toutes les mutations (create/update/delete) passent par l'API backend.
 * La liste observée provient du cache Room, mis à jour par le repository après chaque succès API.
 *
 * Pattern identique à LockViewModel (Phase 2) :
 *   isLoading → spinner pendant l'appel réseau
 *   saved     → fermer le bottom sheet en cas de succès
 *   errorMessage → afficher l'erreur à l'utilisateur
 */
public class RevenueViewModel extends AndroidViewModel {

    private final RevenueRepository revenueRepository;

    private final MutableLiveData<Event<String>>  errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved        = new MutableLiveData<>();
    private final MutableLiveData<Boolean>        isLoading    = new MutableLiveData<>(false);

    public RevenueViewModel(@NonNull Application application) {
        super(application);
        revenueRepository = new RevenueRepository(application);
    }

    // ── LiveData observables ──────────────────────────────────────────────────

    public LiveData<List<Revenue>> getAll()                   { return revenueRepository.getAll(); }
    public LiveData<Event<String>> getErrorMessage()          { return errorMessage; }
    public LiveData<Event<Boolean>> getSaved()                { return saved; }
    public LiveData<Boolean> getIsLoading()                   { return isLoading; }

    // ── CREATE ────────────────────────────────────────────────────────────────

    public void addRevenue(String rawAmount, String source, String category, Date date, String notes) {
        // Validation locale avant appel réseau
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) { errorMessage.setValue(new Event<>(amountError)); return; }

        String sourceError = ValidationUtils.validateText(source, "La source");
        if (sourceError != null) { errorMessage.setValue(new Event<>(sourceError)); return; }

        String dateError = ValidationUtils.validatePastOrTodayDate(date);
        if (dateError != null) { errorMessage.setValue(new Event<>(dateError)); return; }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        isLoading.setValue(true);

        revenueRepository.createRevenue(amount, source.trim(), category, date, notes,
                new RevenueRepository.RevenueCallback() {
                    @Override
                    public void onSuccess() {
                        isLoading.postValue(false);
                        saved.postValue(new Event<>(true));
                    }
                    @Override
                    public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * @param revenue entité Room existante (contient l'ID backend aligné à la création)
     */
    public void updateRevenue(Revenue revenue, String rawAmount, String source, String category) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) { errorMessage.setValue(new Event<>(amountError)); return; }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        isLoading.setValue(true);

        revenueRepository.updateRevenue(revenue.getId(), amount, source.trim(), category,
                new RevenueRepository.RevenueCallback() {
                    @Override
                    public void onSuccess() {
                        isLoading.postValue(false);
                        saved.postValue(new Event<>(true));
                    }
                    @Override
                    public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    public void deleteRevenue(Revenue revenue) {
        isLoading.setValue(true);
        revenueRepository.deleteRevenue(revenue.getId(),
                new RevenueRepository.RevenueCallback() {
                    @Override
                    public void onSuccess() {
                        isLoading.postValue(false);
                    }
                    @Override
                    public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }
}
