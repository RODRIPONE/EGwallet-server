package com.example.egwallet.ui.credit;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.repository.DebtRepository;
import com.example.egwallet.service.NotificationHelper;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

// Couvre "Enregistrer une dette", "Consulter solde dette restant", "Consulter historique
// des remboursements" et le diagramme d'activite complet "RembourserDette".
public class DebtViewModel extends AndroidViewModel {

    private final DebtRepository debtRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> repaymentSuccess = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public DebtViewModel(@NonNull Application application) {
        super(application);
        debtRepository = new DebtRepository(application);
    }

    public LiveData<List<DebtDao.DebtWithRemaining>> getAllWithRemaining() {
        return debtRepository.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return debtRepository.getTotalRemaining();
    }

    public LiveData<Debt> getDebt(long id) {
        return debtRepository.getById(id);
    }

    public LiveData<List<DebtPayment>> getPayments(long debtId) {
        return debtRepository.getPaymentsForDebt(debtId);
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Event<Boolean>> getRepaymentSuccess() {
        return repaymentSuccess;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    // Cas d'usage "Enregistrer une dette"
    public void createDebt(String creditor, String rawAmount, String reason, Date dueDate, String notes) {
        String creditorError = ValidationUtils.validateText(creditor, "Le créancier");
        if (creditorError != null) {
            errorMessage.setValue(new Event<>(creditorError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        Debt debt = new Debt(amount, creditor.trim(), reason, dueDate, notes, Debt.STATUS_ACTIVE);
        debtRepository.insert(debt);
        saved.setValue(new Event<>(true));
    }

    // Diagramme d'activite "RembourserDette" complet (validation -> DebtPayment -> statut
    // -> sync_queue -> notification si la dette devient soldee).
    public void repayDebt(long debtId, String rawAmount, String creditorName) {
        String amountFormatError = ValidationUtils.validateAmount(rawAmount);
        if (amountFormatError != null) {
            errorMessage.setValue(new Event<>(amountFormatError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));

        debtRepository.repayDebt(debtId, amount, new DebtRepository.RepaymentCallback() {
            @Override
            public void onSuccess(boolean fullyPaid) {
                repaymentSuccess.postValue(new Event<>(true));
                if (fullyPaid) {
                    NotificationHelper.showDebtPaidNotification(getApplication(), creditorName);
                }
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    public void deleteDebt(Debt debt) {
        debtRepository.delete(debt);
    }
}
