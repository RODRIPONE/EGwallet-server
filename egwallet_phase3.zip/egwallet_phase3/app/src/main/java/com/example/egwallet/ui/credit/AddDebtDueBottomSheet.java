package com.example.egwallet.ui.credit;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Calendar;
import java.util.Date;

// Bottom sheet partagee "Enregistrer une dette" / "Enregistrer un du". ViewModels scopes
// au Fragment parent (CreditFragment) pour que la liste se rafraichisse automatiquement.
public class AddDebtDueBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_IS_DEBT = "is_debt";

    public static AddDebtDueBottomSheet newInstance(boolean isDebt) {
        AddDebtDueBottomSheet sheet = new AddDebtDueBottomSheet();
        Bundle args = new Bundle();
        args.putBoolean(ARG_IS_DEBT, isDebt);
        sheet.setArguments(args);
        return sheet;
    }

    private DebtViewModel debtViewModel;
    private DueViewModel dueViewModel;
    private boolean isDebt;
    // Echeance par defaut : dans 30 jours (une dette/un du a generalement une echeance future)
    private Date selectedDate = new Date(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000);

    private EditText editName, editAmount, editReason, editNotes;
    private TextView textDate, textError, textSheetTitle, textNameField;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isDebt = getArguments() == null || getArguments().getBoolean(ARG_IS_DEBT, true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_add_debt_due, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        debtViewModel = new ViewModelProvider(requireParentFragment()).get(DebtViewModel.class);
        dueViewModel = new ViewModelProvider(requireParentFragment()).get(DueViewModel.class);

        textSheetTitle = view.findViewById(R.id.text_sheet_title);
        textNameField = view.findViewById(R.id.text_name_field);
        editName = view.findViewById(R.id.edit_name);
        editAmount = view.findViewById(R.id.edit_amount);
        editReason = view.findViewById(R.id.edit_reason);
        editNotes = view.findViewById(R.id.edit_notes);
        textDate = view.findViewById(R.id.text_date);
        textError = view.findViewById(R.id.text_error);

        textSheetTitle.setText(isDebt ? "Enregistrer une dette" : "Enregistrer un dû");
        textNameField.setText(isDebt ? "CRÉANCIER" : "DÉBITEUR");

        updateDateText();
        textDate.setOnClickListener(v -> showDatePicker());
        view.findViewById(R.id.button_close).setOnClickListener(v -> dismiss());
        view.findViewById(R.id.button_save).setOnClickListener(v -> onSaveClicked());

        debtViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null && isDebt) showError(message);
        });
        debtViewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (isDebt && Boolean.TRUE.equals(event.getContentIfNotHandled())) dismiss();
        });
        dueViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null && !isDebt) showError(message);
        });
        dueViewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (!isDebt && Boolean.TRUE.equals(event.getContentIfNotHandled())) dismiss();
        });
    }

    private void showError(String message) {
        textError.setVisibility(View.VISIBLE);
        textError.setText(message);
    }

    private void updateDateText() {
        textDate.setText(DateFormat.format("dd/MM/yyyy", selectedDate));
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);
        new DatePickerDialog(requireContext(), (picker, year, month, day) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year, month, day);
            selectedDate = picked.getTime();
            updateDateText();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void onSaveClicked() {
        textError.setVisibility(View.GONE);
        String name = editName.getText().toString();
        String amount = editAmount.getText().toString();
        String reason = editReason.getText().toString();
        String notes = editNotes.getText().toString();

        if (isDebt) {
            debtViewModel.createDebt(name, amount, reason, selectedDate, notes);
        } else {
            dueViewModel.createDue(name, amount, reason, selectedDate, notes);
        }
    }
}
