package com.example.egwallet.ui.home;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.repository.ExpenseRepository;
import com.example.egwallet.data.repository.GoalRepository;
import com.example.egwallet.data.repository.RevenueRepository;
import com.example.egwallet.data.repository.UserRepository;
import com.example.egwallet.service.FinancialSummaryService;
import com.example.egwallet.util.DateUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Alimente HomeFragment : salutation, solde disponible, bilan du mois, cartes resume
// (Dettes/Dus/Epargne), objectif principal, transactions recentes.
public class HomeViewModel extends AndroidViewModel {

    private final FinancialSummaryService financialSummaryService;
    private final UserRepository userRepository;
    private final RevenueRepository revenueRepository;
    private final ExpenseRepository expenseRepository;
    private final GoalRepository goalRepository;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        financialSummaryService = new FinancialSummaryService(application);
        userRepository = new UserRepository(application);
        revenueRepository = new RevenueRepository(application);
        expenseRepository = new ExpenseRepository(application);
        goalRepository = new GoalRepository(application);
    }

    public LiveData<User> getCurrentUser() {
        return userRepository.getCurrentUser();
    }

    // "Solde disponible" : cumule depuis toujours
    public LiveData<Double> getRunningBalance() {
        return financialSummaryService.getRunningBalance();
    }

    // "Bilan {mois}" : revenus - depenses du mois en cours uniquement
    public LiveData<Double> getCurrentMonthBalance() {
        Date now = new Date();
        return financialSummaryService.getPeriodBalance(
                DateUtils.startOfMonth(now), DateUtils.endOfMonth(now));
    }

    public LiveData<Double> getTotalDebtsRemaining() {
        return financialSummaryService.getTotalDebtsRemaining();
    }

    public LiveData<Double> getTotalDuesRemaining() {
        return financialSummaryService.getTotalDuesRemaining();
    }

    public LiveData<Double> getTotalSavings() {
        return financialSummaryService.getTotalSavings();
    }

    // HomeFragment choisit l'objectif a afficher (echeance la plus proche, deja trie par
    // GoalDao.getAll() qui ORDER BY deadline ASC) : le premier de la liste est le principal.
    public LiveData<List<Goal>> getGoals() {
        return goalRepository.getAll();
    }

    public LiveData<List<Revenue>> getRecentRevenues() {
        return revenueRepository.getAll();
    }

    public LiveData<List<Expense>> getRecentExpenses() {
        return expenseRepository.getAll();
    }

    // Fusionne Revenue + Expense en une liste unique triee par date desc, limitee aux
    // 4 dernieres (liste "Recentes" du Home). Purement UI : TransactionItem n'est pas
    // une entity Room.
    public LiveData<List<TransactionItem>> getRecentTransactions() {
        MediatorLiveData<List<TransactionItem>> result = new MediatorLiveData<>();
        LiveData<List<Revenue>> revenues = revenueRepository.getAll();
        LiveData<List<Expense>> expenses = expenseRepository.getAll();

        Runnable combine = () -> {
            List<Revenue> rev = revenues.getValue();
            List<Expense> exp = expenses.getValue();
            if (rev == null || exp == null) return;

            List<TransactionItem> merged = new ArrayList<>();
            for (Revenue r : rev) {
                merged.add(new TransactionItem(r.getId(), r.getAmount(), r.getSource(),
                        r.getCategory(), r.getDate(), true));
            }
            for (Expense e : exp) {
                merged.add(new TransactionItem(e.getId(), -e.getAmount(), e.getReason(),
                        e.getCategory(), e.getDate(), false));
            }
            merged.sort((a, b) -> b.date.compareTo(a.date));
            result.setValue(merged.size() > 4 ? merged.subList(0, 4) : merged);
        };

        result.addSource(revenues, v -> combine.run());
        result.addSource(expenses, v -> combine.run());
        return result;
    }
}
