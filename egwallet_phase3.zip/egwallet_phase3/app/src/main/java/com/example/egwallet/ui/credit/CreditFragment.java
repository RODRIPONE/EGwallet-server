package com.example.egwallet.ui.credit;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.util.CurrencyFormatter;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

// Ecran "Credit" : toggle Dettes/Dus, cartes resume, liste avec progression, FAB.
public class CreditFragment extends Fragment {

    private DebtViewModel debtViewModel;
    private DueViewModel dueViewModel;
    private CreditRowAdapter adapter;
    private boolean showingDebts = true;

    private TextView textSummaryRemaining, textSummaryPaid, textSummaryLate;

    public CreditFragment() {
        super(R.layout.fragment_credit);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        debtViewModel = new ViewModelProvider(this).get(DebtViewModel.class);
        dueViewModel = new ViewModelProvider(this).get(DueViewModel.class);

        textSummaryRemaining = view.findViewById(R.id.text_summary_remaining);
        textSummaryPaid = view.findViewById(R.id.text_summary_paid);
        textSummaryLate = view.findViewById(R.id.text_summary_late);
        RecyclerView recycler = view.findViewById(R.id.recycler_credit);

        adapter = new CreditRowAdapter(id -> {
            RepayBottomSheet sheet = RepayBottomSheet.newInstance(showingDebts, id);
            sheet.show(getChildFragmentManager(), "repay");
        });
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setAdapter(adapter);

        MaterialButtonToggleGroup toggleGroup = view.findViewById(R.id.toggle_group);
        toggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            showingDebts = checkedId == R.id.button_debts;
            render();
        });

        debtViewModel.getAllWithRemaining().observe(getViewLifecycleOwner(), debts -> {
            if (showingDebts) render();
        });
        dueViewModel.getAllWithRemaining().observe(getViewLifecycleOwner(), dues -> {
            if (!showingDebts) render();
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> {
            AddDebtDueBottomSheet sheet = AddDebtDueBottomSheet.newInstance(showingDebts);
            sheet.show(getChildFragmentManager(), "add_debt_due");
        });

        render();
    }

    private void render() {
        if (showingDebts) {
            List<DebtDao.DebtWithRemaining> debts = debtViewModel.getAllWithRemaining().getValue();
            renderDebts(debts != null ? debts : new ArrayList<>());
        } else {
            List<DueDao.DueWithRemaining> dues = dueViewModel.getAllWithRemaining().getValue();
            renderDues(dues != null ? dues : new ArrayList<>());
        }
    }

    private void renderDebts(List<DebtDao.DebtWithRemaining> debts) {
        List<CreditRowAdapter.CreditRow> rows = new ArrayList<>();
        double totalRemaining = 0;
        int paidCount = 0;
        int lateCount = 0;
        for (DebtDao.DebtWithRemaining d : debts) {
            CreditRowAdapter.CreditRow row = new CreditRowAdapter.CreditRow(
                    d.id, d.creditor, d.dueDate, d.initialAmount, d.getRemainingAmount(), d.status);
            rows.add(row);
            if (row.isFullyPaid()) paidCount++;
            else totalRemaining += row.remainingAmount;
            if (row.isLate()) lateCount++;
        }
        adapter.submitList(rows);
        textSummaryRemaining.setText(CurrencyFormatter.formatAbbreviated(totalRemaining));
        textSummaryPaid.setText(String.valueOf(paidCount));
        textSummaryLate.setText(String.valueOf(lateCount));
    }

    private void renderDues(List<DueDao.DueWithRemaining> dues) {
        List<CreditRowAdapter.CreditRow> rows = new ArrayList<>();
        double totalRemaining = 0;
        int paidCount = 0;
        int lateCount = 0;
        for (DueDao.DueWithRemaining d : dues) {
            CreditRowAdapter.CreditRow row = new CreditRowAdapter.CreditRow(
                    d.id, d.debtorName, d.dueDate, d.initialAmount, d.getRemainingAmount(), d.status);
            rows.add(row);
            if (row.isFullyPaid()) paidCount++;
            else totalRemaining += row.remainingAmount;
            if (row.isLate()) lateCount++;
        }
        adapter.submitList(rows);
        textSummaryRemaining.setText(CurrencyFormatter.formatAbbreviated(totalRemaining));
        textSummaryPaid.setText(String.valueOf(paidCount));
        textSummaryLate.setText(String.valueOf(lateCount));
    }
}
