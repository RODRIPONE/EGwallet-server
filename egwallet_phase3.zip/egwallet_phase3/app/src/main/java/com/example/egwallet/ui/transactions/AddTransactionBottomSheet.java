package com.example.egwallet.ui.transactions;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.FixedExpense;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

// Bottom sheet partagee "Ajouter un revenu" / "Ajouter une depense" (le mode change les
// libelles et affiche/masque le raccourci "depense fixe"). Les ViewModels sont scopes au
// Fragment PARENT (TransactionsFragment) via requireParentFragment(), pour que la liste
// se mette a jour automatiquement des l'insertion (meme instance de ViewModel partagee).
public class AddTransactionBottomSheet extends BottomSheetDialogFragment {

    private static final String ARG_IS_EXPENSE = "is_expense";

    public static AddTransactionBottomSheet newInstance(boolean isExpense) {
        AddTransactionBottomSheet sheet = new AddTransactionBottomSheet();
        Bundle args = new Bundle();
        args.putBoolean(ARG_IS_EXPENSE, isExpense);
        sheet.setArguments(args);
        return sheet;
    }

    private ExpenseViewModel expenseViewModel;
    private RevenueViewModel revenueViewModel;
    private boolean isExpense;
    private Date selectedDate = new Date();

    private EditText editAmount, editLabel, editNotes;
    private Spinner spinnerCategory;
    private TextView textDate, textError, textSheetTitle, textLabelField, textPickFixed;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        isExpense = getArguments() != null && getArguments().getBoolean(ARG_IS_EXPENSE, true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.bottom_sheet_add_transaction, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        expenseViewModel = new ViewModelProvider(requireParentFragment()).get(ExpenseViewModel.class);
        revenueViewModel = new ViewModelProvider(requireParentFragment()).get(RevenueViewModel.class);

        textSheetTitle = view.findViewById(R.id.text_sheet_title);
        textLabelField = view.findViewById(R.id.text_label_field);
        textPickFixed = view.findViewById(R.id.text_pick_fixed);
        editAmount = view.findViewById(R.id.edit_amount);
        editLabel = view.findViewById(R.id.edit_label);
        editNotes = view.findViewById(R.id.edit_notes);
        spinnerCategory = view.findViewById(R.id.spinner_category);
        textDate = view.findViewById(R.id.text_date);
        textError = view.findViewById(R.id.text_error);

        int categoriesRes = isExpense ? R.array.expense_categories : R.array.revenue_categories;
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(
                requireContext(), categoriesRes, android.R.layout.simple_spinner_dropdown_item);
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategory.setAdapter(categoryAdapter);

        textSheetTitle.setText(isExpense ? "Ajouter une dépense" : "Ajouter un revenu");
        textLabelField.setText(isExpense ? "MOTIF" : "SOURCE");
        textPickFixed.setVisibility(isExpense ? View.VISIBLE : View.GONE);

        updateDateText();
        textDate.setOnClickListener(v -> showDatePicker());
        textPickFixed.setOnClickListener(v -> showFixedExpensePicker());
        view.findViewById(R.id.button_close).setOnClickListener(v -> dismiss());
        view.findViewById(R.id.button_save).setOnClickListener(v -> onSaveClicked());

        // Observers enregistres UNE SEULE FOIS ici (pas dans onSaveClicked, pour eviter
        // les observers dupliques si l'utilisateur clique plusieurs fois sur Enregistrer).
        expenseViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null && isExpense) showError(message);
        });
        expenseViewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (isExpense && Boolean.TRUE.equals(event.getContentIfNotHandled())) dismiss();
        });
        revenueViewModel.getErrorMessage().observe(getViewLifecycleOwner(), event -> {
            String message = event.getContentIfNotHandled();
            if (message != null && !isExpense) showError(message);
        });
        revenueViewModel.getSaved().observe(getViewLifecycleOwner(), event -> {
            if (!isExpense && Boolean.TRUE.equals(event.getContentIfNotHandled())) dismiss();
        });
    }

    private void showError(String message) {
        textError.setVisibility(View.VISIBLE);
        textError.setText(message);
    }

    private void updateDateText() {
        textDate.setText(DateFormat.format("dd/MM/yyyy", selectedDate));
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedDate);
        new DatePickerDialog(requireContext(), (picker, year, month, day) -> {
            Calendar picked = Calendar.getInstance();
            picked.set(year, month, day);
            selectedDate = picked.getTime();
            updateDateText();
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void showFixedExpensePicker() {
        List<FixedExpense> fixedExpenses = expenseViewModel.getAllFixedExpenses().getValue();
        if (fixedExpenses == null || fixedExpenses.isEmpty()) {
            showError("Aucune dépense fixe enregistrée pour l'instant");
            return;
        }
        String[] labels = new String[fixedExpenses.size()];
        for (int i = 0; i < fixedExpenses.size(); i++) {
            FixedExpense fe = fixedExpenses.get(i);
            labels[i] = fe.getLabel() + " — " + (int) fe.getAmount() + " FCFA";
        }
        new AlertDialog.Builder(requireContext())
                .setTitle("Choisir une dépense fixe")
                .setItems(labels, (dialog, which) -> {
                    expenseViewModel.addExpenseFromFixed(fixedExpenses.get(which), selectedDate);
                    dismiss();
                })
                .show();
    }

    private void onSaveClicked() {
        textError.setVisibility(View.GONE);
        String amount = editAmount.getText().toString();
        String label = editLabel.getText().toString();
        String category = String.valueOf(spinnerCategory.getSelectedItem());
        String notes = editNotes.getText().toString();

        if (isExpense) {
            expenseViewModel.addExpense(amount, label, category, selectedDate, notes);
        } else {
            revenueViewModel.addRevenue(amount, label, category, selectedDate, notes);
        }
    }
}
