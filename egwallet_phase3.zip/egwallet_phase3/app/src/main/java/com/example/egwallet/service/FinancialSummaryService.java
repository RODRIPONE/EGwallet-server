package com.example.egwallet.service;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.model.Report;

import java.util.Date;

// Classe de service (PAS une entite Room) qui calcule les agregats financiers a la demande,
// comme decrit dans le cahier des charges section 3 (FinancialSummary).
public class FinancialSummaryService {

    private final AppDatabase db;

    public FinancialSummaryService(Application application) {
        db = AppDatabase.getInstance(application);
    }

    // "Solde disponible" du Home : cumule depuis toujours (total revenus - total depenses)
    public LiveData<Double> getRunningBalance() {
        return combineBalance(db.revenueDao().getTotalAll(), db.expenseDao().getTotalAll());
    }

    // "Bilan {mois}" : revenus - depenses sur une periode donnee uniquement
    public LiveData<Double> getPeriodBalance(Date start, Date end) {
        return combineBalance(
                db.revenueDao().getTotalBetween(start, end),
                db.expenseDao().getTotalBetween(start, end));
    }

    private LiveData<Double> combineBalance(LiveData<Double> totalRevenue, LiveData<Double> totalExpense) {
        MediatorLiveData<Double> result = new MediatorLiveData<>();
        Runnable combine = () -> {
            Double rev = totalRevenue.getValue();
            Double exp = totalExpense.getValue();
            if (rev != null && exp != null) {
                result.setValue(rev - exp);
            }
        };
        result.addSource(totalRevenue, v -> combine.run());
        result.addSource(totalExpense, v -> combine.run());
        return result;
    }

    // Carte "Dettes" du Home : somme des soldes restants sur toutes les dettes
    public LiveData<Double> getTotalDebtsRemaining() {
        return db.debtDao().getTotalRemaining();
    }

    // Carte "Dus" du Home : somme des soldes restants sur tous les dus
    public LiveData<Double> getTotalDuesRemaining() {
        return db.dueDao().getTotalRemaining();
    }

    // Carte "Epargne" du Home : somme de l'epargne deja accumulee sur tous les objectifs
    public LiveData<Double> getTotalSavings() {
        return db.goalDao().getTotalCurrentAmount();
    }

    // Genere un rapport pour une periode donnee. A appeler depuis un thread de fond
    // (voir ReportService / StatsViewModel) : fait des requetes Room synchrones.
    public Report getMonthlyReportSync(Date periodStart, Date periodEnd) {
        double totalRevenues = db.revenueDao().getTotalBetweenSync(periodStart, periodEnd);
        double totalExpenses = db.expenseDao().getTotalBetweenSync(periodStart, periodEnd);
        double balance = totalRevenues - totalExpenses;
        double savingsRate = totalRevenues > 0 ? (balance / totalRevenues) * 100.0 : 0;
        return new Report(periodStart, periodEnd, totalRevenues, totalExpenses, balance, savingsRate);
    }
}
