package com.example.egwallet.service;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

// Notification locale declenchee quand une dette/du est entierement solde(e)
// (diagramme d'activite RembourserDette, etape 8). Necessite la permission
// POST_NOTIFICATIONS sur Android 13+ : a demander depuis l'Activity en Phase 3
// (ActivityCompat.requestPermissions). Si non accordee, on n'affiche simplement rien.
public class NotificationHelper {

    private static final String CHANNEL_ID = "egwallet_debts";
    private static final int NOTIFICATION_ID_DEBT_PAID = 1001;
    private static final int NOTIFICATION_ID_DUE_RECEIVED = 1002;

    public static void createChannelIfNeeded(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Dettes et dus",
                    NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Alertes de remboursement de dettes et de dus");
            NotificationManager manager = context.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public static void showDebtPaidNotification(Context context, String creditorName) {
        if (!hasNotificationPermission(context)) return;
        createChannelIfNeeded(context);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info) // remplace par l'icone de l'app en Phase 3
                .setContentTitle("Dette soldée \uD83C\uDF89")
                .setContentText("Ta dette envers " + creditorName + " est entièrement remboursée.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_DEBT_PAID, builder.build());
    }

    public static void showDuePaidNotification(Context context, String debtorName) {
        if (!hasNotificationPermission(context)) return;
        createChannelIfNeeded(context);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Dû reçu \uD83C\uDF89")
                .setContentText(debtorName + " t'a remboursé l'intégralité du montant dû.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_DUE_RECEIVED, builder.build());
    }

    private static boolean hasNotificationPermission(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return true; // pas necessaire avant Android 13
        }
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED;
    }
}
