package com.example.egwallet.ui.transactions;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.entity.FixedExpense;
import com.example.egwallet.data.repository.ExpenseRepository;
import com.example.egwallet.data.repository.FixedExpenseRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

// Reproduit exactement le diagramme de sequence "AjouterDepense" : valider -> repository.insert()
// -> confirmation (le solde/la liste se mettent a jour tout seuls via LiveData, sans
// rechargement manuel). Couvre aussi "Gerer depenses fixes" / "Selectionner une depense
// fixe existante" (extension UC12 -> UC8).
public class ExpenseViewModel extends AndroidViewModel {

    private final ExpenseRepository expenseRepository;
    private final FixedExpenseRepository fixedExpenseRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public ExpenseViewModel(@NonNull Application application) {
        super(application);
        expenseRepository = new ExpenseRepository(application);
        fixedExpenseRepository = new FixedExpenseRepository(application);
    }

    public LiveData<List<Expense>> getAll() {
        return expenseRepository.getAll();
    }

    public LiveData<List<FixedExpense>> getAllFixedExpenses() {
        return fixedExpenseRepository.getAll();
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    public void addExpense(String rawAmount, String reason, String category, Date date, String notes) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        String reasonError = ValidationUtils.validateText(reason, "Le motif");
        if (reasonError != null) {
            errorMessage.setValue(new Event<>(reasonError));
            return;
        }
        String dateError = ValidationUtils.validatePastOrTodayDate(date);
        if (dateError != null) {
            errorMessage.setValue(new Event<>(dateError));
            return;
        }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        Expense expense = new Expense(amount, reason.trim(), category, date, notes, false, null);
        expenseRepository.insert(expense);
        saved.setValue(new Event<>(true));
    }

    // Extension "Selectionner une depense fixe existante" : pre-remplit et enregistre a
    // partir d'une FixedExpense (FixedExpense.applyToExpense() construit l'objet Expense).
    public void addExpenseFromFixed(FixedExpense fixedExpense, Date date) {
        Expense expense = fixedExpense.applyToExpense(date);
        expenseRepository.insert(expense);
        saved.setValue(new Event<>(true));
    }

    public void createFixedExpense(String label, String rawAmount, String category, int recurrenceDay) {
        String labelError = ValidationUtils.validateText(label, "Le libellé");
        if (labelError != null) {
            errorMessage.setValue(new Event<>(labelError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        fixedExpenseRepository.insert(new FixedExpense(label.trim(), amount, category, recurrenceDay));
        saved.setValue(new Event<>(true));
    }

    public void updateExpense(Expense expense) {
        expenseRepository.update(expense);
    }

    public void deleteExpense(Expense expense) {
        expenseRepository.delete(expense);
    }
}
