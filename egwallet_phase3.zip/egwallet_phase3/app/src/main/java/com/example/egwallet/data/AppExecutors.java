package com.example.egwallet.data;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// Pool de threads unique pour toutes les ecritures Room (Room interdit les ecritures
// sur le thread principal). Un singleton simple suffit pour la taille de cette app.
public class AppExecutors {

    private static final AppExecutors INSTANCE = new AppExecutors();

    private final ExecutorService diskIO = Executors.newSingleThreadExecutor();

    private AppExecutors() {}

    public static AppExecutors getInstance() {
        return INSTANCE;
    }

    public ExecutorService diskIO() {
        return diskIO;
    }
}
