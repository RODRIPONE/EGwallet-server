package com.example.egwallet.data.repository;

import android.app.Application;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.SyncQueueDao;
import com.example.egwallet.data.entity.SyncQueueEvent;

import java.util.List;

public class SyncQueueRepository {

    private final SyncQueueDao syncQueueDao;

    public SyncQueueRepository(Application application) {
        syncQueueDao = AppDatabase.getInstance(application).syncQueueDao();
    }

    public void enqueue(SyncQueueEvent event) {
        AppExecutors.getInstance().diskIO().execute(() -> syncQueueDao.insert(event));
    }

    public List<SyncQueueEvent> getPendingSync() {
        return syncQueueDao.getByStatusSync(SyncQueueEvent.STATUS_PENDING);
    }

    public void markSynced(SyncQueueEvent event) {
        event.setStatus(SyncQueueEvent.STATUS_SYNCED);
        AppExecutors.getInstance().diskIO().execute(() -> syncQueueDao.update(event));
    }
}
