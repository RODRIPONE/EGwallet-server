package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.dao.DebtPaymentDao;
import com.example.egwallet.data.dao.SyncQueueDao;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.entity.SyncQueueEvent;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

public class DebtRepository {

    // Callback pour rapporter le resultat du remboursement (execute sur un thread de fond,
    // donc jamais de mise a jour LiveData directe ici : le ViewModel appelant utilise postValue).
    public interface RepaymentCallback {
        void onSuccess(boolean fullyPaid);
        void onError(String message);
    }

    private final AppDatabase db;
    private final DebtDao debtDao;
    private final DebtPaymentDao debtPaymentDao;
    private final SyncQueueDao syncQueueDao;

    public DebtRepository(Application application) {
        db = AppDatabase.getInstance(application);
        debtDao = db.debtDao();
        debtPaymentDao = db.debtPaymentDao();
        syncQueueDao = db.syncQueueDao();
    }

    public LiveData<List<DebtDao.DebtWithRemaining>> getAllWithRemaining() {
        return debtDao.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return debtDao.getTotalRemaining();
    }

    public LiveData<Debt> getById(long id) {
        return debtDao.getById(id);
    }

    public LiveData<List<DebtPayment>> getPaymentsForDebt(long debtId) {
        return debtPaymentDao.getForDebt(debtId);
    }

    public void insert(Debt debt) {
        AppExecutors.getInstance().diskIO().execute(() -> debtDao.insert(debt));
    }

    public void update(Debt debt) {
        AppExecutors.getInstance().diskIO().execute(() -> debtDao.update(debt));
    }

    public void delete(Debt debt) {
        AppExecutors.getInstance().diskIO().execute(() -> debtDao.delete(debt));
    }

    // Diagramme d'activite "RembourserDette" (cahier des charges section 6), etapes 2 a 9 :
    // 1) lecture fraiche du solde restant (jamais la valeur cachee de l'UI, pour eviter
    //    une validation basee sur une donnee perimee)
    // 2) validation montant <= 0 / montant > solde restant
    // 3) DebtPayment + statut + sync_queue inseres dans UNE transaction atomique
    // 4) callback de resultat (fullyPaid ou message d'erreur)
    // Le recalcul du FinancialSummary et la mise a jour du dashboard n'ont rien de special a
    // faire ici : ils se produisent automatiquement, les LiveData Room se re-emettent des que
    // les tables debt_payments/debts sont invalidees.
    public void repayDebt(long debtId, double amount, RepaymentCallback callback) {
        AppExecutors.getInstance().diskIO().execute(() -> {
            Debt debt = debtDao.getByIdSync(debtId);
            if (debt == null) {
                callback.onError("Dette introuvable");
                return;
            }

            double alreadyPaid = debtPaymentDao.getTotalPaidSync(debtId);
            double remaining = debt.getInitialAmount() - alreadyPaid;

            String validationError = ValidationUtils.validateRepaymentAmount(amount, remaining);
            if (validationError != null) {
                callback.onError(validationError);
                return;
            }

            double newRemaining = remaining - amount;
            boolean fullyPaid = newRemaining <= 0.0001;
            String newStatus = fullyPaid ? Debt.STATUS_PAID : Debt.STATUS_PARTIALLY_PAID;
            debt.setStatus(newStatus);

            db.runInTransaction(() -> {
                debtPaymentDao.insert(new DebtPayment(debtId, amount, new Date(), null));
                debtDao.update(debt);
                syncQueueDao.insert(new SyncQueueEvent(
                        SyncQueueEvent.TYPE_DEBT_PAYMENT_CREATED,
                        debtId,
                        SyncQueueEvent.STATUS_PENDING,
                        new Date()));
            });

            callback.onSuccess(fullyPaid);
        });
    }
}
