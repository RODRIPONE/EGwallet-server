package com.example.egwallet.ui.transactions;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.egwallet.R;
import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.entity.Revenue;
import com.example.egwallet.util.CurrencyFormatter;
import com.example.egwallet.util.DateUtils;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

// Ecran "Flux" : toggle Revenus/Depenses, carte total du mois, liste chronologique, FAB.
public class TransactionsFragment extends Fragment {

    private RevenueViewModel revenueViewModel;
    private ExpenseViewModel expenseViewModel;
    private TransactionFullAdapter adapter;
    private boolean showingExpenses = true;

    private TextView textTotalLabel, textTotalAmount, textTotalCount;

    public TransactionsFragment() {
        super(R.layout.fragment_transactions);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        revenueViewModel = new ViewModelProvider(this).get(RevenueViewModel.class);
        expenseViewModel = new ViewModelProvider(this).get(ExpenseViewModel.class);

        textTotalLabel = view.findViewById(R.id.text_total_label);
        textTotalAmount = view.findViewById(R.id.text_total_amount);
        textTotalCount = view.findViewById(R.id.text_total_count);
        RecyclerView recycler = view.findViewById(R.id.recycler_transactions);

        adapter = new TransactionFullAdapter();
        recycler.setLayoutManager(new LinearLayoutManager(requireContext()));
        recycler.setAdapter(adapter);

        MaterialButtonToggleGroup toggleGroup = view.findViewById(R.id.toggle_group);
        toggleGroup.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            showingExpenses = checkedId == R.id.button_expenses;
            render();
        });

        expenseViewModel.getAll().observe(getViewLifecycleOwner(), expenses -> {
            if (showingExpenses) render();
        });
        revenueViewModel.getAll().observe(getViewLifecycleOwner(), revenues -> {
            if (!showingExpenses) render();
        });

        FloatingActionButton fab = view.findViewById(R.id.fab_add);
        fab.setOnClickListener(v -> {
            AddTransactionBottomSheet sheet = AddTransactionBottomSheet.newInstance(showingExpenses);
            sheet.show(getChildFragmentManager(), "add_transaction");
        });

        render();
    }

    private void render() {
        if (showingExpenses) {
            List<Expense> expenses = expenseViewModel.getAll().getValue();
            renderExpenses(expenses != null ? expenses : new ArrayList<>());
        } else {
            List<Revenue> revenues = revenueViewModel.getAll().getValue();
            renderRevenues(revenues != null ? revenues : new ArrayList<>());
        }
    }

    private void renderExpenses(List<Expense> expenses) {
        Date now = new Date();
        Date start = DateUtils.startOfMonth(now);
        Date end = DateUtils.endOfMonth(now);

        List<TransactionFullAdapter.TransactionRow> rows = new ArrayList<>();
        double total = 0;
        int count = 0;
        for (Expense e : expenses) {
            rows.add(new TransactionFullAdapter.TransactionRow(
                    e.getReason(), e.getCategory(), e.getAmount(), false, e.isFixed(), e.getDate()));
            if (!e.getDate().before(start) && !e.getDate().after(end)) {
                total += e.getAmount();
                count++;
            }
        }
        adapter.submitList(rows);
        textTotalLabel.setText("TOTAL DÉPENSES — CE MOIS");
        textTotalAmount.setText(CurrencyFormatter.formatFull(total));
        textTotalCount.setText(count + (count > 1 ? " transactions" : " transaction"));
    }

    private void renderRevenues(List<Revenue> revenues) {
        Date now = new Date();
        Date start = DateUtils.startOfMonth(now);
        Date end = DateUtils.endOfMonth(now);

        List<TransactionFullAdapter.TransactionRow> rows = new ArrayList<>();
        double total = 0;
        int count = 0;
        for (Revenue r : revenues) {
            rows.add(new TransactionFullAdapter.TransactionRow(
                    r.getSource(), r.getCategory(), r.getAmount(), true, false, r.getDate()));
            if (!r.getDate().before(start) && !r.getDate().after(end)) {
                total += r.getAmount();
                count++;
            }
        }
        adapter.submitList(rows);
        textTotalLabel.setText("TOTAL REVENUS — CE MOIS");
        textTotalAmount.setText(CurrencyFormatter.formatFull(total));
        textTotalCount.setText(count + (count > 1 ? " transactions" : " transaction"));
    }
}
