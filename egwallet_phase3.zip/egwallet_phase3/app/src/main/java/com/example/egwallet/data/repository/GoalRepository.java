package com.example.egwallet.data.repository;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.GoalDao;
import com.example.egwallet.data.entity.Goal;

import java.util.List;

public class GoalRepository {

    // Limite du plan gratuit : 3 objectifs actifs maximum (cahier des charges section 7)
    public static final int FREE_PLAN_MAX_GOALS = 3;

    private final GoalDao goalDao;

    public GoalRepository(Application application) {
        goalDao = AppDatabase.getInstance(application).goalDao();
    }

    public LiveData<List<Goal>> getAll() {
        return goalDao.getAll();
    }

    public LiveData<Goal> getById(long id) {
        return goalDao.getById(id);
    }

    public int countGoalsSync() {
        return goalDao.countSync();
    }

    public void insert(Goal goal) {
        AppExecutors.getInstance().diskIO().execute(() -> goalDao.insert(goal));
    }

    public void update(Goal goal) {
        AppExecutors.getInstance().diskIO().execute(() -> goalDao.update(goal));
    }

    public void delete(Goal goal) {
        AppExecutors.getInstance().diskIO().execute(() -> goalDao.delete(goal));
    }

    // Lit -> mute en memoire (Goal.addContribution) -> persiste
    public void addContribution(Goal goal, double amount) {
        goal.addContribution(amount);
        update(goal);
    }
}
