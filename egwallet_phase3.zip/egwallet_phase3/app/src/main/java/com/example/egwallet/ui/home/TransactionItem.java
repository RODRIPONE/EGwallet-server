package com.example.egwallet.ui.home;

import java.util.Date;

// Modele d'affichage unifie pour la liste "Recentes" du Home (fusionne Revenue + Expense
// triees par date). Purement UI : ce n'est pas une entity Room.
public class TransactionItem {
    public final long id;
    public final double amount; // positif = revenu, negatif = depense
    public final String label;
    public final String category;
    public final Date date;
    public final boolean isRevenue;

    public TransactionItem(long id, double amount, String label, String category,
                            Date date, boolean isRevenue) {
        this.id = id;
        this.amount = amount;
        this.label = label;
        this.category = category;
        this.date = date;
        this.isRevenue = isRevenue;
    }
}
