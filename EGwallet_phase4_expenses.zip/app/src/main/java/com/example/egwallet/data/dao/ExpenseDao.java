package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.Expense;

import java.util.Date;
import java.util.List;

@Dao
public interface ExpenseDao {

    // OnConflictStrategy.REPLACE : si un Expense avec le même id arrive du backend,
    // il écrase l'entrée locale (utile lors du chargement initial depuis l'API)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Expense expense);

    @Update
    void update(Expense expense);

    @Delete
    void delete(Expense expense);

    /** Suppression par ID backend — utilisé par ExpenseRepository.deleteExpense() */
    @Query("DELETE FROM expenses WHERE id = :id")
    void deleteById(long id);

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    LiveData<List<Expense>> getAll();

    @Query("SELECT * FROM expenses WHERE date BETWEEN :start AND :end ORDER BY date DESC")
    LiveData<List<Expense>> getBetween(Date start, Date end);

    @Query("SELECT IFNULL(SUM(amount), 0) FROM expenses WHERE date BETWEEN :start AND :end")
    LiveData<Double> getTotalBetween(Date start, Date end);

    @Query("SELECT IFNULL(SUM(amount), 0) FROM expenses WHERE date BETWEEN :start AND :end")
    double getTotalBetweenSync(Date start, Date end);

    @Query("SELECT category, SUM(amount) as total FROM expenses " +
           "WHERE date BETWEEN :start AND :end GROUP BY category")
    LiveData<List<CategoryTotal>> getTotalsByCategory(Date start, Date end);

    @Query("SELECT IFNULL(SUM(amount), 0) FROM expenses")
    LiveData<Double> getTotalAll();

    // POJO de projection utilisé par le donut chart "Répartition des dépenses"
    class CategoryTotal {
        public String category;
        public double total;
    }
}
