package com.example.egwallet.ui.transactions;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.entity.FixedExpense;
import com.example.egwallet.data.repository.ExpenseRepository;
import com.example.egwallet.data.repository.FixedExpenseRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

/**
 * ExpenseViewModel — Phase 4 : API-first.
 *
 * Toutes les mutations (create/update/delete) passent par l'API backend.
 * La liste observée provient du cache Room, mis à jour par ExpenseRepository après chaque succès.
 *
 * Pattern identique à RevenueViewModel (Phase 3) :
 *   isLoading → spinner pendant l'appel réseau
 *   saved     → fermer le bottom sheet en cas de succès
 *   errorMessage → afficher l'erreur à l'utilisateur
 *
 * Particularité Expense : gestion du fixedExpenseId (dépenses fixes)
 *   addExpenseFromFixed() transmet l'ID de la FixedExpense au backend via createExpense().
 */
public class ExpenseViewModel extends AndroidViewModel {

    private final ExpenseRepository expenseRepository;
    private final FixedExpenseRepository fixedExpenseRepository;

    private final MutableLiveData<Event<String>>  errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved        = new MutableLiveData<>();
    private final MutableLiveData<Boolean>        isLoading    = new MutableLiveData<>(false);

    public ExpenseViewModel(@NonNull Application application) {
        super(application);
        expenseRepository = new ExpenseRepository(application);
        fixedExpenseRepository = new FixedExpenseRepository(application);
    }

    // ── LiveData observables ──────────────────────────────────────────────────

    public LiveData<List<Expense>> getAll()              { return expenseRepository.getAll(); }
    public LiveData<List<FixedExpense>> getAllFixedExpenses() { return fixedExpenseRepository.getAll(); }
    public LiveData<Event<String>> getErrorMessage()     { return errorMessage; }
    public LiveData<Event<Boolean>> getSaved()           { return saved; }
    public LiveData<Boolean> getIsLoading()              { return isLoading; }

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * Ajoute une dépense saisie manuellement (fixedExpenseId = null).
     */
    public void addExpense(String rawAmount, String reason, String category,
                            Date date, String notes) {
        // Validation locale avant appel réseau
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) { errorMessage.setValue(new Event<>(amountError)); return; }

        String reasonError = ValidationUtils.validateText(reason, "Le motif");
        if (reasonError != null) { errorMessage.setValue(new Event<>(reasonError)); return; }

        String dateError = ValidationUtils.validatePastOrTodayDate(date);
        if (dateError != null) { errorMessage.setValue(new Event<>(dateError)); return; }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        isLoading.setValue(true);

        expenseRepository.createExpense(
                amount, reason.trim(), category, date, notes,
                null,   // pas de dépense fixe associée
                new ExpenseRepository.ExpenseCallback() {
                    @Override public void onSuccess() {
                        isLoading.postValue(false);
                        saved.postValue(new Event<>(true));
                    }
                    @Override public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    /**
     * Extension UC "Sélectionner une dépense fixe existante" :
     * pré-remplit depuis une FixedExpense et la transmet au backend avec fixedExpenseId.
     */
    public void addExpenseFromFixed(FixedExpense fixedExpense, Date date) {
        isLoading.setValue(true);
        expenseRepository.createExpense(
                fixedExpense.getAmount(),
                fixedExpense.getLabel(),
                fixedExpense.getCategory(),
                date,
                null,
                fixedExpense.getId(),   // fixedExpenseId transmis au backend
                new ExpenseRepository.ExpenseCallback() {
                    @Override public void onSuccess() {
                        isLoading.postValue(false);
                        saved.postValue(new Event<>(true));
                    }
                    @Override public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * @param expense entité Room existante (contient l'ID backend aligné à la création)
     */
    public void updateExpense(Expense expense, String rawAmount, String reason, String category) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) { errorMessage.setValue(new Event<>(amountError)); return; }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        isLoading.setValue(true);

        expenseRepository.updateExpense(
                expense.getId(), amount, reason.trim(), category,
                new ExpenseRepository.ExpenseCallback() {
                    @Override public void onSuccess() {
                        isLoading.postValue(false);
                        saved.postValue(new Event<>(true));
                    }
                    @Override public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    public void deleteExpense(Expense expense) {
        isLoading.setValue(true);
        expenseRepository.deleteExpense(expense.getId(),
                new ExpenseRepository.ExpenseCallback() {
                    @Override public void onSuccess() {
                        isLoading.postValue(false);
                    }
                    @Override public void onError(String message) {
                        isLoading.postValue(false);
                        errorMessage.postValue(new Event<>(message));
                    }
                });
    }

    // ── FixedExpense CRUD local (Room uniquement) ─────────────────────────────
    // Les dépenses fixes ne sont pas encore synchronisées avec le backend dans cette phase.

    public void createFixedExpense(String label, String rawAmount, String category, int recurrenceDay) {
        String labelError = ValidationUtils.validateText(label, "Le libellé");
        if (labelError != null) { errorMessage.setValue(new Event<>(labelError)); return; }

        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) { errorMessage.setValue(new Event<>(amountError)); return; }

        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        fixedExpenseRepository.insert(new FixedExpense(label.trim(), amount, category, recurrenceDay));
        saved.setValue(new Event<>(true));
    }
}
