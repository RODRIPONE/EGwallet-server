package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.ExpenseDao;
import com.example.egwallet.data.entity.Expense;
import com.example.egwallet.data.remote.ApiService;
import com.example.egwallet.data.remote.DateMapper;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.dto.ApiResponseDto;
import com.example.egwallet.data.remote.dto.ExpenseDto;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * ExpenseRepository — Phase 4 : API-first with local cache.
 *
 * Pattern identique à RevenueRepository (Phase 3) :
 *   1. Appel API backend
 *   2. Succès → mise à jour Room (cache) → callback onSuccess
 *   3. Échec  → callback onError (Room non modifié)
 *
 * Particularité Expense par rapport à Revenue :
 *   - Champ fixedExpenseId (nullable) : transmis au backend, aligné en cache Room
 *   - isFixed calculé côté client : true si fixedExpenseId != null
 *
 * Les LiveData viennent de Room et se notifient automatiquement.
 */
public class ExpenseRepository {

    private static final String TAG = "ExpenseRepository";

    private final ExpenseDao expenseDao;
    private final ApiService apiService;

    public ExpenseRepository(Application application) {
        expenseDao = AppDatabase.getInstance(application).expenseDao();
        apiService = RetrofitClient.getInstance(application).getApiService();
    }

    // ── Lecture (Room → LiveData) ─────────────────────────────────────────────

    public LiveData<List<Expense>> getAll() {
        return expenseDao.getAll();
    }

    public LiveData<List<Expense>> getBetween(Date start, Date end) {
        return expenseDao.getBetween(start, end);
    }

    public LiveData<Double> getTotalBetween(Date start, Date end) {
        return expenseDao.getTotalBetween(start, end);
    }

    public double getTotalBetweenSync(Date start, Date end) {
        return expenseDao.getTotalBetweenSync(start, end);
    }

    public LiveData<List<ExpenseDao.CategoryTotal>> getTotalsByCategory(Date start, Date end) {
        return expenseDao.getTotalsByCategory(start, end);
    }

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * Crée une dépense via l'API, puis la persiste en cache Room.
     *
     * @param amount          montant
     * @param reason          motif (libellé)
     * @param category        catégorie
     * @param date            date de la dépense
     * @param notes           notes optionnelles (nullable)
     * @param fixedExpenseId  ID de la dépense fixe source (nullable — null si saisie manuelle)
     * @param callback        résultat de l'opération
     */
    public void createExpense(double amount, String reason, String category,
                               Date date, String notes, Long fixedExpenseId,
                               ExpenseCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("amount", amount);
        body.put("reason", reason);
        body.put("category", category);
        body.put("date", DateMapper.formatDate(date));   // "yyyy-MM-dd"
        if (notes != null && !notes.isEmpty()) body.put("notes", notes);
        if (fixedExpenseId != null) body.put("fixedExpenseId", fixedExpenseId);

        apiService.createExpense(body).enqueue(new Callback<ApiResponseDto<ExpenseDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<ExpenseDto>> call,
                                   Response<ApiResponseDto<ExpenseDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess() && response.body().getData() != null) {
                    ExpenseDto dto = response.body().getData();
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        Expense local = dtoToEntity(dto);
                        local.setId(dto.getId());   // aligner ID local sur ID backend
                        expenseDao.insert(local);
                        Log.d(TAG, "Expense créée et mise en cache : id=" + dto.getId());
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null
                            ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<ExpenseDto>> call, Throwable t) {
                Log.e(TAG, "createExpense failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * Met à jour une dépense via l'API, puis synchronise le cache Room.
     * L'ID passé doit être l'ID backend (= Expense.id après alignement à la création).
     */
    public void updateExpense(long expenseId, double amount, String reason,
                               String category, ExpenseCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("amount", amount);
        body.put("reason", reason);
        body.put("category", category);

        apiService.updateExpense(expenseId, body).enqueue(new Callback<ApiResponseDto<ExpenseDto>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<ExpenseDto>> call,
                                   Response<ApiResponseDto<ExpenseDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess() && response.body().getData() != null) {
                    ExpenseDto dto = response.body().getData();
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        Expense local = dtoToEntity(dto);
                        local.setId(dto.getId());
                        expenseDao.update(local);
                        Log.d(TAG, "Expense mise à jour : id=" + dto.getId());
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null
                            ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<ExpenseDto>> call, Throwable t) {
                Log.e(TAG, "updateExpense failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /**
     * Supprime une dépense via l'API, puis supprime du cache Room.
     */
    public void deleteExpense(long expenseId, ExpenseCallback callback) {
        apiService.deleteExpense(expenseId).enqueue(new Callback<ApiResponseDto<String>>() {
            @Override
            public void onResponse(Call<ApiResponseDto<String>> call,
                                   Response<ApiResponseDto<String>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        expenseDao.deleteById(expenseId);
                        Log.d(TAG, "Expense supprimée du cache : id=" + expenseId);
                    });
                    callback.onSuccess();
                } else {
                    String msg = response.body() != null
                            ? response.body().getMessage() : "Erreur serveur";
                    callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponseDto<String>> call, Throwable t) {
                Log.e(TAG, "deleteExpense failed", t);
                callback.onError("Erreur réseau : " + t.getMessage());
            }
        });
    }

    // ── Mapper DTO → entité Room ──────────────────────────────────────────────

    private Expense dtoToEntity(ExpenseDto dto) {
        return new Expense(
                dto.getAmount() != null ? dto.getAmount() : 0.0,
                dto.getReason(),
                dto.getCategory(),
                DateMapper.parseDate(dto.getDate()),        // "yyyy-MM-dd" → Date
                null,                                        // notes non exposé dans ExpenseResponse
                Boolean.TRUE.equals(dto.getIsFixed()),
                dto.getFixedExpenseId()
        );
    }

    // ── Callback ──────────────────────────────────────────────────────────────

    public interface ExpenseCallback {
        void onSuccess();
        void onError(String message);
    }
}
