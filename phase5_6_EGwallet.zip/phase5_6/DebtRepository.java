package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.dao.DebtPaymentDao;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.dto.ApiResponse;
import com.example.egwallet.data.remote.dto.DebtDto;
import com.example.egwallet.util.DateUtils;
import com.example.egwallet.util.ValidationUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * DebtRepository — version API-first avec cache Room (Phase 5).
 *
 * Stratégie :
 *   • Lectures  → Room (LiveData, réactivité immédiate même hors-ligne).
 *   • Écritures → API d'abord, Room mis à jour uniquement si l'API répond 2xx.
 *   • Erreur API → callback.onError() ; Room inchangé (pas de données fantômes).
 *
 * Contrat de l'interface {@link RepaymentCallback} inchangé → DebtViewModel
 * n'a pas besoin d'être modifié.
 */
public class DebtRepository {

    private static final String TAG = "DebtRepository";

    // ── Callback identique à l'ancienne version ─────────────────────────────
    public interface RepaymentCallback {
        void onSuccess(boolean fullyPaid);
        void onError(String message);
    }

    // ── Callback générique pour créer / supprimer ────────────────────────────
    public interface ActionCallback {
        void onSuccess();
        void onError(String message);
    }

    private final AppDatabase db;
    private final DebtDao debtDao;
    private final DebtPaymentDao debtPaymentDao;

    public DebtRepository(Application application) {
        db = AppDatabase.getInstance(application);
        debtDao = db.debtDao();
        debtPaymentDao = db.debtPaymentDao();
    }

    // ── Lectures (Room → LiveData) ───────────────────────────────────────────

    public LiveData<List<DebtDao.DebtWithRemaining>> getAllWithRemaining() {
        return debtDao.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return debtDao.getTotalRemaining();
    }

    public LiveData<Debt> getById(long id) {
        return debtDao.getById(id);
    }

    public LiveData<List<DebtPayment>> getPaymentsForDebt(long debtId) {
        return debtPaymentDao.getForDebt(debtId);
    }

    // ── Chargement initial / rafraîchissement depuis l'API ───────────────────

    /**
     * Récupère toutes les dettes depuis l'API et remplace le cache Room.
     * À appeler au démarrage (onResume du fragment) ou après une reconnexion.
     */
    public void refreshFromApi() {
        RetrofitClient.getApiService().getDebts().enqueue(new Callback<ApiResponse<List<DebtDto>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<DebtDto>>> call,
                                   Response<ApiResponse<List<DebtDto>>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    List<DebtDto> dtos = response.body().getData();
                    if (dtos == null) return;
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        // Remplacement complet du cache local
                        debtDao.deleteAll();
                        for (DebtDto dto : dtos) {
                            debtDao.insertWithServerId(dtoToEntity(dto));
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<DebtDto>>> call, Throwable t) {
                Log.w(TAG, "refreshFromApi failed — affichage du cache Room", t);
            }
        });
    }

    // ── Création ─────────────────────────────────────────────────────────────

    /**
     * Crée une dette via l'API, puis la persiste en Room si succès.
     *
     * @param callback appelé sur le thread principal via postValue dans DebtViewModel.
     */
    public void insert(Debt debt, ActionCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("creditor", debt.getCreditor());
        body.put("amount", debt.getInitialAmount());
        body.put("reason", debt.getReason());
        if (debt.getDueDate() != null) {
            body.put("dueDate", DateUtils.toIsoDate(debt.getDueDate()));
        }
        if (debt.getNotes() != null) {
            body.put("notes", debt.getNotes());
        }

        RetrofitClient.getApiService().createDebt(body).enqueue(new Callback<ApiResponse<DebtDto>>() {
            @Override
            public void onResponse(Call<ApiResponse<DebtDto>> call,
                                   Response<ApiResponse<DebtDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    DebtDto dto = response.body().getData();
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        debtDao.insertWithServerId(dtoToEntity(dto));
                    });
                    if (callback != null) callback.onSuccess();
                } else {
                    String msg = response.body() != null ? response.body().getMessage()
                            : "Erreur serveur (" + response.code() + ")";
                    if (callback != null) callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<DebtDto>> call, Throwable t) {
                if (callback != null) callback.onError("Pas de connexion réseau");
            }
        });
    }

    // ── Remboursement ────────────────────────────────────────────────────────

    /**
     * Enregistre un remboursement via POST /api/debts/{id}/pay.
     * Le backend recalcule remainingAmount et status — on met Room à jour avec
     * la réponse officielle du serveur (source de vérité unique).
     *
     * Validation préalable (montant > 0, montant <= restant) conservée ici
     * pour un retour d'erreur immédiat sans aller-retour réseau.
     */
    public void repayDebt(long debtId, double amount, RepaymentCallback callback) {
        AppExecutors.getInstance().diskIO().execute(() -> {
            Debt debt = debtDao.getByIdSync(debtId);
            if (debt == null) {
                callback.onError("Dette introuvable");
                return;
            }

            double alreadyPaid = debtPaymentDao.getTotalPaidSync(debtId);
            double remaining = debt.getInitialAmount() - alreadyPaid;

            String validationError = ValidationUtils.validateRepaymentAmount(amount, remaining);
            if (validationError != null) {
                callback.onError(validationError);
                return;
            }

            // Passer à l'API avec le serverId (= id Room après phase 5 — on utilise id directement
            // car Room est rempli avec les IDs serveur via insertWithServerId)
            Map<String, Object> body = new HashMap<>();
            body.put("amount", amount);

            RetrofitClient.getApiService().repayDebt(debtId, body)
                    .enqueue(new Callback<ApiResponse<DebtDto>>() {
                        @Override
                        public void onResponse(Call<ApiResponse<DebtDto>> call,
                                               Response<ApiResponse<DebtDto>> response) {
                            if (response.isSuccessful() && response.body() != null
                                    && response.body().isSuccess()) {
                                DebtDto dto = response.body().getData();
                                // Mettre à jour Room avec les valeurs officielles du backend
                                AppExecutors.getInstance().diskIO().execute(() -> {
                                    Debt updated = dtoToEntity(dto);
                                    debtDao.update(updated);
                                    // Insérer le paiement local pour l'historique
                                    debtPaymentDao.insert(
                                            new DebtPayment(debtId, amount, new Date(), null));
                                });
                                callback.onSuccess(dto.isFullyPaid);
                            } else {
                                String msg = response.body() != null
                                        ? response.body().getMessage()
                                        : "Erreur serveur (" + response.code() + ")";
                                callback.onError(msg);
                            }
                        }

                        @Override
                        public void onFailure(Call<ApiResponse<DebtDto>> call, Throwable t) {
                            callback.onError("Pas de connexion réseau");
                        }
                    });
        });
    }

    // ── Suppression ──────────────────────────────────────────────────────────

    public void delete(Debt debt) {
        RetrofitClient.getApiService().deleteDebt(debt.getId())
                .enqueue(new Callback<ApiResponse<Void>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Void>> call,
                                           Response<ApiResponse<Void>> response) {
                        if (response.isSuccessful()) {
                            AppExecutors.getInstance().diskIO().execute(() -> debtDao.delete(debt));
                        } else {
                            Log.e(TAG, "Suppression API échouée : " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Void>> call, Throwable t) {
                        Log.e(TAG, "Suppression hors-ligne non supportée pour l'instant", t);
                    }
                });
    }

    // ── Conversion DTO → Entity Room ─────────────────────────────────────────

    /**
     * Convertit un DebtDto (JSON réseau) en entité Debt Room.
     * Les dates ISO-8601 String sont converties en java.util.Date via DateUtils.
     */
    private Debt dtoToEntity(DebtDto dto) {
        Date dueDate = DateUtils.fromIsoDate(dto.dueDate);
        Debt entity = new Debt(
                dto.initialAmount,
                dto.creditor,
                dto.reason,
                dueDate,
                null,   // notes absentes de DebtResponse — on ne les écrase pas
                dto.status
        );
        entity.setId(dto.id);
        // remainingAmount n'existe pas sur l'entité Room (calculé via JOIN debt_payments).
        // Le backend maintient remainingAmount de son côté ; Room le recalcule localement.
        return entity;
    }
}
