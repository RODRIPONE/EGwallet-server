// ════════════════════════════════════════════════════════════════════════════
//  AJOUTS AUX DAOs — PHASE 5 & 6
//
//  Ces méthodes Room sont requises par les nouveaux repositories.
//  Ajoute chaque bloc dans le DAO correspondant.
// ════════════════════════════════════════════════════════════════════════════


// ─── DebtDao.java ────────────────────────────────────────────────────────────
// Ajouter ces 3 méthodes dans l'interface DebtDao existante :

// Insère une entité avec l'ID serveur déjà défini (REPLACE si conflit d'ID).
// Utilisé par refreshFromApi() et insert() pour préserver l'ID backend.
@Insert(onConflict = OnConflictStrategy.REPLACE)
void insertWithServerId(Debt debt);

// Vide complètement la table debts (appelé par refreshFromApi avant rechargement).
// Les debt_payments sont supprimées en cascade si tu ajoutes
// FOREIGN KEY(debtId) REFERENCES debts(id) ON DELETE CASCADE dans la migration Room.
// Sinon : décommenter l'appel à clearPayments() dans refreshFromApi() selon ta migration.
@Query("DELETE FROM debts")
void deleteAll();

// Récupère une dette par son ID côté Room — déjà présent dans le DAO actuel :
// Debt getByIdSync(long id);   ← ne pas dupliquer, déjà là.


// ─── DueDao.java ─────────────────────────────────────────────────────────────
// Ajouter ces 2 méthodes dans l'interface DueDao existante :

@Insert(onConflict = OnConflictStrategy.REPLACE)
void insertWithServerId(Due due);

@Query("DELETE FROM dues")
void deleteAll();

// Due getByIdSync(long dueId);  ← déjà présent, ne pas dupliquer.


// ─── GoalDao.java ────────────────────────────────────────────────────────────
// Ajouter ces 2 méthodes dans l'interface GoalDao existante :

@Insert(onConflict = OnConflictStrategy.REPLACE)
void insertWithServerId(Goal goal);

@Query("DELETE FROM goals")
void deleteAll();


// ════════════════════════════════════════════════════════════════════════════
//  IMPORTS À AJOUTER EN TÊTE DES FICHIERS DAO concernés
// ════════════════════════════════════════════════════════════════════════════

// DebtDao.java & DueDao.java & GoalDao.java :
import androidx.room.OnConflictStrategy;
