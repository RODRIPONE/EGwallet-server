package com.example.egwallet.ui.goals;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.data.repository.GoalRepository;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

/**
 * GoalViewModel — version API-first (Phase 6).
 *
 * Changements vs version locale :
 *
 * 1. La vérification FREE_PLAN_LIMIT est retirée du ViewModel.
 *    Elle est désormais entièrement gérée côté serveur (GoalService).
 *    GoalRepository remonte onPaywallReached() quand le backend répond FREE_PLAN_LIMIT.
 *    → UserRepository n'est plus nécessaire ici (import supprimé).
 *    → AppExecutors n'est plus nécessaire ici (import supprimé).
 *
 * 2. createGoal() passe un InsertCallback à GoalRepository.insert()
 *    au lieu d'appeler goalDao directement.
 *
 * 3. addFunds() appelle GoalRepository.addContribution() qui poste
 *    via POST /api/goals/{id}/contribute.
 *
 * Le contrat LiveData exposé vers le fragment est 100 % inchangé :
 *   getAllGoals(), getGoal(), getErrorMessage(), getShowPaywall(), getSaved().
 */
public class GoalViewModel extends AndroidViewModel {

    private final GoalRepository goalRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> showPaywall = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public GoalViewModel(@NonNull Application application) {
        super(application);
        goalRepository = new GoalRepository(application);
    }

    // ── Observables exposés au fragment ──────────────────────────────────────

    public LiveData<List<Goal>> getAllGoals() {
        return goalRepository.getAll();
    }

    public LiveData<Goal> getGoal(long id) {
        return goalRepository.getById(id);
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    /**
     * Émis quand le backend confirme que la limite FREE_PLAN est atteinte.
     * Le Fragment observe ce LiveData et redirige vers PremiumActivity.
     */
    public LiveData<Event<Boolean>> getShowPaywall() {
        return showPaywall;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    // ── Actions ──────────────────────────────────────────────────────────────

    /**
     * Cas d'usage "Définir un objectif".
     *
     * Validation locale → API → Room (via GoalRepository.InsertCallback).
     * Le paywall est maintenant déclenché par le serveur, pas par un compteur local.
     */
    public void createGoal(String title, String emoji, String rawTargetAmount, Date deadline) {
        String titleError = ValidationUtils.validateText(title, "Le titre");
        if (titleError != null) {
            errorMessage.setValue(new Event<>(titleError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawTargetAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double targetAmount = Double.parseDouble(rawTargetAmount.trim().replace(" ", ""));

        Goal goal = new Goal(title.trim(), emoji, targetAmount, 0, deadline);

        goalRepository.insert(goal, new GoalRepository.InsertCallback() {
            @Override
            public void onSuccess() {
                saved.postValue(new Event<>(true));
            }

            @Override
            public void onPaywallReached() {
                // Le backend a confirmé : limite FREE_PLAN atteinte → afficher le paywall
                showPaywall.postValue(new Event<>(true));
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    /**
     * Cas d'usage "Suivre la progression" (ajout de fonds).
     * GoalRepository.addContribution() appelle POST /api/goals/{id}/contribute
     * puis met Room à jour avec currentAmount et isAchieved retournés par le backend.
     */
    public void addFunds(Goal goal, String rawAmount) {
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        goalRepository.addContribution(goal, amount);
        // saved est émis optimistiquement ; Room se mettra à jour dès la réponse API
        saved.setValue(new Event<>(true));
    }

    public void updateGoal(Goal goal) {
        goalRepository.update(goal);
    }

    public void deleteGoal(Goal goal) {
        goalRepository.delete(goal);
    }

    // ── Rafraîchissement ─────────────────────────────────────────────────────

    /** À appeler depuis onResume() du GoalsFragment pour synchroniser avec le serveur. */
    public void refresh() {
        goalRepository.refreshFromApi();
    }
}
