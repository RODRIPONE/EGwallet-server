package com.example.egwallet.ui.credit;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.data.entity.Due;
import com.example.egwallet.data.entity.DuePayment;
import com.example.egwallet.data.repository.DueRepository;
import com.example.egwallet.service.NotificationHelper;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

/**
 * DueViewModel — version API-first (Phase 5).
 * Symétrique de DebtViewModel.
 *
 * Changements vs version locale :
 * 1. createDue()       → passe un ActionCallback à DueRepository.insert().
 * 2. receivePayment()  → DueRepository gère l'appel POST /api/dues/{id}/receive + Room.
 * 3. refresh()         → ajouté pour onResume().
 *
 * Contrat LiveData inchangé.
 */
public class DueViewModel extends AndroidViewModel {

    private final DueRepository dueRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> receptionSuccess = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public DueViewModel(@NonNull Application application) {
        super(application);
        dueRepository = new DueRepository(application);
    }

    // ── Observables ──────────────────────────────────────────────────────────

    public LiveData<List<DueDao.DueWithRemaining>> getAllWithRemaining() {
        return dueRepository.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return dueRepository.getTotalRemaining();
    }

    public LiveData<Due> getDue(long id) {
        return dueRepository.getById(id);
    }

    public LiveData<List<DuePayment>> getPayments(long dueId) {
        return dueRepository.getPaymentsForDue(dueId);
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Event<Boolean>> getReceptionSuccess() {
        return receptionSuccess;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    // ── Actions ──────────────────────────────────────────────────────────────

    /**
     * Cas d'usage "Enregistrer un dû".
     * Validation locale → POST /api/dues → Room.
     */
    public void createDue(String debtorName, String rawAmount, String reason,
                          Date dueDate, String notes) {
        String debtorError = ValidationUtils.validateText(debtorName, "Le débiteur");
        if (debtorError != null) {
            errorMessage.setValue(new Event<>(debtorError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        Due due = new Due(amount, debtorName.trim(), reason, dueDate, notes, Due.STATUS_ACTIVE);

        dueRepository.insert(due, new DueRepository.ActionCallback() {
            @Override
            public void onSuccess() {
                saved.postValue(new Event<>(true));
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    /**
     * "Recevoir un remboursement de dû".
     * Validation locale → POST /api/dues/{id}/receive → Room.
     */
    public void receivePayment(long dueId, String rawAmount, String debtorName) {
        String amountFormatError = ValidationUtils.validateAmount(rawAmount);
        if (amountFormatError != null) {
            errorMessage.setValue(new Event<>(amountFormatError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));

        dueRepository.receivePayment(dueId, amount, new DueRepository.ReceptionCallback() {
            @Override
            public void onSuccess(boolean fullyReceived) {
                receptionSuccess.postValue(new Event<>(true));
                if (fullyReceived) {
                    NotificationHelper.showDuePaidNotification(getApplication(), debtorName);
                }
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    public void deleteDue(Due due) {
        dueRepository.delete(due);
    }

    // ── Rafraîchissement ─────────────────────────────────────────────────────

    /** À appeler depuis onResume() du CreditFragment. */
    public void refresh() {
        dueRepository.refreshFromApi();
    }
}
