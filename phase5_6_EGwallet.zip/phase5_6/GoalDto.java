package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * DTO réseau pour un objectif financier (Goal).
 *
 * JSON exact renvoyé par GET /api/goals et POST /api/goals :
 * {
 *   "id": 3,
 *   "userId": 5,
 *   "title": "Voiture",
 *   "emoji": "🚗",
 *   "targetAmount": 2000000.0000,
 *   "currentAmount": 350000.0000,
 *   "deadline": "2027-06-01",
 *   "category": "Transport",           ← absent de l'entité Room actuelle → à ignorer ou stocker
 *   "isAchieved": false,               ← absent de l'entité Room actuelle → à ajouter (phase 6)
 *   "progressPercentage": 17.5,        ← calculé par le backend, utile pour affichage rapide
 *   "monthsRemaining": 10,
 *   "requiredMonthlyContribution": 165000.0,
 *   "createdAt": "2026-07-19T09:00:00"
 * }
 *
 * Note : "progressPercentage", "monthsRemaining" et "requiredMonthlyContribution"
 * sont des champs calculés côté backend. Room ne les stocke pas (ils sont recalculés
 * localement par Goal.getProgressPercentage() etc.). On les lit ici uniquement
 * pour l'affichage immédiat avant persistance Room.
 */
public class GoalDto {

    @SerializedName("id")
    public long id;

    @SerializedName("userId")
    public long userId;

    @SerializedName("title")
    public String title;

    @SerializedName("emoji")
    public String emoji;

    @SerializedName("targetAmount")
    public double targetAmount;

    @SerializedName("currentAmount")
    public double currentAmount;

    /** Format "yyyy-MM-dd". */
    @SerializedName("deadline")
    public String deadline;

    /**
     * Champ présent dans le backend, absent de l'entité Room Goal actuelle.
     * Le repository l'ignore lors de la conversion → Room tant que Goal.java
     * n'expose pas ce champ. À exploiter quand la phase 6 l'ajoute à Room.
     */
    @SerializedName("category")
    public String category;

    /**
     * Indique si l'objectif est atteint (currentAmount >= targetAmount).
     * Calculé et persisté côté backend. À ajouter à l'entité Room Goal
     * (migration v→v+1) pour synchroniser l'état "atteint" correctement.
     */
    @SerializedName("isAchieved")
    public boolean isAchieved;

    /** Pourcentage de progression [0–100]. Calculé backend, non stocké en Room. */
    @SerializedName("progressPercentage")
    public double progressPercentage;

    /** Mois restants avant l'échéance. Calculé backend, non stocké en Room. */
    @SerializedName("monthsRemaining")
    public Integer monthsRemaining;

    /** Contribution mensuelle requise pour atteindre l'objectif. Non stockée en Room. */
    @SerializedName("requiredMonthlyContribution")
    public double requiredMonthlyContribution;

    /** Format "yyyy-MM-dd'T'HH:mm:ss". */
    @SerializedName("createdAt")
    public String createdAt;
}
