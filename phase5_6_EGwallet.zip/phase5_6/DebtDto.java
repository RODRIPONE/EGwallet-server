package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * DTO réseau pour une dette (Debt).
 *
 * JSON exact renvoyé par GET /api/debts et POST /api/debts :
 * {
 *   "id": 1,
 *   "userId": 5,
 *   "creditor": "Paul",
 *   "initialAmount": 50000.0000,
 *   "remainingAmount": 30000.0000,
 *   "reason": "Prêt voiture",
 *   "dueDate": "2026-09-15",          ← LocalDate ISO-8601
 *   "isFullyPaid": false,
 *   "status": "partiellement_payee",
 *   "createdAt": "2026-07-19T14:30:00" ← LocalDateTime ISO-8601
 * }
 *
 * Stratégie date : on stocke les dates en String ici, le repository
 * les convertit en java.util.Date via DateUtils avant de persister dans Room.
 */
public class DebtDto {

    @SerializedName("id")
    public long id;

    @SerializedName("userId")
    public long userId;

    @SerializedName("creditor")
    public String creditor;

    /** Backend : BigDecimal sérialisé en nombre décimal — Gson lit en double sans perte pour des montants courants. */
    @SerializedName("initialAmount")
    public double initialAmount;

    @SerializedName("remainingAmount")
    public double remainingAmount;

    @SerializedName("reason")
    public String reason;

    /** Format "yyyy-MM-dd" ou null si aucune échéance. */
    @SerializedName("dueDate")
    public String dueDate;

    @SerializedName("isFullyPaid")
    public boolean isFullyPaid;

    /**
     * Valeurs possibles (constantes identiques aux deux côtés) :
     * "active" | "partiellement_payee" | "soldee" | "en_retard"
     */
    @SerializedName("status")
    public String status;

    /** Format "yyyy-MM-dd'T'HH:mm:ss". */
    @SerializedName("createdAt")
    public String createdAt;
}
