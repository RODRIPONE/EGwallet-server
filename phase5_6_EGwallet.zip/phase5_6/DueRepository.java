package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.DueDao;
import com.example.egwallet.data.dao.DuePaymentDao;
import com.example.egwallet.data.entity.Due;
import com.example.egwallet.data.entity.DuePayment;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.dto.ApiResponse;
import com.example.egwallet.data.remote.dto.DueDto;
import com.example.egwallet.util.DateUtils;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * DueRepository — version API-first avec cache Room (Phase 5).
 * Symétrique de DebtRepository.
 *
 * Stratégie identique :
 *   • Lectures  → Room (LiveData).
 *   • Écritures → API d'abord, Room mis à jour sur réponse 2xx.
 */
public class DueRepository {

    private static final String TAG = "DueRepository";

    public interface ReceptionCallback {
        void onSuccess(boolean fullyReceived);
        void onError(String message);
    }

    public interface ActionCallback {
        void onSuccess();
        void onError(String message);
    }

    private final AppDatabase db;
    private final DueDao dueDao;
    private final DuePaymentDao duePaymentDao;

    public DueRepository(Application application) {
        db = AppDatabase.getInstance(application);
        dueDao = db.dueDao();
        duePaymentDao = db.duePaymentDao();
    }

    // ── Lectures ─────────────────────────────────────────────────────────────

    public LiveData<List<DueDao.DueWithRemaining>> getAllWithRemaining() {
        return dueDao.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return dueDao.getTotalRemaining();
    }

    public LiveData<Due> getById(long dueId) {
        return dueDao.getById(dueId);
    }

    public LiveData<List<DuePayment>> getPaymentsForDue(long dueId) {
        return duePaymentDao.getForDue(dueId);
    }

    // ── Rafraîchissement API ─────────────────────────────────────────────────

    public void refreshFromApi() {
        RetrofitClient.getApiService().getDues().enqueue(new Callback<ApiResponse<List<DueDto>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<DueDto>>> call,
                                   Response<ApiResponse<List<DueDto>>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    List<DueDto> dtos = response.body().getData();
                    if (dtos == null) return;
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        dueDao.deleteAll();
                        for (DueDto dto : dtos) {
                            dueDao.insertWithServerId(dtoToEntity(dto));
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<DueDto>>> call, Throwable t) {
                Log.w(TAG, "refreshFromApi failed — affichage du cache Room", t);
            }
        });
    }

    // ── Création ─────────────────────────────────────────────────────────────

    public void insert(Due due, ActionCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("debtorName", due.getDebtorName());
        body.put("amount", due.getInitialAmount());
        body.put("reason", due.getReason());
        if (due.getDueDate() != null) {
            body.put("dueDate", DateUtils.toIsoDate(due.getDueDate()));
        }
        if (due.getNotes() != null) {
            body.put("notes", due.getNotes());
        }

        RetrofitClient.getApiService().createDue(body).enqueue(new Callback<ApiResponse<DueDto>>() {
            @Override
            public void onResponse(Call<ApiResponse<DueDto>> call,
                                   Response<ApiResponse<DueDto>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    DueDto dto = response.body().getData();
                    AppExecutors.getInstance().diskIO().execute(() ->
                            dueDao.insertWithServerId(dtoToEntity(dto)));
                    if (callback != null) callback.onSuccess();
                } else {
                    String msg = response.body() != null ? response.body().getMessage()
                            : "Erreur serveur (" + response.code() + ")";
                    if (callback != null) callback.onError(msg);
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<DueDto>> call, Throwable t) {
                if (callback != null) callback.onError("Pas de connexion réseau");
            }
        });
    }

    // ── Réception d'un remboursement ─────────────────────────────────────────

    /**
     * Enregistre la réception d'un remboursement via POST /api/dues/{id}/receive.
     * Logique de validation identique à l'ancienne version Room.
     */
    public void receivePayment(long dueId, double amount, ReceptionCallback callback) {
        AppExecutors.getInstance().diskIO().execute(() -> {
            Due due = dueDao.getByIdSync(dueId);
            if (due == null) {
                callback.onError("Dû introuvable");
                return;
            }

            double alreadyReceived = duePaymentDao.getTotalReceivedSync(dueId);
            double remaining = due.getInitialAmount() - alreadyReceived;

            String validationError = ValidationUtils.validateRepaymentAmount(amount, remaining);
            if (validationError != null) {
                callback.onError(validationError);
                return;
            }

            Map<String, Object> body = new HashMap<>();
            body.put("amount", amount);

            RetrofitClient.getApiService().receiveDue(dueId, body)
                    .enqueue(new Callback<ApiResponse<DueDto>>() {
                        @Override
                        public void onResponse(Call<ApiResponse<DueDto>> call,
                                               Response<ApiResponse<DueDto>> response) {
                            if (response.isSuccessful() && response.body() != null
                                    && response.body().isSuccess()) {
                                DueDto dto = response.body().getData();
                                AppExecutors.getInstance().diskIO().execute(() -> {
                                    Due updated = dtoToEntity(dto);
                                    dueDao.update(updated);
                                    duePaymentDao.insert(
                                            new DuePayment(dueId, amount, new Date(), null));
                                });
                                callback.onSuccess(dto.isFullyReceived);
                            } else {
                                String msg = response.body() != null
                                        ? response.body().getMessage()
                                        : "Erreur serveur (" + response.code() + ")";
                                callback.onError(msg);
                            }
                        }

                        @Override
                        public void onFailure(Call<ApiResponse<DueDto>> call, Throwable t) {
                            callback.onError("Pas de connexion réseau");
                        }
                    });
        });
    }

    // ── Suppression ──────────────────────────────────────────────────────────

    public void delete(Due due) {
        RetrofitClient.getApiService().deleteDue(due.getId())
                .enqueue(new Callback<ApiResponse<Void>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Void>> call,
                                           Response<ApiResponse<Void>> response) {
                        if (response.isSuccessful()) {
                            AppExecutors.getInstance().diskIO().execute(() -> dueDao.delete(due));
                        } else {
                            Log.e(TAG, "Suppression API échouée : " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Void>> call, Throwable t) {
                        Log.e(TAG, "Suppression hors-ligne non supportée pour l'instant", t);
                    }
                });
    }

    // ── Conversion DTO → Entity Room ─────────────────────────────────────────

    private Due dtoToEntity(DueDto dto) {
        Date dueDate = DateUtils.fromIsoDate(dto.dueDate);
        Due entity = new Due(
                dto.initialAmount,
                dto.debtorName,
                dto.reason,
                dueDate,
                null,
                dto.status
        );
        entity.setId(dto.id);
        return entity;
    }
}
