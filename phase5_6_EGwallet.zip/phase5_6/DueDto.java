package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * DTO réseau pour un dû (Due) — argent que quelqu'un doit à l'utilisateur.
 * Symétrique de DebtDto.
 *
 * JSON exact renvoyé par GET /api/dues et POST /api/dues :
 * {
 *   "id": 2,
 *   "userId": 5,
 *   "debtorName": "Marie",
 *   "initialAmount": 20000.0000,
 *   "remainingAmount": 20000.0000,
 *   "reason": "Remboursement repas",
 *   "dueDate": "2026-08-01",
 *   "isFullyReceived": false,
 *   "status": "active",
 *   "createdAt": "2026-07-19T10:00:00"
 * }
 */
public class DueDto {

    @SerializedName("id")
    public long id;

    @SerializedName("userId")
    public long userId;

    /** Nom du débiteur — champ "debtorName" côté backend (à ne pas confondre avec "creditor" des Debt). */
    @SerializedName("debtorName")
    public String debtorName;

    @SerializedName("initialAmount")
    public double initialAmount;

    @SerializedName("remainingAmount")
    public double remainingAmount;

    @SerializedName("reason")
    public String reason;

    /** Format "yyyy-MM-dd" ou null. */
    @SerializedName("dueDate")
    public String dueDate;

    /**
     * Valeurs possibles :
     * "active" | "partiellement_payee" | "soldee" | "en_retard"
     */
    @SerializedName("isFullyReceived")
    public boolean isFullyReceived;

    @SerializedName("status")
    public String status;

    /** Format "yyyy-MM-dd'T'HH:mm:ss". */
    @SerializedName("createdAt")
    public String createdAt;
}
