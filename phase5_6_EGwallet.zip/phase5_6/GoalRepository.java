package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.GoalDao;
import com.example.egwallet.data.entity.Goal;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.dto.ApiResponse;
import com.example.egwallet.data.remote.dto.GoalDto;
import com.example.egwallet.util.DateUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * GoalRepository — version API-first avec cache Room (Phase 6).
 *
 * Paywall FREE_PLAN_LIMIT :
 *   La limite est désormais vérifiée ET appliquée côté backend (GoalService).
 *   Quand l'API retourne le code "FREE_PLAN_LIMIT", le repository le remonte
 *   via InsertCallback.onPaywallReached() → GoalViewModel déclenche showPaywall.
 *
 *   On ne vérifie plus le compteur Room localement (plus de countGoalsSync()).
 *   Cela évite une désynchronisation si des objectifs ont été créés sur un autre appareil.
 *
 * Note sur isAchieved / category :
 *   Ces champs sont présents dans GoalDto mais absents de l'entité Room Goal actuelle.
 *   Tant que Goal.java n'expose pas ces champs, dtoToEntity() les ignore.
 *   Quand tu ajouteras isAchieved et category à l'entité Room (migration), il suffira
 *   de compléter dtoToEntity() ici — aucun autre fichier à toucher.
 */
public class GoalRepository {

    private static final String TAG = "GoalRepository";

    /** Conservé pour compatibilité avec GoalViewModel (utilisé en lecture seule pour info). */
    public static final int FREE_PLAN_MAX_GOALS = 3;

    // ── Callbacks ────────────────────────────────────────────────────────────

    public interface InsertCallback {
        void onSuccess();
        /** Le backend a renvoyé FREE_PLAN_LIMIT → afficher le paywall. */
        void onPaywallReached();
        void onError(String message);
    }

    public interface ActionCallback {
        void onSuccess();
        void onError(String message);
    }

    private final GoalDao goalDao;

    public GoalRepository(Application application) {
        goalDao = AppDatabase.getInstance(application).goalDao();
    }

    // ── Lectures ─────────────────────────────────────────────────────────────

    public LiveData<List<Goal>> getAll() {
        return goalDao.getAll();
    }

    public LiveData<Goal> getById(long id) {
        return goalDao.getById(id);
    }

    /** Conservé pour la vérification d'affichage locale (badge, compteur UI). */
    public int countGoalsSync() {
        return goalDao.countSync();
    }

    // ── Rafraîchissement API ─────────────────────────────────────────────────

    public void refreshFromApi() {
        RetrofitClient.getApiService().getGoals().enqueue(new Callback<ApiResponse<List<GoalDto>>>() {
            @Override
            public void onResponse(Call<ApiResponse<List<GoalDto>>> call,
                                   Response<ApiResponse<List<GoalDto>>> response) {
                if (response.isSuccessful() && response.body() != null
                        && response.body().isSuccess()) {
                    List<GoalDto> dtos = response.body().getData();
                    if (dtos == null) return;
                    AppExecutors.getInstance().diskIO().execute(() -> {
                        goalDao.deleteAll();
                        for (GoalDto dto : dtos) {
                            goalDao.insertWithServerId(dtoToEntity(dto));
                        }
                    });
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<List<GoalDto>>> call, Throwable t) {
                Log.w(TAG, "refreshFromApi failed — affichage du cache Room", t);
            }
        });
    }

    // ── Création ─────────────────────────────────────────────────────────────

    /**
     * Crée un objectif via POST /api/goals.
     *
     * Le backend vérifie la limite FREE_PLAN (3 objectifs) et renvoie
     * ApiResponse.code == "FREE_PLAN_LIMIT" si dépassé.
     *
     * @param goal   entité pré-construite par GoalViewModel
     * @param callback résultat (onSuccess / onPaywallReached / onError)
     */
    public void insert(Goal goal, InsertCallback callback) {
        Map<String, Object> body = new HashMap<>();
        body.put("title", goal.getTitle());
        body.put("emoji", goal.getEmoji());
        body.put("targetAmount", goal.getTargetAmount());
        if (goal.getDeadline() != null) {
            body.put("deadline", DateUtils.toIsoDate(goal.getDeadline()));
        }
        // category et notes : absents de l'entité Room actuelle,
        // on n'envoie pas de valeur — le backend mettra null.

        RetrofitClient.getApiService().createGoal(body).enqueue(new Callback<ApiResponse<GoalDto>>() {
            @Override
            public void onResponse(Call<ApiResponse<GoalDto>> call,
                                   Response<ApiResponse<GoalDto>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ApiResponse<GoalDto> apiResp = response.body();

                    // Paywall : le backend envoie success=false + code="FREE_PLAN_LIMIT"
                    if ("FREE_PLAN_LIMIT".equals(apiResp.getCode())) {
                        if (callback != null) callback.onPaywallReached();
                        return;
                    }

                    if (apiResp.isSuccess() && apiResp.getData() != null) {
                        GoalDto dto = apiResp.getData();
                        AppExecutors.getInstance().diskIO().execute(() ->
                                goalDao.insertWithServerId(dtoToEntity(dto)));
                        if (callback != null) callback.onSuccess();
                    } else {
                        if (callback != null) callback.onError(apiResp.getMessage());
                    }
                } else {
                    if (callback != null) callback.onError("Erreur serveur (" + response.code() + ")");
                }
            }

            @Override
            public void onFailure(Call<ApiResponse<GoalDto>> call, Throwable t) {
                if (callback != null) callback.onError("Pas de connexion réseau");
            }
        });
    }

    // ── Contribution ─────────────────────────────────────────────────────────

    /**
     * Ajoute une contribution via POST /api/goals/{goalId}/contribute.
     * Met à jour Room avec les valeurs officielles du backend (currentAmount, isAchieved).
     */
    public void addContribution(Goal goal, double amount) {
        Map<String, Object> body = new HashMap<>();
        body.put("amount", amount);

        RetrofitClient.getApiService().addGoalContribution(goal.getId(), body)
                .enqueue(new Callback<ApiResponse<GoalDto>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<GoalDto>> call,
                                           Response<ApiResponse<GoalDto>> response) {
                        if (response.isSuccessful() && response.body() != null
                                && response.body().isSuccess()) {
                            GoalDto dto = response.body().getData();
                            AppExecutors.getInstance().diskIO().execute(() -> {
                                Goal updated = dtoToEntity(dto);
                                goalDao.update(updated);
                            });
                        } else {
                            Log.e(TAG, "addContribution API failed : "
                                    + (response.body() != null ? response.body().getMessage()
                                    : response.code()));
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<GoalDto>> call, Throwable t) {
                        Log.e(TAG, "addContribution hors-ligne — non supporté pour l'instant", t);
                    }
                });
    }

    // ── Mise à jour ──────────────────────────────────────────────────────────
    // Note : le backend n'expose pas de PUT /api/goals/{id} dans la version actuelle.
    // update() fait uniquement une mise à jour Room locale (titre, emoji, etc.)
    // jusqu'à ce que cet endpoint soit ajouté.
    public void update(Goal goal) {
        AppExecutors.getInstance().diskIO().execute(() -> goalDao.update(goal));
    }

    // ── Suppression ──────────────────────────────────────────────────────────

    public void delete(Goal goal) {
        RetrofitClient.getApiService().deleteGoal(goal.getId())
                .enqueue(new Callback<ApiResponse<Void>>() {
                    @Override
                    public void onResponse(Call<ApiResponse<Void>> call,
                                           Response<ApiResponse<Void>> response) {
                        if (response.isSuccessful()) {
                            AppExecutors.getInstance().diskIO().execute(() -> goalDao.delete(goal));
                        } else {
                            Log.e(TAG, "Suppression API échouée : " + response.code());
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponse<Void>> call, Throwable t) {
                        Log.e(TAG, "Suppression hors-ligne non supportée pour l'instant", t);
                    }
                });
    }

    // ── Conversion DTO → Entity Room ─────────────────────────────────────────

    /**
     * Convertit un GoalDto (JSON réseau) en entité Goal Room.
     *
     * Champs absents de l'entité Room actuelle (isAchieved, category, notes) :
     * ignorés pour l'instant. Quand tu ajouteras ces colonnes à Goal.java
     * et lances la migration Room, il suffira de décommenter les lignes marquées TODO.
     */
    private Goal dtoToEntity(GoalDto dto) {
        Date deadline = DateUtils.fromIsoDate(dto.deadline);
        Goal entity = new Goal(
                dto.title,
                dto.emoji,
                dto.targetAmount,
                dto.currentAmount,
                deadline
        );
        entity.setId(dto.id);

        // TODO (après ajout isAchieved à Goal.java) :
        // entity.setAchieved(dto.isAchieved);

        // TODO (après ajout category à Goal.java) :
        // entity.setCategory(dto.category);

        return entity;
    }
}
