package com.example.egwallet.data.remote;

// ════════════════════════════════════════════════════════════════════════════
//  AJOUTS À FUSIONNER DANS ApiService.java (produit en Phase 1)
//
//  Ces méthodes Retrofit couvrent exactement les endpoints backend
//  lus dans DebtController, DueController et GoalController.
//
//  Fusionne ces imports et méthodes dans ton ApiService.java existant.
// ════════════════════════════════════════════════════════════════════════════

import com.example.egwallet.data.remote.dto.ApiResponse;
import com.example.egwallet.data.remote.dto.DebtDto;
import com.example.egwallet.data.remote.dto.DueDto;
import com.example.egwallet.data.remote.dto.GoalDto;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

// ─── DEBT ────────────────────────────────────────────────────────────────────

// GET /api/debts
@GET("api/debts")
Call<ApiResponse<List<DebtDto>>> getDebts();

// POST /api/debts
// Corps attendu : { "creditor": "", "amount": 0, "reason": "", "dueDate": "yyyy-MM-dd", "notes": "" }
@POST("api/debts")
Call<ApiResponse<DebtDto>> createDebt(@Body Map<String, Object> body);

// GET /api/debts/{debtId}
@GET("api/debts/{debtId}")
Call<ApiResponse<DebtDto>> getDebt(@Path("debtId") long debtId);

// POST /api/debts/{debtId}/pay
// Corps attendu : { "amount": 0 }
@POST("api/debts/{debtId}/pay")
Call<ApiResponse<DebtDto>> repayDebt(@Path("debtId") long debtId,
                                      @Body Map<String, Object> body);

// GET /api/debts/{debtId}/payments
// La réponse est une List<Map> : [{id, amountPaid, paymentDate, createdAt}]
// On peut la typer avec DebtPaymentDto si on veut afficher l'historique des paiements.
// Pour l'instant on retourne Void et on lit l'historique depuis Room (DebtPaymentDao).
@GET("api/debts/{debtId}/payments")
Call<ApiResponse<List<Map<String, Object>>>> getDebtPayments(@Path("debtId") long debtId);

// DELETE /api/debts/{debtId}
@DELETE("api/debts/{debtId}")
Call<ApiResponse<Void>> deleteDebt(@Path("debtId") long debtId);


// ─── DUE ─────────────────────────────────────────────────────────────────────

// GET /api/dues
@GET("api/dues")
Call<ApiResponse<List<DueDto>>> getDues();

// POST /api/dues
// Corps attendu : { "debtorName": "", "amount": 0, "reason": "", "dueDate": "yyyy-MM-dd", "notes": "" }
@POST("api/dues")
Call<ApiResponse<DueDto>> createDue(@Body Map<String, Object> body);

// GET /api/dues/{dueId}
@GET("api/dues/{dueId}")
Call<ApiResponse<DueDto>> getDue(@Path("dueId") long dueId);

// POST /api/dues/{dueId}/receive
// Corps attendu : { "amount": 0 }
@POST("api/dues/{dueId}/receive")
Call<ApiResponse<DueDto>> receiveDue(@Path("dueId") long dueId,
                                      @Body Map<String, Object> body);

// GET /api/dues/{dueId}/payments
@GET("api/dues/{dueId}/payments")
Call<ApiResponse<List<Map<String, Object>>>> getDuePayments(@Path("dueId") long dueId);

// DELETE /api/dues/{dueId}
@DELETE("api/dues/{dueId}")
Call<ApiResponse<Void>> deleteDue(@Path("dueId") long dueId);


// ─── GOAL ─────────────────────────────────────────────────────────────────────

// GET /api/goals
@GET("api/goals")
Call<ApiResponse<List<GoalDto>>> getGoals();

// POST /api/goals
// Corps attendu : { "title": "", "emoji": "", "targetAmount": 0, "deadline": "yyyy-MM-dd",
//                   "category": null, "notes": null }
// Réponse erreur quand plan gratuit dépassé :
//   { "success": false, "code": "FREE_PLAN_LIMIT", "message": "..." }
@POST("api/goals")
Call<ApiResponse<GoalDto>> createGoal(@Body Map<String, Object> body);

// POST /api/goals/{goalId}/contribute
// Corps attendu : { "amount": 0 }
@POST("api/goals/{goalId}/contribute")
Call<ApiResponse<GoalDto>> addGoalContribution(@Path("goalId") long goalId,
                                                @Body Map<String, Object> body);

// DELETE /api/goals/{goalId}
@DELETE("api/goals/{goalId}")
Call<ApiResponse<Void>> deleteGoal(@Path("goalId") long goalId);
