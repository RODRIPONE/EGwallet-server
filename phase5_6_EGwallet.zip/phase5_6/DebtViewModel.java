package com.example.egwallet.ui.credit;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.dao.DebtDao;
import com.example.egwallet.data.entity.Debt;
import com.example.egwallet.data.entity.DebtPayment;
import com.example.egwallet.data.repository.DebtRepository;
import com.example.egwallet.service.NotificationHelper;
import com.example.egwallet.util.Event;
import com.example.egwallet.util.ValidationUtils;

import java.util.Date;
import java.util.List;

/**
 * DebtViewModel — version API-first (Phase 5).
 *
 * Changements vs version locale :
 *
 * 1. createDebt() passe un ActionCallback à DebtRepository.insert()
 *    → saved n'est émis que si l'API confirme la création (plus d'insert optimiste).
 *    → errorMessage est émis si l'API échoue ou si le réseau est absent.
 *
 * 2. repayDebt() inchangé en surface — DebtRepository.repayDebt() gère
 *    maintenant l'appel API + mise à jour Room en interne.
 *
 * 3. deleteDebt() n'attend plus de callback (suppression API best-effort,
 *    Room mis à jour si l'API répond 2xx).
 *
 * 4. refresh() est ajouté pour appeler refreshFromApi() depuis le fragment.
 *
 * Tout le contrat LiveData exposé vers le fragment est inchangé.
 */
public class DebtViewModel extends AndroidViewModel {

    private final DebtRepository debtRepository;

    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> repaymentSuccess = new MutableLiveData<>();
    private final MutableLiveData<Event<Boolean>> saved = new MutableLiveData<>();

    public DebtViewModel(@NonNull Application application) {
        super(application);
        debtRepository = new DebtRepository(application);
    }

    // ── Observables ──────────────────────────────────────────────────────────

    public LiveData<List<DebtDao.DebtWithRemaining>> getAllWithRemaining() {
        return debtRepository.getAllWithRemaining();
    }

    public LiveData<Double> getTotalRemaining() {
        return debtRepository.getTotalRemaining();
    }

    public LiveData<Debt> getDebt(long id) {
        return debtRepository.getById(id);
    }

    public LiveData<List<DebtPayment>> getPayments(long debtId) {
        return debtRepository.getPaymentsForDebt(debtId);
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Event<Boolean>> getRepaymentSuccess() {
        return repaymentSuccess;
    }

    public LiveData<Event<Boolean>> getSaved() {
        return saved;
    }

    // ── Actions ──────────────────────────────────────────────────────────────

    /**
     * Cas d'usage "Enregistrer une dette".
     * Validation locale → POST /api/debts → Room.
     * saved est émis uniquement si l'API répond 2xx.
     */
    public void createDebt(String creditor, String rawAmount, String reason,
                           Date dueDate, String notes) {
        String creditorError = ValidationUtils.validateText(creditor, "Le créancier");
        if (creditorError != null) {
            errorMessage.setValue(new Event<>(creditorError));
            return;
        }
        String amountError = ValidationUtils.validateAmount(rawAmount);
        if (amountError != null) {
            errorMessage.setValue(new Event<>(amountError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        Debt debt = new Debt(amount, creditor.trim(), reason, dueDate, notes, Debt.STATUS_ACTIVE);

        debtRepository.insert(debt, new DebtRepository.ActionCallback() {
            @Override
            public void onSuccess() {
                saved.postValue(new Event<>(true));
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    /**
     * Diagramme d'activité "RembourserDette".
     * Validation locale → POST /api/debts/{id}/pay → Room mis à jour avec les
     * valeurs officielles du backend (remainingAmount, status, isFullyPaid).
     * Notification locale si soldée.
     */
    public void repayDebt(long debtId, String rawAmount, String creditorName) {
        String amountFormatError = ValidationUtils.validateAmount(rawAmount);
        if (amountFormatError != null) {
            errorMessage.setValue(new Event<>(amountFormatError));
            return;
        }
        double amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));

        debtRepository.repayDebt(debtId, amount, new DebtRepository.RepaymentCallback() {
            @Override
            public void onSuccess(boolean fullyPaid) {
                repaymentSuccess.postValue(new Event<>(true));
                if (fullyPaid) {
                    NotificationHelper.showDebtPaidNotification(getApplication(), creditorName);
                }
            }

            @Override
            public void onError(String message) {
                errorMessage.postValue(new Event<>(message));
            }
        });
    }

    public void deleteDebt(Debt debt) {
        debtRepository.delete(debt);
    }

    // ── Rafraîchissement ─────────────────────────────────────────────────────

    /** À appeler depuis onResume() du CreditFragment pour synchroniser avec le serveur. */
    public void refresh() {
        debtRepository.refreshFromApi();
    }
}
