package com.egwallet.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EgwalletServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
