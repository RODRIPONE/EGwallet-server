-- ============================================================================
-- MIGRATION V2: Colonnes manquantes + corrections de contraintes
-- ============================================================================

-- 1. Agrandir pin_code : BCrypt génère 60 chars, VARCHAR(10) causait une troncature silencieuse
ALTER TABLE users ALTER COLUMN pin_code TYPE VARCHAR(100);

-- 2. Ajouter emoji sur goals (parité Android)
ALTER TABLE goals ADD COLUMN IF NOT EXISTS emoji VARCHAR(10);

-- 3. Ajouter status sur debts (parité Android : active | partiellement_payee | soldee | en_retard)
ALTER TABLE debts ADD COLUMN IF NOT EXISTS status VARCHAR(30) NOT NULL DEFAULT 'active';

-- 4. Ajouter status sur dues (parité Android)
ALTER TABLE dues ADD COLUMN IF NOT EXISTS status VARCHAR(30) NOT NULL DEFAULT 'active';

-- 5. Index sur le nouveau champ status pour les requêtes de filtrage
CREATE INDEX IF NOT EXISTS idx_debts_status ON debts(status);
CREATE INDEX IF NOT EXISTS idx_dues_status ON dues(status);

-- ============================================================================
-- FIN DE MIGRATION V2
-- ============================================================================
