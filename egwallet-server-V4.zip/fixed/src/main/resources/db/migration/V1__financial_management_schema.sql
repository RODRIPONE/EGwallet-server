-- ============================================================================
-- MIGRATION V1: Financial Management Application Schema
-- ============================================================================
-- Complete database schema for EgWallet - Personal Finance Management App
-- Based on UML class diagram from requirements
-- ============================================================================

-- ============================================================================
-- 1. USERS TABLE - Central entity for all financial data
-- ============================================================================
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    pin_code VARCHAR(10) NOT NULL,
    biometric_enabled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- ============================================================================
-- 2. EXPENSES TABLE - Track all expenses (fixed and variable)
-- ============================================================================
CREATE TABLE expenses (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    amount DECIMAL(19, 4) NOT NULL,
    reason VARCHAR(255),
    category VARCHAR(50) NOT NULL,
    date DATE NOT NULL,
    notes VARCHAR(500),
    is_fixed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 3. REVENUES TABLE - Track all income/revenues
-- ============================================================================
CREATE TABLE revenues (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    amount DECIMAL(19, 4) NOT NULL,
    source VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    date DATE NOT NULL,
    notes VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 4. FIXED_EXPENSES TABLE - Recurring expenses (bills, subscriptions, etc.)
-- ============================================================================
CREATE TABLE fixed_expenses (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    label VARCHAR(100) NOT NULL,
    amount DECIMAL(19, 4) NOT NULL,
    category VARCHAR(50) NOT NULL,
    recurrence_day INT NOT NULL, -- Day of month when expense occurs
    is_active BOOLEAN DEFAULT TRUE,
    notes VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 5. DEBTS TABLE - Money user owes to others
-- ============================================================================
CREATE TABLE debts (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    initial_amount DECIMAL(19, 4) NOT NULL,
    remaining_amount DECIMAL(19, 4) NOT NULL,
    creditor VARCHAR(100) NOT NULL,
    reason VARCHAR(255),
    due_date DATE,
    notes VARCHAR(500),
    is_fully_paid BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 6. DEBT_PAYMENTS TABLE - Track debt payments
-- ============================================================================
CREATE TABLE debt_payments (
    id BIGSERIAL PRIMARY KEY,
    debt_id BIGINT NOT NULL,
    amount_paid DECIMAL(19, 4) NOT NULL,
    payment_date DATE NOT NULL,
    notes VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (debt_id) REFERENCES debts(id) ON DELETE CASCADE
);

-- ============================================================================
-- 7. DUES TABLE - Money others owe to user
-- ============================================================================
CREATE TABLE dues (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    initial_amount DECIMAL(19, 4) NOT NULL,
    remaining_amount DECIMAL(19, 4) NOT NULL,
    debtor_name VARCHAR(100) NOT NULL,
    reason VARCHAR(255),
    due_date DATE,
    notes VARCHAR(500),
    is_fully_received BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 8. DUE_PAYMENTS TABLE - Track payments received
-- ============================================================================
CREATE TABLE due_payments (
    id BIGSERIAL PRIMARY KEY,
    due_id BIGINT NOT NULL,
    amount_received DECIMAL(19, 4) NOT NULL,
    payment_date DATE NOT NULL,
    notes VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (due_id) REFERENCES dues(id) ON DELETE CASCADE
);

-- ============================================================================
-- 9. GOALS TABLE - Financial goals/targets
-- ============================================================================
CREATE TABLE goals (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(100) NOT NULL,
    target_amount DECIMAL(19, 4) NOT NULL,
    current_amount DECIMAL(19, 4) DEFAULT 0,
    deadline DATE NOT NULL,
    category VARCHAR(50),
    notes VARCHAR(500),
    is_achieved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 10. REPORTS TABLE - Financial reports and summaries
-- ============================================================================
CREATE TABLE reports (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    total_revenues DECIMAL(19, 4) DEFAULT 0,
    total_expenses DECIMAL(19, 4) DEFAULT 0,
    balance DECIMAL(19, 4),
    report_type VARCHAR(20), -- MONTHLY, QUARTERLY, ANNUAL, CUSTOM
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 11. FINANCIAL_SUMMARY TABLE - Current financial overview per user
-- ============================================================================
CREATE TABLE financial_summary (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    current_balance DECIMAL(19, 4) DEFAULT 0,
    total_debts DECIMAL(19, 4) DEFAULT 0,
    total_dues DECIMAL(19, 4) DEFAULT 0,
    total_fixed_expenses DECIMAL(19, 4) DEFAULT 0,
    total_goals_amount DECIMAL(19, 4) DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 12. AUTHENTICATION_TOKENS TABLE - For session management
-- ============================================================================
CREATE TABLE authentication_tokens (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    token_value VARCHAR(500) NOT NULL UNIQUE,
    token_type VARCHAR(50), -- PIN, BIOMETRIC, SESSION
    expires_at TIMESTAMP NOT NULL,
    is_valid BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================================
-- 13. AUDIT_LOG TABLE - Track all user actions
-- ============================================================================
CREATE TABLE audit_logs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id BIGINT,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ============================================================================
-- 14. INDEXES FOR PERFORMANCE
-- ============================================================================

-- User indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_created_at ON users(created_at);

-- Expense indexes
CREATE INDEX idx_expenses_user_id ON expenses(user_id);
CREATE INDEX idx_expenses_date ON expenses(date);
CREATE INDEX idx_expenses_category ON expenses(category);
CREATE INDEX idx_expenses_is_fixed ON expenses(is_fixed);

-- Revenue indexes
CREATE INDEX idx_revenues_user_id ON revenues(user_id);
CREATE INDEX idx_revenues_date ON revenues(date);
CREATE INDEX idx_revenues_category ON revenues(category);

-- Fixed Expense indexes
CREATE INDEX idx_fixed_expenses_user_id ON fixed_expenses(user_id);
CREATE INDEX idx_fixed_expenses_is_active ON fixed_expenses(is_active);

-- Debt indexes
CREATE INDEX idx_debts_user_id ON debts(user_id);
CREATE INDEX idx_debts_is_fully_paid ON debts(is_fully_paid);
CREATE INDEX idx_debts_due_date ON debts(due_date);

-- Debt Payment indexes
CREATE INDEX idx_debt_payments_debt_id ON debt_payments(debt_id);
CREATE INDEX idx_debt_payments_payment_date ON debt_payments(payment_date);

-- Due indexes
CREATE INDEX idx_dues_user_id ON dues(user_id);
CREATE INDEX idx_dues_is_fully_received ON dues(is_fully_received);
CREATE INDEX idx_dues_due_date ON dues(due_date);

-- Due Payment indexes
CREATE INDEX idx_due_payments_due_id ON due_payments(due_id);
CREATE INDEX idx_due_payments_payment_date ON due_payments(payment_date);

-- Goal indexes
CREATE INDEX idx_goals_user_id ON goals(user_id);
CREATE INDEX idx_goals_deadline ON goals(deadline);
CREATE INDEX idx_goals_is_achieved ON goals(is_achieved);

-- Report indexes
CREATE INDEX idx_reports_user_id ON reports(user_id);
CREATE INDEX idx_reports_period_start ON reports(period_start);

-- Authentication indexes
CREATE INDEX idx_auth_tokens_user_id ON authentication_tokens(user_id);
CREATE INDEX idx_auth_tokens_expires_at ON authentication_tokens(expires_at);

-- Audit indexes
CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

-- ============================================================================
-- 15. TRIGGERS FOR AUTOMATIC TIMESTAMP UPDATES
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply triggers to tables with updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_expenses_updated_at BEFORE UPDATE ON expenses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_revenues_updated_at BEFORE UPDATE ON revenues
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_fixed_expenses_updated_at BEFORE UPDATE ON fixed_expenses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_debts_updated_at BEFORE UPDATE ON debts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_dues_updated_at BEFORE UPDATE ON dues
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_goals_updated_at BEFORE UPDATE ON goals
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- 16. CONSTRAINT CHECKS
-- ============================================================================

-- Ensure amounts are positive
ALTER TABLE expenses ADD CONSTRAINT chk_expense_amount_positive CHECK (amount > 0);
ALTER TABLE revenues ADD CONSTRAINT chk_revenue_amount_positive CHECK (amount > 0);
ALTER TABLE fixed_expenses ADD CONSTRAINT chk_fixed_expense_amount_positive CHECK (amount > 0);
ALTER TABLE debts ADD CONSTRAINT chk_debt_initial_amount_positive CHECK (initial_amount > 0);
ALTER TABLE debts ADD CONSTRAINT chk_debt_remaining_amount CHECK (remaining_amount >= 0 AND remaining_amount <= initial_amount);
ALTER TABLE dues ADD CONSTRAINT chk_due_initial_amount_positive CHECK (initial_amount > 0);
ALTER TABLE dues ADD CONSTRAINT chk_due_remaining_amount CHECK (remaining_amount >= 0 AND remaining_amount <= initial_amount);
ALTER TABLE goals ADD CONSTRAINT chk_goal_amounts CHECK (target_amount > 0 AND current_amount >= 0);
ALTER TABLE debt_payments ADD CONSTRAINT chk_debt_payment_amount_positive CHECK (amount_paid > 0);
ALTER TABLE due_payments ADD CONSTRAINT chk_due_payment_amount_positive CHECK (amount_received > 0);

-- ============================================================================
-- 17. VIEWS FOR COMMON QUERIES
-- ============================================================================

-- Monthly expense summary per user
CREATE OR REPLACE VIEW monthly_expenses_summary AS
SELECT 
    user_id,
    DATE_TRUNC('month', date)::DATE as month,
    category,
    SUM(amount) as total_amount,
    COUNT(*) as count
FROM expenses
WHERE deleted_at IS NULL
GROUP BY user_id, DATE_TRUNC('month', date), category;

-- Monthly revenue summary per user
CREATE OR REPLACE VIEW monthly_revenues_summary AS
SELECT 
    user_id,
    DATE_TRUNC('month', date)::DATE as month,
    category,
    SUM(amount) as total_amount,
    COUNT(*) as count
FROM revenues
WHERE deleted_at IS NULL
GROUP BY user_id, DATE_TRUNC('month', date), category;

-- User financial status
CREATE OR REPLACE VIEW user_financial_status AS
SELECT 
    u.id as user_id,
    COALESCE(SUM(r.amount), 0) - COALESCE(SUM(e.amount), 0) as net_balance,
    COALESCE(SUM(CASE WHEN d.is_fully_paid = false THEN d.remaining_amount ELSE 0 END), 0) as active_debts,
    COALESCE(SUM(CASE WHEN du.is_fully_received = false THEN du.remaining_amount ELSE 0 END), 0) as active_dues
FROM users u
LEFT JOIN revenues r ON u.id = r.user_id AND r.deleted_at IS NULL
LEFT JOIN expenses e ON u.id = e.user_id AND e.deleted_at IS NULL
LEFT JOIN debts d ON u.id = d.user_id AND d.deleted_at IS NULL
LEFT JOIN dues du ON u.id = du.user_id AND du.deleted_at IS NULL
GROUP BY u.id;

-- ============================================================================
-- END OF MIGRATION V1
-- ============================================================================
