-- Migration V3: Ajouter colonne fixedExpenseId à la table expenses
-- Copie ce fichier dans: src/main/resources/db/migration/

ALTER TABLE expenses 
ADD COLUMN fixed_expense_id BIGINT;

ALTER TABLE expenses 
ADD CONSTRAINT FK_expenses_fixed_expense 
FOREIGN KEY (fixed_expense_id) 
REFERENCES fixed_expenses(id) 
ON DELETE SET NULL;

CREATE INDEX idx_expenses_fixed_expense_id ON expenses(fixed_expense_id);
