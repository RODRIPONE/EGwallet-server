-- Migration V4: Ajouter colonne is_premium à la table users
-- Copie ce fichier dans: src/main/resources/db/migration/

ALTER TABLE users 
ADD COLUMN is_premium BOOLEAN DEFAULT FALSE;
