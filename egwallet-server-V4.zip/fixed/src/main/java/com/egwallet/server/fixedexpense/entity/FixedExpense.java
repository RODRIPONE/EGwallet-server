package com.egwallet.server.fixedexpense.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * FixedExpense entity - Represents recurring expenses (bills, subscriptions, etc.)
 */
@Entity
@Table(name = "fixed_expenses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FixedExpense {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, length = 100)
    private String label;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(nullable = false)
    private Integer recurrenceDay; // Day of month when expense occurs

    @Column(columnDefinition = "BOOLEAN DEFAULT TRUE")
    @Builder.Default
    private Boolean isActive = true;

    @Column(length = 500)
    private String notes;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column
    private LocalDateTime deletedAt;

    /**
     * Apply this fixed expense to create an Expense entry
     * Used when applying recurring expenses
     */
    public void applyToExpense() {
        // Logic to create Expense from FixedExpense
    }

    @Override
    public String toString() {
        return "FixedExpense{" +
                "id=" + id +
                ", label='" + label + '\'' +
                ", amount=" + amount +
                ", category='" + category + '\'' +
                ", recurrenceDay=" + recurrenceDay +
                ", isActive=" + isActive +
                '}';
    }
}
