package com.egwallet.server.goal.repository;

import com.egwallet.server.goal.entity.Goal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface GoalRepository extends JpaRepository<Goal, Long> {
    List<Goal> findByUserIdOrderByDeadlineAsc(Long userId);
    List<Goal> findByUserIdAndIsAchievedFalseOrderByDeadlineAsc(Long userId);
    long countByUserId(Long userId);
}
