package com.egwallet.server.due.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Due entity — argent que quelqu'un doit à l'utilisateur.
 * Statuts alignés sur l'app Android.
 */
@Entity
@Table(name = "dues")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Due {

    public static final String STATUS_ACTIVE              = "active";
    public static final String STATUS_PARTIALLY_RECEIVED  = "partiellement_payee";
    public static final String STATUS_RECEIVED            = "soldee";
    public static final String STATUS_LATE                = "en_retard";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal initialAmount;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal remainingAmount;

    @Column(nullable = false, length = 100)
    private String debtorName;

    @Column(length = 255)
    private String reason;

    @Column
    private LocalDate dueDate;

    @Column(length = 500)
    private String notes;

    @Column(nullable = false, length = 30)
    @Builder.Default
    private String status = STATUS_ACTIVE;

    @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
    @Builder.Default
    private Boolean isFullyReceived = false;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column
    private LocalDateTime deletedAt;

    public void recalculateStatus() {
        if (remainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            this.status = STATUS_RECEIVED;
            this.isFullyReceived = true;
        } else if (dueDate != null && LocalDate.now().isAfter(dueDate)) {
            this.status = STATUS_LATE;
        } else if (remainingAmount.compareTo(initialAmount) < 0) {
            this.status = STATUS_PARTIALLY_RECEIVED;
        } else {
            this.status = STATUS_ACTIVE;
        }
    }

    @Override
    public String toString() {
        return "Due{id=" + id + ", debtorName='" + debtorName + "', remaining=" + remainingAmount + ", status='" + status + "'}";
    }
}
