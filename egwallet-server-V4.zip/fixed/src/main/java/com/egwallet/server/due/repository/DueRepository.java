package com.egwallet.server.due.repository;

import com.egwallet.server.due.entity.Due;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DueRepository extends JpaRepository<Due, Long> {
    List<Due> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Due> findByUserIdAndIsFullyReceivedFalseOrderByDueDateAsc(Long userId);
}
