package com.egwallet.server.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * JPA configuration for EgWallet application
 */
@Configuration
@EnableJpaRepositories(basePackages = "com.egwallet.server")
@EnableTransactionManagement
@EnableJpaAuditing
public class JpaConfig {
    // Configuration is handled by Spring Boot auto-configuration
}
