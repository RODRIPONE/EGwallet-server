package com.egwallet.server.fixedexpense.repository;

import com.egwallet.server.fixedexpense.entity.FixedExpense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FixedExpenseRepository extends JpaRepository<FixedExpense, Long> {
    List<FixedExpense> findByUserIdOrderByCreatedAtDesc(Long userId);
}
