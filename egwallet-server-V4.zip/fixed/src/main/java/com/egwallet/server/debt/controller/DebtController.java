package com.egwallet.server.debt.controller;

import com.egwallet.server.common.response.ApiResponse;
import com.egwallet.server.debt.dto.DebtResponse;
import com.egwallet.server.debt.entity.Debt;
import com.egwallet.server.debt.entity.DebtPayment;
import com.egwallet.server.debt.service.DebtService;
import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/debts")
@CrossOrigin(origins = "*")
public class DebtController {

    @Autowired private DebtService debtService;
    @Autowired private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    private DebtResponse toDTO(Debt debt) {
        return new DebtResponse(
                debt.getId(),
                debt.getUser().getId(),
                debt.getCreditor(),
                debt.getInitialAmount(),
                debt.getRemainingAmount(),
                debt.getReason(),
                debt.getDueDate(),
                debt.getIsFullyPaid(),
                debt.getStatus(),
                debt.getCreatedAt()
        );
    }

    @PostMapping
    public ApiResponse<?> createDebt(Authentication auth, @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId).orElseThrow();

            // dueDate optionnel
            LocalDate dueDate = req.get("dueDate") != null
                    ? LocalDate.parse(req.get("dueDate").toString()) : null;

            Debt debt = debtService.createDebt(
                    user,
                    (String) req.get("creditor"),
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.get("reason"),
                    dueDate,
                    (String) req.getOrDefault("notes", null)
            );
            return ApiResponse.success("Debt created", toDTO(debt));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_CREATE_FAILED");
        }
    }

    @PostMapping("/{debtId}/pay")
    public ApiResponse<?> repayDebt(Authentication auth,
                                     @PathVariable Long debtId,
                                     @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            BigDecimal amount = new BigDecimal(req.get("amount").toString());
            Debt debt = debtService.repayDebt(debtId, userId, amount);
            return ApiResponse.success("Payment recorded", toDTO(debt));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_PAY_FAILED");
        }
    }

    @GetMapping
    public ApiResponse<?> getDebts(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            List<DebtResponse> response = debtService.getUserDebts(userId)
                    .stream().map(this::toDTO).collect(Collectors.toList());
            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_GET_FAILED");
        }
    }

    @GetMapping("/{debtId}")
    public ApiResponse<?> getDebt(Authentication auth, @PathVariable Long debtId) {
        try {
            Long userId = getCurrentUserId(auth);
            return ApiResponse.success(toDTO(debtService.getDebt(debtId, userId)));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_GET_FAILED");
        }
    }

    @GetMapping("/{debtId}/payments")
    public ApiResponse<?> getDebtPayments(Authentication auth, @PathVariable Long debtId) {
        try {
            Long userId = getCurrentUserId(auth);
            List<DebtPayment> payments = debtService.getDebtPayments(debtId, userId);
            return ApiResponse.success(payments.stream().map(p -> Map.of(
                    "id", p.getId(),
                    "amountPaid", p.getAmountPaid(),
                    "paymentDate", p.getPaymentDate(),
                    "createdAt", p.getCreatedAt()
            )).collect(Collectors.toList()));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_PAYMENTS_GET_FAILED");
        }
    }

    @DeleteMapping("/{debtId}")
    public ApiResponse<?> deleteDebt(Authentication auth, @PathVariable Long debtId) {
        try {
            Long userId = getCurrentUserId(auth);
            debtService.deleteDebt(debtId, userId);
            return ApiResponse.success("Debt deleted");
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DEBT_DELETE_FAILED");
        }
    }
}
