package com.egwallet.server.revenue.service;

import com.egwallet.server.revenue.entity.Revenue;
import com.egwallet.server.revenue.repository.RevenueRepository;
import com.egwallet.server.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class RevenueService {

    @Autowired
    private RevenueRepository revenueRepository;

    @Transactional
    public Revenue createRevenue(User user, BigDecimal amount, String source,
                                  String category, LocalDate date, String notes) {
        Revenue revenue = new Revenue();
        revenue.setUser(user);
        revenue.setAmount(amount);
        revenue.setSource(source);
        revenue.setCategory(category);
        revenue.setDate(date);
        revenue.setNotes(notes);
        revenue.setCreatedAt(LocalDateTime.now());
        revenue.setUpdatedAt(LocalDateTime.now());
        return revenueRepository.save(revenue);
    }

    public List<Revenue> getUserRevenues(Long userId) {
        return revenueRepository.findByUserIdOrderByDateDesc(userId);
    }

    public Revenue getRevenue(Long revenueId, Long userId) {
        Revenue revenue = revenueRepository.findById(revenueId)
                .orElseThrow(() -> new RuntimeException("Revenue not found"));
        if (!revenue.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        return revenue;
    }

    @Transactional
    public Revenue updateRevenue(Long revenueId, Long userId,
                                  BigDecimal amount, String source, String category) {
        Revenue revenue = getRevenue(revenueId, userId);
        revenue.setAmount(amount);
        revenue.setSource(source);
        revenue.setCategory(category);
        revenue.setUpdatedAt(LocalDateTime.now());
        return revenueRepository.save(revenue);
    }

    @Transactional
    public void deleteRevenue(Long revenueId, Long userId) {
        Revenue revenue = getRevenue(revenueId, userId);
        revenueRepository.delete(revenue);
    }
}
