package com.egwallet.server.report.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "reports")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private LocalDate periodStart;

    @Column(nullable = false)
    private LocalDate periodEnd;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalRevenues = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalExpenses = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    private BigDecimal balance;

    @Column(length = 20)
    private String reportType; // MONTHLY, QUARTERLY, ANNUAL, CUSTOM

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime generatedAt = LocalDateTime.now();

    public void generatePDF() {
        // Logic to generate PDF report
    }

    @Override
    public String toString() {
        return "Report{id=" + id + ", periodStart=" + periodStart
                + ", periodEnd=" + periodEnd + ", totalRevenues=" + totalRevenues
                + ", totalExpenses=" + totalExpenses + ", balance=" + balance
                + ", reportType='" + reportType + "'}";
    }
}
