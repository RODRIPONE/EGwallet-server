package com.egwallet.server.security.auth.controller;

import com.egwallet.server.user.entity.User;
import com.egwallet.server.security.auth.service.AuthService;
import com.egwallet.server.common.response.ApiResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ApiResponse<?> register(@RequestBody Map<String, String> request) {
        try {
            User user = authService.register(request.get("username"), request.get("pin"));
            String token = authService.generateToken(user);
            return ApiResponse.success(buildAuthResponse(user, token));
        } catch (Exception e) {
            return ApiResponse.error("Registration failed: " + e.getMessage(), "REGISTER_FAILED");
        }
    }

    @PostMapping("/login")
    public ApiResponse<?> login(@RequestBody Map<String, String> request) {
        try {
            User user = authService.login(request.get("username"), request.get("pin"));
            String token = authService.generateToken(user);
            return ApiResponse.success(buildAuthResponse(user, token));
        } catch (Exception e) {
            return ApiResponse.error("Login failed: " + e.getMessage(), "LOGIN_FAILED");
        }
    }

    private AuthResponse buildAuthResponse(User user, String token) {
        return new AuthResponse(
                user.getId(),
                user.getUsername(),
                token,
                user.getBiometricEnabled(),
                user.getIsPremium(),
                user.getCreatedAt()
        );
    }

    @Data
    @AllArgsConstructor
    public static class AuthResponse {
        private Long userId;
        private String username;
        private String token;
        private Boolean biometricEnabled;
        private Boolean isPremium;

        @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
        private LocalDateTime createdAt;
    }
}
