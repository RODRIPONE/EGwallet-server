package com.egwallet.server.due.controller;

import com.egwallet.server.common.response.ApiResponse;
import com.egwallet.server.due.dto.DueResponse;
import com.egwallet.server.due.entity.Due;
import com.egwallet.server.due.entity.DuePayment;
import com.egwallet.server.due.service.DueService;
import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/dues")
@CrossOrigin(origins = "*")
public class DueController {

    @Autowired private DueService dueService;
    @Autowired private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    private DueResponse toDTO(Due due) {
        return new DueResponse(
                due.getId(),
                due.getUser().getId(),
                due.getDebtorName(),
                due.getInitialAmount(),
                due.getRemainingAmount(),
                due.getReason(),
                due.getDueDate(),
                due.getIsFullyReceived(),
                due.getStatus(),
                due.getCreatedAt()
        );
    }

    @PostMapping
    public ApiResponse<?> createDue(Authentication auth, @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId).orElseThrow();
            LocalDate dueDate = req.get("dueDate") != null
                    ? LocalDate.parse(req.get("dueDate").toString()) : null;
            Due due = dueService.createDue(
                    user,
                    (String) req.get("debtorName"),
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.get("reason"),
                    dueDate,
                    (String) req.getOrDefault("notes", null)
            );
            return ApiResponse.success("Due created", toDTO(due));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_CREATE_FAILED");
        }
    }

    @PostMapping("/{dueId}/receive")
    public ApiResponse<?> receiveDue(Authentication auth,
                                      @PathVariable Long dueId,
                                      @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            BigDecimal amount = new BigDecimal(req.get("amount").toString());
            Due due = dueService.receiveDue(dueId, userId, amount);
            return ApiResponse.success("Reception recorded", toDTO(due));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_RECEIVE_FAILED");
        }
    }

    @GetMapping
    public ApiResponse<?> getDues(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            List<DueResponse> response = dueService.getUserDues(userId)
                    .stream().map(this::toDTO).collect(Collectors.toList());
            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_GET_FAILED");
        }
    }

    @GetMapping("/{dueId}")
    public ApiResponse<?> getDue(Authentication auth, @PathVariable Long dueId) {
        try {
            Long userId = getCurrentUserId(auth);
            return ApiResponse.success(toDTO(dueService.getDue(dueId, userId)));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_GET_FAILED");
        }
    }

    @GetMapping("/{dueId}/payments")
    public ApiResponse<?> getDuePayments(Authentication auth, @PathVariable Long dueId) {
        try {
            Long userId = getCurrentUserId(auth);
            List<DuePayment> payments = dueService.getDuePayments(dueId, userId);
            return ApiResponse.success(payments.stream().map(p -> Map.of(
                    "id", p.getId(),
                    "amountReceived", p.getAmountReceived(),
                    "paymentDate", p.getPaymentDate(),
                    "createdAt", p.getCreatedAt()
            )).collect(Collectors.toList()));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_PAYMENTS_GET_FAILED");
        }
    }

    @DeleteMapping("/{dueId}")
    public ApiResponse<?> deleteDue(Authentication auth, @PathVariable Long dueId) {
        try {
            Long userId = getCurrentUserId(auth);
            dueService.deleteDue(dueId, userId);
            return ApiResponse.success("Due deleted");
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "DUE_DELETE_FAILED");
        }
    }
}
