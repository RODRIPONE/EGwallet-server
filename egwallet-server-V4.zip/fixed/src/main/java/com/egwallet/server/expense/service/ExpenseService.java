package com.egwallet.server.expense.service;

import com.egwallet.server.expense.dto.ExpenseResponse;
import com.egwallet.server.expense.entity.Expense;
import com.egwallet.server.expense.repository.ExpenseRepository;
import com.egwallet.server.fixedexpense.entity.FixedExpense;
import com.egwallet.server.fixedexpense.repository.FixedExpenseRepository;
import com.egwallet.server.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExpenseService {

    @Autowired private ExpenseRepository expenseRepository;
    @Autowired private FixedExpenseRepository fixedExpenseRepository;

    /** Convertit une Expense en DTO — méthode centralisée pour éviter la duplication */
    public ExpenseResponse toDTO(Expense e) {
        return new ExpenseResponse(
                e.getId(),
                e.getUser().getId(),
                e.getAmount(),
                e.getReason(),
                e.getCategory(),
                e.getDate(),
                e.getIsFixed(),
                e.getFixedExpense() != null ? e.getFixedExpense().getId() : null,
                e.getCreatedAt()
        );
    }

    @Transactional
    public Expense createExpense(User user, BigDecimal amount, String reason,
                                  String category, LocalDate date, String notes) {
        return createExpense(user, amount, reason, category, date, notes, null);
    }

    @Transactional
    public Expense createExpense(User user, BigDecimal amount, String reason,
                                  String category, LocalDate date, String notes,
                                  Long fixedExpenseId) {
        Expense expense = new Expense();
        expense.setUser(user);
        expense.setAmount(amount);
        expense.setReason(reason);
        expense.setCategory(category);
        expense.setDate(date);
        expense.setNotes(notes);
        expense.setIsFixed(fixedExpenseId != null);
        expense.setCreatedAt(LocalDateTime.now());
        expense.setUpdatedAt(LocalDateTime.now());

        if (fixedExpenseId != null) {
            fixedExpenseRepository.findById(fixedExpenseId)
                    .ifPresent(expense::setFixedExpense);
        }

        return expenseRepository.save(expense);
    }

    public List<Expense> getUserExpenses(Long userId) {
        return expenseRepository.findByUserIdOrderByDateDesc(userId);
    }

    public Expense getExpense(Long expenseId, Long userId) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new RuntimeException("Expense not found"));
        if (!expense.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        return expense;
    }

    @Transactional
    public Expense updateExpense(Long expenseId, Long userId,
                                  BigDecimal amount, String reason, String category) {
        Expense expense = getExpense(expenseId, userId);
        expense.setAmount(amount);
        expense.setReason(reason);
        expense.setCategory(category);
        expense.setUpdatedAt(LocalDateTime.now());
        return expenseRepository.save(expense);
    }

    @Transactional
    public void deleteExpense(Long expenseId, Long userId) {
        expenseRepository.delete(getExpense(expenseId, userId));
    }
}
