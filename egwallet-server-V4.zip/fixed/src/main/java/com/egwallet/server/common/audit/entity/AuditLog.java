package com.egwallet.server.common.audit.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * AuditLog entity — journal de toutes les actions utilisateur.
 * Mapping JSONB natif Hibernate 6+ via @JdbcTypeCode(SqlTypes.JSON).
 * Ne nécessite plus hypersistence-utils.
 */
@Entity
@Table(name = "audit_logs")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(nullable = false, length = 100)
    private String action;

    @Column(length = 50)
    private String entityType;

    @Column
    private Long entityId;

    // Hibernate 6+ gère nativement le mapping Map<String,Object> → JSONB PostgreSQL
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb")
    private Map<String, Object> details;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Override
    public String toString() {
        return "AuditLog{id=" + id + ", action='" + action + "', entityType='" + entityType + "'}";
    }
}
