package com.egwallet.server.due.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class DueResponse {
    private Long id;
    private Long userId;
    private String debtorName;
    private BigDecimal initialAmount;
    private BigDecimal remainingAmount;
    private String reason;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dueDate;

    private Boolean isFullyReceived;
    private String status;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;
}

@Data
class DueRequest {
    private String debtorName;
    private BigDecimal amount;
    private String reason;
    private LocalDate dueDate;
}

@Data
class DuePaymentRequest {
    private BigDecimal amount;
}
