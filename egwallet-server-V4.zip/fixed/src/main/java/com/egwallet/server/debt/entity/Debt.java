package com.egwallet.server.debt.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Debt entity — argent que l'utilisateur doit à quelqu'un.
 * Statuts alignés sur l'app Android :
 *   active | partiellement_payee | soldee | en_retard
 */
@Entity
@Table(name = "debts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Debt {

    // Constantes de statut — identiques à l'app Android
    public static final String STATUS_ACTIVE           = "active";
    public static final String STATUS_PARTIALLY_PAID   = "partiellement_payee";
    public static final String STATUS_PAID             = "soldee";
    public static final String STATUS_LATE             = "en_retard";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal initialAmount;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal remainingAmount;

    @Column(nullable = false, length = 100)
    private String creditor;

    @Column(length = 255)
    private String reason;

    @Column
    private LocalDate dueDate;

    @Column(length = 500)
    private String notes;

    /** Statut aligné sur Android : active | partiellement_payee | soldee | en_retard */
    @Column(nullable = false, length = 30)
    @Builder.Default
    private String status = STATUS_ACTIVE;

    @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
    @Builder.Default
    private Boolean isFullyPaid = false;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column
    private LocalDateTime deletedAt;

    /** Recalcule le statut à partir du solde restant et de la date d'échéance */
    public void recalculateStatus() {
        if (remainingAmount.compareTo(BigDecimal.ZERO) <= 0) {
            this.status = STATUS_PAID;
            this.isFullyPaid = true;
        } else if (dueDate != null && LocalDate.now().isAfter(dueDate)) {
            this.status = STATUS_LATE;
        } else if (remainingAmount.compareTo(initialAmount) < 0) {
            this.status = STATUS_PARTIALLY_PAID;
        } else {
            this.status = STATUS_ACTIVE;
        }
    }

    @Override
    public String toString() {
        return "Debt{id=" + id + ", creditor='" + creditor + "', remaining=" + remainingAmount + ", status='" + status + "'}";
    }
}
