package com.egwallet.server.due.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DuePayment entity - Tracks payments received from dues
 */
@Entity
@Table(name = "due_payments")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DuePayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "due_id", nullable = false)
    private Due due;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal amountReceived;

    @Column(nullable = false)
    private LocalDate paymentDate;

    @Column(length = 500)
    private String notes;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Override
    public String toString() {
        return "DuePayment{" +
                "id=" + id +
                ", amountReceived=" + amountReceived +
                ", paymentDate=" + paymentDate +
                '}';
    }
}
