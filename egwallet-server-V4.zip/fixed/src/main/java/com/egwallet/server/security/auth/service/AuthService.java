package com.egwallet.server.security.auth.service;

import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import com.egwallet.server.security.auth.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User register(String username, String pinCode) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new RuntimeException("User already exists");
        }

        User user = new User();
        user.setUsername(username);
        user.setPinCode(passwordEncoder.encode(pinCode));
        user.setBiometricEnabled(false);
        user.setCreatedAt(LocalDateTime.now());

        return userRepository.save(user);
    }

    public User login(String username, String pinCode) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(pinCode, user.getPinCode())) {
            throw new RuntimeException("Invalid PIN");
        }

        return user;
    }

    public String generateToken(User user) {
        return jwtUtil.generateToken(user.getId(), user.getUsername());
    }
}
