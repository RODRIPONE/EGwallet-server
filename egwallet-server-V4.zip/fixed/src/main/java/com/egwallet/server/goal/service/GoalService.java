package com.egwallet.server.goal.service;

import com.egwallet.server.goal.entity.Goal;
import com.egwallet.server.goal.repository.GoalRepository;
import com.egwallet.server.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class GoalService {

    private static final int MAX_FREE_GOALS = 3;

    @Autowired
    private GoalRepository goalRepository;

    @Transactional
    public Goal createGoal(User user, String title, String emoji,
                            BigDecimal targetAmount, LocalDate deadline,
                            String category, String notes) {
        // Plan gratuit : 3 objectifs max. Plan Premium : illimité.
        if (!Boolean.TRUE.equals(user.getIsPremium())) {
            long count = goalRepository.countByUserId(user.getId());
            if (count >= MAX_FREE_GOALS) {
                throw new RuntimeException("FREE_PLAN_LIMIT: Maximum " + MAX_FREE_GOALS
                        + " goals on free plan. Upgrade to Premium for unlimited goals.");
            }
        }

        Goal goal = new Goal();
        goal.setUser(user);
        goal.setTitle(title);
        goal.setEmoji(emoji);
        goal.setTargetAmount(targetAmount);
        goal.setCurrentAmount(BigDecimal.ZERO);
        goal.setDeadline(deadline);
        goal.setCategory(category);
        goal.setNotes(notes);
        goal.setIsAchieved(false);
        goal.setCreatedAt(LocalDateTime.now());
        goal.setUpdatedAt(LocalDateTime.now());

        return goalRepository.save(goal);
    }

    public List<Goal> getUserGoals(Long userId) {
        return goalRepository.findByUserIdOrderByDeadlineAsc(userId);
    }

    @Transactional
    public Goal addContribution(Long goalId, Long userId, BigDecimal amount) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new RuntimeException("Goal not found"));
        if (!goal.getUser().getId().equals(userId)) throw new RuntimeException("Unauthorized");
        if (amount.compareTo(BigDecimal.ZERO) <= 0) throw new RuntimeException("Amount must be > 0");

        goal.addContribution(amount);
        goal.setUpdatedAt(LocalDateTime.now());
        return goalRepository.save(goal);
    }

    @Transactional
    public void deleteGoal(Long goalId, Long userId) {
        Goal goal = goalRepository.findById(goalId)
                .orElseThrow(() -> new RuntimeException("Goal not found"));
        if (!goal.getUser().getId().equals(userId)) throw new RuntimeException("Unauthorized");
        goalRepository.delete(goal);
    }
}
