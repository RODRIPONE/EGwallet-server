package com.egwallet.server.user.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "financial_summary")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FinancialSummary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal currentBalance = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalDebts = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalDues = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalFixedExpenses = BigDecimal.ZERO;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal totalGoalsAmount = BigDecimal.ZERO;

    @Column
    @Builder.Default
    private LocalDateTime lastUpdated = LocalDateTime.now();

    public BigDecimal calculateBalance() {
        return currentBalance;
    }

    public Object getMonthlyReport(java.time.LocalDate month) {
        return null;
    }

    @Override
    public String toString() {
        return "FinancialSummary{id=" + id + ", currentBalance=" + currentBalance
                + ", totalDebts=" + totalDebts + ", totalDues=" + totalDues
                + ", lastUpdated=" + lastUpdated + "}";
    }
}
