package com.egwallet.server.revenue.controller;

import com.egwallet.server.common.response.ApiResponse;
import com.egwallet.server.revenue.dto.RevenueResponse;
import com.egwallet.server.revenue.entity.Revenue;
import com.egwallet.server.revenue.service.RevenueService;
import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/revenues")
@CrossOrigin(origins = "*")
public class RevenueController {

    @Autowired private RevenueService revenueService;
    @Autowired private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    private RevenueResponse toDTO(Revenue r) {
        return new RevenueResponse(
                r.getId(),
                r.getUser().getId(),
                r.getAmount(),
                r.getSource(),
                r.getCategory(),
                r.getDate(),
                r.getCreatedAt()
        );
    }

    @PostMapping
    public ApiResponse<?> createRevenue(Authentication auth, @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId).orElseThrow();
            Revenue revenue = revenueService.createRevenue(
                    user,
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.get("source"),
                    (String) req.getOrDefault("category", null),
                    LocalDate.parse(req.get("date").toString()),
                    (String) req.getOrDefault("notes", null)
            );
            return ApiResponse.success("Revenue created", toDTO(revenue));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "REVENUE_CREATE_FAILED");
        }
    }

    @GetMapping
    public ApiResponse<?> getRevenues(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            List<RevenueResponse> response = revenueService.getUserRevenues(userId)
                    .stream().map(this::toDTO).collect(Collectors.toList());
            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "REVENUE_GET_FAILED");
        }
    }

    @PutMapping("/{revenueId}")
    public ApiResponse<?> updateRevenue(Authentication auth,
                                         @PathVariable Long revenueId,
                                         @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            Revenue revenue = revenueService.updateRevenue(
                    revenueId, userId,
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.get("source"),
                    (String) req.getOrDefault("category", null)
            );
            return ApiResponse.success("Revenue updated", toDTO(revenue));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "REVENUE_UPDATE_FAILED");
        }
    }

    @DeleteMapping("/{revenueId}")
    public ApiResponse<?> deleteRevenue(Authentication auth, @PathVariable Long revenueId) {
        try {
            Long userId = getCurrentUserId(auth);
            revenueService.deleteRevenue(revenueId, userId);
            return ApiResponse.success("Revenue deleted");
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "REVENUE_DELETE_FAILED");
        }
    }
}
