package com.egwallet.server.debt.service;

import com.egwallet.server.debt.entity.Debt;
import com.egwallet.server.debt.entity.DebtPayment;
import com.egwallet.server.debt.repository.DebtRepository;
import com.egwallet.server.debt.repository.DebtPaymentRepository;
import com.egwallet.server.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class DebtService {

    @Autowired
    private DebtRepository debtRepository;

    @Autowired
    private DebtPaymentRepository debtPaymentRepository;

    @Transactional
    public Debt createDebt(User user, String creditor, BigDecimal amount,
                           String reason, LocalDate dueDate, String notes) {
        Debt debt = new Debt();
        debt.setUser(user);
        debt.setCreditor(creditor);
        debt.setInitialAmount(amount);
        debt.setRemainingAmount(amount);
        debt.setReason(reason);
        debt.setDueDate(dueDate);
        debt.setNotes(notes);
        debt.setStatus(Debt.STATUS_ACTIVE);
        debt.setIsFullyPaid(false);
        debt.setCreatedAt(LocalDateTime.now());
        debt.setUpdatedAt(LocalDateTime.now());

        // Détecter dès la création si la date est déjà dépassée
        debt.recalculateStatus();
        return debtRepository.save(debt);
    }

    @Transactional
    public Debt repayDebt(Long debtId, Long userId, BigDecimal amountPaid) {
        Debt debt = debtRepository.findById(debtId)
                .orElseThrow(() -> new RuntimeException("Debt not found"));

        if (!debt.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        if (amountPaid.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Amount must be > 0");
        }
        if (amountPaid.compareTo(debt.getRemainingAmount()) > 0) {
            throw new RuntimeException("Amount exceeds remaining debt");
        }

        // Enregistrer le paiement
        DebtPayment payment = new DebtPayment();
        payment.setDebt(debt);
        payment.setAmountPaid(amountPaid);
        payment.setPaymentDate(LocalDate.now());
        payment.setCreatedAt(LocalDateTime.now());
        debtPaymentRepository.save(payment);

        // Mettre à jour le solde et le statut (atomique avec @Transactional)
        BigDecimal newRemaining = debt.getRemainingAmount().subtract(amountPaid);
        debt.setRemainingAmount(newRemaining);
        debt.recalculateStatus();
        debt.setUpdatedAt(LocalDateTime.now());

        return debtRepository.save(debt);
    }

    public List<Debt> getUserDebts(Long userId) {
        return debtRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public Debt getDebt(Long debtId, Long userId) {
        Debt debt = debtRepository.findById(debtId)
                .orElseThrow(() -> new RuntimeException("Debt not found"));
        if (!debt.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        return debt;
    }

    @Transactional
    public void deleteDebt(Long debtId, Long userId) {
        Debt debt = getDebt(debtId, userId);
        debtRepository.delete(debt);
    }

    public List<DebtPayment> getDebtPayments(Long debtId, Long userId) {
        // Vérification anti-IDOR avant d'exposer les paiements
        getDebt(debtId, userId);
        return debtPaymentRepository.findByDebtIdOrderByPaymentDateDesc(debtId);
    }
}
