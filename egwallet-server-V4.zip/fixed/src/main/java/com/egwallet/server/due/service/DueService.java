package com.egwallet.server.due.service;

import com.egwallet.server.due.entity.Due;
import com.egwallet.server.due.entity.DuePayment;
import com.egwallet.server.due.repository.DueRepository;
import com.egwallet.server.due.repository.DuePaymentRepository;
import com.egwallet.server.user.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class DueService {

    @Autowired
    private DueRepository dueRepository;

    @Autowired
    private DuePaymentRepository duePaymentRepository;

    @Transactional
    public Due createDue(User user, String debtorName, BigDecimal amount,
                         String reason, LocalDate dueDate, String notes) {
        Due due = new Due();
        due.setUser(user);
        due.setDebtorName(debtorName);
        due.setInitialAmount(amount);
        due.setRemainingAmount(amount);
        due.setReason(reason);
        due.setDueDate(dueDate);
        due.setNotes(notes);
        due.setStatus(Due.STATUS_ACTIVE);
        due.setIsFullyReceived(false);
        due.setCreatedAt(LocalDateTime.now());
        due.setUpdatedAt(LocalDateTime.now());
        due.recalculateStatus();
        return dueRepository.save(due);
    }

    @Transactional
    public Due receiveDue(Long dueId, Long userId, BigDecimal amountReceived) {
        Due due = dueRepository.findById(dueId)
                .orElseThrow(() -> new RuntimeException("Due not found"));

        if (!due.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        if (amountReceived.compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Amount must be > 0");
        }
        if (amountReceived.compareTo(due.getRemainingAmount()) > 0) {
            throw new RuntimeException("Amount exceeds remaining due");
        }

        DuePayment payment = new DuePayment();
        payment.setDue(due);
        payment.setAmountReceived(amountReceived);
        payment.setPaymentDate(LocalDate.now());
        payment.setCreatedAt(LocalDateTime.now());
        duePaymentRepository.save(payment);

        BigDecimal newRemaining = due.getRemainingAmount().subtract(amountReceived);
        due.setRemainingAmount(newRemaining);
        due.recalculateStatus();
        due.setUpdatedAt(LocalDateTime.now());

        return dueRepository.save(due);
    }

    public List<Due> getUserDues(Long userId) {
        return dueRepository.findByUserIdOrderByCreatedAtDesc(userId);
    }

    public Due getDue(Long dueId, Long userId) {
        Due due = dueRepository.findById(dueId)
                .orElseThrow(() -> new RuntimeException("Due not found"));
        if (!due.getUser().getId().equals(userId)) {
            throw new RuntimeException("Unauthorized");
        }
        return due;
    }

    @Transactional
    public void deleteDue(Long dueId, Long userId) {
        Due due = getDue(dueId, userId);
        dueRepository.delete(due);
    }

    public List<DuePayment> getDuePayments(Long dueId, Long userId) {
        getDue(dueId, userId);
        return duePaymentRepository.findByDueIdOrderByPaymentDateDesc(dueId);
    }
}
