package com.egwallet.server.user.repository;

import com.egwallet.server.user.entity.FinancialSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface FinancialSummaryRepository extends JpaRepository<FinancialSummary, Long> {
    Optional<FinancialSummary> findByUserId(Long userId);
}
