package com.egwallet.server.common.exception;

/**
 * Base exception — public car référencée depuis GlobalExceptionHandler
 */
public class EgWalletException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    private final String errorCode;

    public EgWalletException(String message) {
        super(message);
        this.errorCode = "EGW_ERROR";
    }

    public EgWalletException(String errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

    public String getErrorCode() { return errorCode; }
}

// Les classes suivantes ne sont pas public : Java exige que seule la classe
// dont le nom correspond au fichier soit public. On les laisse package-private,
// elles sont utilisées uniquement dans ce package (GlobalExceptionHandler).
class ResourceNotFoundException extends EgWalletException {
    private static final long serialVersionUID = 1L;

    ResourceNotFoundException(String resourceName, Long id) {
        super("NOT_FOUND", resourceName + " not found with id: " + id);
    }

    ResourceNotFoundException(String message) {
        super("NOT_FOUND", message);
    }
}

class AuthenticationException extends EgWalletException {
    private static final long serialVersionUID = 1L;

    AuthenticationException(String message) {
        super("AUTH_FAILED", message);
    }
}

class InvalidPINException extends EgWalletException {
    private static final long serialVersionUID = 1L;

    InvalidPINException(String message) {
        super("INVALID_PIN", message);
    }
}

class InvalidAmountException extends EgWalletException {
    private static final long serialVersionUID = 1L;

    InvalidAmountException(String message) {
        super("INVALID_AMOUNT", message);
    }
}
