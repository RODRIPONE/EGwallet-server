package com.egwallet.server.user.controller;

import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.dto.UserResponse;
import com.egwallet.server.user.repository.UserRepository;
import com.egwallet.server.common.response.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    @GetMapping("/me")
    public ApiResponse<?> getCurrentUser(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            // Ne JAMAIS retourner l'entité brute avec le PIN !
            UserResponse response = new UserResponse(
                    user.getId(),
                    user.getUsername(),
                    user.getBiometricEnabled(),
                    user.getIsPremium(),   // ajouté
                    user.getCreatedAt()
            );

            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "USER_GET_FAILED");
        }
    }
}
