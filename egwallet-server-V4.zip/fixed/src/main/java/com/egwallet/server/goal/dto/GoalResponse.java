package com.egwallet.server.goal.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class GoalResponse {
    private Long id;
    private Long userId;
    private String title;
    private String emoji;
    private BigDecimal targetAmount;
    private BigDecimal currentAmount;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate deadline;

    private String category;
    private Boolean isAchieved;
    private Double progressPercentage;
    private Integer monthsRemaining;
    private BigDecimal requiredMonthlyContribution;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;
}

@Data
class GoalRequest {
    private String title;
    private String emoji;
    private BigDecimal targetAmount;
    private LocalDate deadline;
    private String category;
    private String notes;
}

@Data
class GoalContributionRequest {
    private BigDecimal amount;
}
