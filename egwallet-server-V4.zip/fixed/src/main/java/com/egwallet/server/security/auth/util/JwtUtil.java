package com.egwallet.server.security.auth.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.util.Date;

/**
 * Utilitaire JWT — API jjwt 0.12.x :
 *   - parserBuilder()  → supprimée, remplacée par parser()
 *   - parseClaimsJws() → supprimée, remplacée par parseSignedClaims()
 *   - .body            → remplacé par .getPayload()
 *   - SignatureAlgorithm.HS256 dans signWith() → déprécié, la clé porte déjà l'algo
 */
@Component
public class JwtUtil {

    @Value("${jwt.secret:EgWallet2026SuperSecretKeyChangeThisInProduction1234567890123456}")
    private String jwtSecret;

    @Value("${jwt.expiration:86400000}")
    private long jwtExpiration;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(jwtSecret.getBytes());
    }

    public String generateToken(Long userId, String username) {
        return Jwts.builder()
                .subject(username)
                .claim("userId", userId)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + jwtExpiration))
                .signWith(getSigningKey())          // 0.12.x : pas besoin de préciser l'algo
                .compact();
    }

    public Claims extractAllClaims(String token) {
        return Jwts.parser()                        // 0.12.x : parser() remplace parserBuilder()
                .verifyWith(getSigningKey())         // 0.12.x : verifyWith() remplace setSigningKey()
                .build()
                .parseSignedClaims(token)           // 0.12.x : remplace parseClaimsJws()
                .getPayload();                      // 0.12.x : getPayload() remplace getBody()
    }

    public Long getUserId(String token) {
        return extractAllClaims(token).get("userId", Long.class);
    }

    public String getUsername(String token) {
        return extractAllClaims(token).getSubject();
    }

    public boolean isTokenValid(String token) {
        try {
            Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
