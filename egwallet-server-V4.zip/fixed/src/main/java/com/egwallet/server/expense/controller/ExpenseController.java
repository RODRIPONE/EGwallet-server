package com.egwallet.server.expense.controller;

import com.egwallet.server.common.response.ApiResponse;
import com.egwallet.server.expense.dto.ExpenseResponse;
import com.egwallet.server.expense.entity.Expense;
import com.egwallet.server.expense.service.ExpenseService;
import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/expenses")
@CrossOrigin(origins = "*")
public class ExpenseController {

    @Autowired private ExpenseService expenseService;
    @Autowired private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    @PostMapping
    public ApiResponse<?> createExpense(Authentication auth, @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId).orElseThrow();

            Long fixedExpenseId = req.get("fixedExpenseId") != null
                    ? Long.valueOf(req.get("fixedExpenseId").toString()) : null;

            Expense expense = expenseService.createExpense(
                    user,
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.getOrDefault("reason", null),
                    (String) req.get("category"),
                    LocalDate.parse(req.get("date").toString()),
                    (String) req.getOrDefault("notes", null),
                    fixedExpenseId
            );
            return ApiResponse.success("Expense created", expenseService.toDTO(expense));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "EXPENSE_CREATE_FAILED");
        }
    }

    @GetMapping
    public ApiResponse<?> getExpenses(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            List<ExpenseResponse> response = expenseService.getUserExpenses(userId)
                    .stream().map(expenseService::toDTO).collect(Collectors.toList());
            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "EXPENSE_GET_FAILED");
        }
    }

    @PutMapping("/{expenseId}")
    public ApiResponse<?> updateExpense(Authentication auth, @PathVariable Long expenseId,
                                         @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            Expense expense = expenseService.updateExpense(
                    expenseId, userId,
                    new BigDecimal(req.get("amount").toString()),
                    (String) req.getOrDefault("reason", null),
                    (String) req.get("category")
            );
            return ApiResponse.success("Expense updated", expenseService.toDTO(expense));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "EXPENSE_UPDATE_FAILED");
        }
    }

    @DeleteMapping("/{expenseId}")
    public ApiResponse<?> deleteExpense(Authentication auth, @PathVariable Long expenseId) {
        try {
            expenseService.deleteExpense(expenseId, getCurrentUserId(auth));
            return ApiResponse.success("Expense deleted");
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "EXPENSE_DELETE_FAILED");
        }
    }
}
