package com.egwallet.server.goal.controller;

import com.egwallet.server.common.response.ApiResponse;
import com.egwallet.server.goal.dto.GoalResponse;
import com.egwallet.server.goal.entity.Goal;
import com.egwallet.server.goal.service.GoalService;
import com.egwallet.server.user.entity.User;
import com.egwallet.server.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/goals")
@CrossOrigin(origins = "*")
public class GoalController {

    @Autowired private GoalService goalService;
    @Autowired private UserRepository userRepository;

    private Long getCurrentUserId(Authentication auth) {
        return (Long) auth.getDetails();
    }

    private GoalResponse toDTO(Goal g) {
        return new GoalResponse(
                g.getId(),
                g.getUser().getId(),
                g.getTitle(),
                g.getEmoji(),
                g.getTargetAmount(),
                g.getCurrentAmount(),
                g.getDeadline(),
                g.getCategory(),
                g.getIsAchieved(),
                g.getProgressPercentage(),
                g.getMonthsRemaining(),
                g.getRequiredMonthlyContribution(),
                g.getCreatedAt()
        );
    }

    @PostMapping
    public ApiResponse<?> createGoal(Authentication auth, @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            User user = userRepository.findById(userId).orElseThrow();
            Goal goal = goalService.createGoal(
                    user,
                    (String) req.get("title"),
                    (String) req.getOrDefault("emoji", null),
                    new BigDecimal(req.get("targetAmount").toString()),
                    LocalDate.parse(req.get("deadline").toString()),
                    (String) req.getOrDefault("category", null),
                    (String) req.getOrDefault("notes", null)
            );
            return ApiResponse.success("Goal created", toDTO(goal));
        } catch (RuntimeException e) {
            // Exposer le code d'erreur FREE_PLAN_LIMIT pour que l'Android affiche le paywall
            String code = e.getMessage().startsWith("FREE_PLAN_LIMIT") ? "FREE_PLAN_LIMIT" : "GOAL_CREATE_FAILED";
            return ApiResponse.error(e.getMessage(), code);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "GOAL_CREATE_FAILED");
        }
    }

    @GetMapping
    public ApiResponse<?> getGoals(Authentication auth) {
        try {
            Long userId = getCurrentUserId(auth);
            List<GoalResponse> response = goalService.getUserGoals(userId)
                    .stream().map(this::toDTO).collect(Collectors.toList());
            return ApiResponse.success(response);
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "GOAL_GET_FAILED");
        }
    }

    @PostMapping("/{goalId}/contribute")
    public ApiResponse<?> contribute(Authentication auth,
                                      @PathVariable Long goalId,
                                      @RequestBody Map<String, Object> req) {
        try {
            Long userId = getCurrentUserId(auth);
            BigDecimal amount = new BigDecimal(req.get("amount").toString());
            Goal goal = goalService.addContribution(goalId, userId, amount);
            return ApiResponse.success("Contribution added", toDTO(goal));
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "GOAL_CONTRIBUTE_FAILED");
        }
    }

    @DeleteMapping("/{goalId}")
    public ApiResponse<?> deleteGoal(Authentication auth, @PathVariable Long goalId) {
        try {
            Long userId = getCurrentUserId(auth);
            goalService.deleteGoal(goalId, userId);
            return ApiResponse.success("Goal deleted");
        } catch (Exception e) {
            return ApiResponse.error(e.getMessage(), "GOAL_DELETE_FAILED");
        }
    }
}
