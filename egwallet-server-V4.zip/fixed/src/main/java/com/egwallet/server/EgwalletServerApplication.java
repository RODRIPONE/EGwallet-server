package com.egwallet.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EgwalletServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EgwalletServerApplication.class, args);
	}

}
