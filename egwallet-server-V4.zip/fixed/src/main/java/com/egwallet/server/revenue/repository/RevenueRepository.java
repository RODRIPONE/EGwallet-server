package com.egwallet.server.revenue.repository;

import com.egwallet.server.revenue.entity.Revenue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RevenueRepository extends JpaRepository<Revenue, Long> {
    List<Revenue> findByUserIdOrderByDateDesc(Long userId);
}
