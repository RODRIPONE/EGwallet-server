package com.egwallet.server.goal.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "goals")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Goal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, length = 100)
    private String title;

    /** Emoji de l'objectif — parité avec l'app Android (ex : 🚗, 💰, ✈️) */
    @Column(length = 10)
    private String emoji;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal targetAmount;

    @Column(precision = 19, scale = 4)
    @Builder.Default
    private BigDecimal currentAmount = BigDecimal.ZERO;

    @Column(nullable = false)
    private LocalDate deadline;

    @Column(length = 50)
    private String category;

    @Column(length = 500)
    private String notes;

    @Column(columnDefinition = "BOOLEAN DEFAULT FALSE")
    @Builder.Default
    private Boolean isAchieved = false;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    @Column
    @Builder.Default
    private LocalDateTime updatedAt = LocalDateTime.now();

    @Column
    private LocalDateTime deletedAt;

    public Double getProgressPercentage() {
        if (targetAmount.compareTo(BigDecimal.ZERO) == 0) return 0.0;
        return Math.min((currentAmount.doubleValue() / targetAmount.doubleValue()) * 100, 100.0);
    }

    public Integer getMonthsRemaining() {
        if (deadline == null) return null;
        long days = java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), deadline);
        return (int) Math.max(0, days / 30);
    }

    public BigDecimal getRequiredMonthlyContribution() {
        int months = getMonthsRemaining();
        if (months <= 0) return BigDecimal.ZERO;
        BigDecimal remaining = targetAmount.subtract(currentAmount);
        if (remaining.compareTo(BigDecimal.ZERO) <= 0) return BigDecimal.ZERO;
        return remaining.divide(BigDecimal.valueOf(months), 4, java.math.RoundingMode.CEILING);
    }

    public void addContribution(BigDecimal amount) {
        this.currentAmount = this.currentAmount.add(amount);
        if (this.currentAmount.compareTo(this.targetAmount) >= 0) {
            this.isAchieved = true;
        }
    }

    @Override
    public String toString() {
        return "Goal{id=" + id + ", title='" + title + "', progress=" + getProgressPercentage() + "%, isAchieved=" + isAchieved + "}";
    }
}
