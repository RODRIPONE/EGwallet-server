package com.egwallet.server.due.repository;

import com.egwallet.server.due.entity.DuePayment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DuePaymentRepository extends JpaRepository<DuePayment, Long> {
    List<DuePayment> findByDueIdOrderByPaymentDateDesc(Long dueId);
}
