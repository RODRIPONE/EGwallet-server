package com.egwallet.server.debt.repository;

import com.egwallet.server.debt.entity.Debt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface DebtRepository extends JpaRepository<Debt, Long> {
    List<Debt> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Debt> findByUserIdAndIsFullyPaidFalseOrderByDueDateAsc(Long userId);
}
