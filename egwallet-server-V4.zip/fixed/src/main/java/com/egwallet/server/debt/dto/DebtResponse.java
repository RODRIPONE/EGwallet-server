package com.egwallet.server.debt.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class DebtResponse {
    private Long id;
    private Long userId;
    private String creditor;
    private BigDecimal initialAmount;
    private BigDecimal remainingAmount;
    private String reason;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dueDate;

    private Boolean isFullyPaid;
    private String status;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;
}

@Data
class DebtRequest {
    private String creditor;
    private BigDecimal amount;
    private String reason;
    private LocalDate dueDate;
}

@Data
class DebtPaymentRequest {
    private BigDecimal amount;
}
