package com.egwallet.server.expense.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class ExpenseResponse {
    private Long id;
    private Long userId;
    private BigDecimal amount;
    private String reason;
    private String category;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate date;

    private Boolean isFixed;
    private Long fixedExpenseId;

    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdAt;
}
