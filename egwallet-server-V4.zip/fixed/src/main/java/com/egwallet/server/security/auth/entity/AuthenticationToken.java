package com.egwallet.server.security.auth.entity;

import com.egwallet.server.user.entity.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "authentication_tokens")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuthenticationToken {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false, length = 500, unique = true)
    private String tokenValue;

    @Column(length = 50)
    private String tokenType; // PIN, BIOMETRIC, SESSION

    // PAS de @Builder.Default ici : expiresAt est fourni à la construction (pas une valeur fixe)
    @Column(nullable = false)
    private LocalDateTime expiresAt;

    @Column(columnDefinition = "BOOLEAN DEFAULT TRUE")
    @Builder.Default
    private Boolean isValid = true;

    @Column(updatable = false)
    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();

    public boolean isTokenValid() {
        return isValid != null && isValid && LocalDateTime.now().isBefore(expiresAt);
    }

    public void invalidate() {
        this.isValid = false;
    }

    @Override
    public String toString() {
        return "AuthenticationToken{id=" + id + ", tokenType='" + tokenType
                + "', expiresAt=" + expiresAt + ", isValid=" + isValid + "}";
    }
}
