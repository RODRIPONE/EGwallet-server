plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.egwallet"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.egwallet"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.activity.ktx)
    implementation(libs.appcompat)
    implementation(libs.constraintlayout)
    implementation(libs.material)

    // Room (persistance locale / cache)
    implementation(libs.room.runtime)
    annotationProcessor(libs.room.compiler)

    // Lifecycle (ViewModel + LiveData)
    implementation(libs.lifecycle.viewmodel)
    implementation(libs.lifecycle.livedata)

    // Navigation Component (bottom nav 5 onglets)
    implementation(libs.navigation.fragment)
    implementation(libs.navigation.ui)

    // Biometrie (deverrouillage)
    implementation(libs.biometric)

    // Graphiques (ecran Stats)
    implementation(libs.mpandroidchart)

    // ── Réseau ──────────────────────────────────────────────────────
    implementation(libs.retrofit)          // client REST
    implementation(libs.retrofit.gson)     // convertisseur JSON
    implementation(libs.okhttp.logging)    // logs HTTP (debug)
    implementation(libs.gson)              // parsing JSON

    // ── Sécurité ────────────────────────────────────────────────────
    implementation(libs.security.crypto)   // EncryptedSharedPreferences (token JWT)

    testImplementation(libs.junit)
    androidTestImplementation(libs.espresso.core)
    androidTestImplementation(libs.ext.junit)
}
