package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "fixed_expenses")
public class FixedExpense {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String label;
    private double amount;
    private String category;
    private int recurrenceDay;

    public FixedExpense(String label, double amount, String category, int recurrenceDay) {
        this.label = label;
        this.amount = amount;
        this.category = category;
        this.recurrenceDay = recurrenceDay;
    }

    // Construit une nouvelle depense a partir de cette depense fixe (UML: applyToExpense()).
    // Ne persiste rien : c'est au repository/ViewModel appelant d'inserer l'objet retourne.
    public Expense applyToExpense(Date date) {
        return new Expense(this.amount, this.label, this.category, date, null, true, this.id);
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getLabel() { return label; }
    public void setLabel(String label) { this.label = label; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getRecurrenceDay() { return recurrenceDay; }
    public void setRecurrenceDay(int recurrenceDay) { this.recurrenceDay = recurrenceDay; }
}
