package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.Revenue;

import java.util.Date;
import java.util.List;

@Dao
public interface RevenueDao {

    @Insert
    long insert(Revenue revenue);

    @Update
    void update(Revenue revenue);

    @Delete
    void delete(Revenue revenue);

    @Query("SELECT * FROM revenues ORDER BY date DESC")
    LiveData<List<Revenue>> getAll();

    @Query("SELECT * FROM revenues WHERE date BETWEEN :start AND :end ORDER BY date DESC")
    LiveData<List<Revenue>> getBetween(Date start, Date end);

    @Query("SELECT IFNULL(SUM(amount), 0) FROM revenues WHERE date BETWEEN :start AND :end")
    LiveData<Double> getTotalBetween(Date start, Date end);

    @Query("SELECT IFNULL(SUM(amount), 0) FROM revenues WHERE date BETWEEN :start AND :end")
    double getTotalBetweenSync(Date start, Date end);

    // Total cumule depuis toujours (utilise pour le "solde disponible" du Home)
    @Query("SELECT IFNULL(SUM(amount), 0) FROM revenues")
    LiveData<Double> getTotalAll();
}
