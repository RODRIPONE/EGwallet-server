package com.example.egwallet.util;

// Enveloppe pour les evenements a usage unique exposes via LiveData (messages d'erreur,
// confirmations...). Evite qu'un evenement deja traite soit rejoue automatiquement lors
// d'un changement de configuration (ex: rotation d'ecran) grace au flag hasBeenHandled.
public class Event<T> {

    private final T content;
    private boolean hasBeenHandled = false;

    public Event(T content) {
        this.content = content;
    }

    // Renvoie le contenu et le marque comme traite ; renvoie null si deja traite.
    public T getContentIfNotHandled() {
        if (hasBeenHandled) {
            return null;
        }
        hasBeenHandled = true;
        return content;
    }

    public T peekContent() {
        return content;
    }
}
