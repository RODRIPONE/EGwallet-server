package com.example.egwallet.data.remote.dto;

/**
 * Correspond aux maps retournées par GET /api/debts/{id}/payments
 * et GET /api/dues/{id}/payments.
 *
 * Debt payment JSON :
 * { "id": 1, "amountPaid": 10000.00, "paymentDate": "2026-07-10", "createdAt": "2026-07-10T09:00:00" }
 *
 * Due payment JSON :
 * { "id": 1, "amountReceived": 5000.00, "paymentDate": "2026-07-15", "createdAt": "2026-07-15T10:00:00" }
 *
 * On utilise un seul DTO avec les deux champs (nullable selon le type).
 */
public class PaymentDto {
    private Long id;
    private Double amountPaid;       // pour debt payments
    private Double amountReceived;   // pour due payments
    private String paymentDate;      // "yyyy-MM-dd"
    private String createdAt;        // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()               { return id; }
    public Double getAmountPaid()     { return amountPaid; }
    public Double getAmountReceived() { return amountReceived; }
    public String getPaymentDate()    { return paymentDate; }
    public String getCreatedAt()      { return createdAt; }

    /** Retourne le montant quelle que soit la nature du paiement. */
    public double getAmount() {
        if (amountPaid != null)     return amountPaid;
        if (amountReceived != null) return amountReceived;
        return 0.0;
    }
}
