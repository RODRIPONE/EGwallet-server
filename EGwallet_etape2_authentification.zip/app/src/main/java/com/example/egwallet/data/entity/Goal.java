package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "goals")
public class Goal {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String title;
    private String emoji;
    private double targetAmount;
    private double currentAmount;
    private Date deadline;

    public Goal(String title, String emoji, double targetAmount, double currentAmount, Date deadline) {
        this.title = title;
        this.emoji = emoji;
        this.targetAmount = targetAmount;
        this.currentAmount = currentAmount;
        this.deadline = deadline;
    }

    public double getProgressPercentage() {
        if (targetAmount <= 0) return 0;
        return Math.min((currentAmount / targetAmount) * 100.0, 100.0);
    }

    public double getRemainingAmount() {
        return Math.max(targetAmount - currentAmount, 0);
    }

    // Mutation en memoire uniquement : le repository persiste ensuite via goalDao.update()
    public void addContribution(double amount) {
        this.currentAmount += amount;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getEmoji() { return emoji; }
    public void setEmoji(String emoji) { this.emoji = emoji; }

    public double getTargetAmount() { return targetAmount; }
    public void setTargetAmount(double targetAmount) { this.targetAmount = targetAmount; }

    public double getCurrentAmount() { return currentAmount; }
    public void setCurrentAmount(double currentAmount) { this.currentAmount = currentAmount; }

    public Date getDeadline() { return deadline; }
    public void setDeadline(Date deadline) { this.deadline = deadline; }
}
