package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "revenues")
public class Revenue {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private double amount;
    private String source;
    private String category;
    private Date date;
    private String notes;

    public Revenue(double amount, String source, String category, Date date, String notes) {
        this.amount = amount;
        this.source = source;
        this.category = category;
        this.date = date;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
