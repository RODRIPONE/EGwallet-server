package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "users")
public class User {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String username;
    private String pinCodeHash;
    private boolean biometricEnabled;
    private Date createdAt;
    private boolean isPremium; // false par defaut ; passe a true via le stub "Activer Premium"

    public User(String username, String pinCodeHash, boolean biometricEnabled, Date createdAt) {
        this.username = username;
        this.pinCodeHash = pinCodeHash;
        this.biometricEnabled = biometricEnabled;
        this.createdAt = createdAt;
        this.isPremium = false;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPinCodeHash() { return pinCodeHash; }
    public void setPinCodeHash(String pinCodeHash) { this.pinCodeHash = pinCodeHash; }

    public boolean isBiometricEnabled() { return biometricEnabled; }
    public void setBiometricEnabled(boolean biometricEnabled) { this.biometricEnabled = biometricEnabled; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public boolean isPremium() { return isPremium; }
    public void setPremium(boolean premium) { isPremium = premium; }
}
