package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à GoalResponse du backend.
 *
 * JSON :
 * {
 *   "id": 1,
 *   "userId": 1,
 *   "title": "Vacances",
 *   "emoji": "✈️",
 *   "targetAmount": 300000.00,
 *   "currentAmount": 50000.00,
 *   "deadline": "2026-12-31",
 *   "category": "Voyage",
 *   "isAchieved": false,
 *   "progressPercentage": 16.67,
 *   "monthsRemaining": 5,
 *   "requiredMonthlyContribution": 50000.00,
 *   "createdAt": "2026-07-01T08:00:00"
 * }
 */
public class GoalDto {
    private Long id;
    private Long userId;
    private String title;
    private String emoji;
    private Double targetAmount;
    private Double currentAmount;
    private String deadline;    // "yyyy-MM-dd"
    private String category;

    @SerializedName("isAchieved")
    private Boolean isAchieved;

    private Double progressPercentage;
    private Integer monthsRemaining;
    private Double requiredMonthlyContribution;
    private String createdAt;   // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()                        { return id; }
    public Long getUserId()                    { return userId; }
    public String getTitle()                   { return title; }
    public String getEmoji()                   { return emoji; }
    public Double getTargetAmount()            { return targetAmount; }
    public Double getCurrentAmount()           { return currentAmount; }
    public String getDeadline()                { return deadline; }
    public String getCategory()                { return category; }
    public Boolean getIsAchieved()             { return isAchieved; }
    public Double getProgressPercentage()      { return progressPercentage; }
    public Integer getMonthsRemaining()        { return monthsRemaining; }
    public Double getRequiredMonthlyContribution() { return requiredMonthlyContribution; }
    public String getCreatedAt()               { return createdAt; }
}
