package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "debts")
public class Debt {

    public static final String STATUS_ACTIVE = "active";
    public static final String STATUS_PARTIALLY_PAID = "partiellement_payee";
    public static final String STATUS_PAID = "soldee";
    public static final String STATUS_LATE = "en_retard";

    @PrimaryKey(autoGenerate = true)
    private long id;

    private double initialAmount;
    private String creditor;
    private String reason;
    private Date dueDate;
    private String notes;
    private String status;

    public Debt(double initialAmount, String creditor, String reason, Date dueDate,
                String notes, String status) {
        this.initialAmount = initialAmount;
        this.creditor = creditor;
        this.reason = reason;
        this.dueDate = dueDate;
        this.notes = notes;
        this.status = status;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public double getInitialAmount() { return initialAmount; }
    public void setInitialAmount(double initialAmount) { this.initialAmount = initialAmount; }

    public String getCreditor() { return creditor; }
    public void setCreditor(String creditor) { this.creditor = creditor; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
