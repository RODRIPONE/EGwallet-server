package com.example.egwallet.ui.lock;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.repository.UserRepository;
import com.example.egwallet.util.Event;

/**
 * ViewModel pour la gestion de l'authentification (LockActivity).
 *
 * Phase 2 (Authentification API) :
 * Remplace la logique d'authentification locale (SHA-256) par des appels à l'API backend.
 *
 * Workflow :
 * 1. Premier lancement : createAccount(username, rawPin)
 *    → Appel API : /api/auth/register (username, rawPin)
 *    → Réponse : { userId, token, isPremium, ... }
 *    → Stockage : token JWT + User local avec serverId
 *
 * 2. Connexion subsequent : verifyPin(username, rawPin)
 *    → Appel API : /api/auth/login (username, rawPin)
 *    → Réponse : { userId, token, isPremium, ... }
 *    → Stockage : token JWT + User local mis à jour
 *
 * 3. Biométrie (Phase 3 optionnelle) : onBiometricSuccess()
 *    → Lecture du token JWT depuis SecurePreferences (pas d'appel API requis)
 *    → Déverrouillage local
 *
 * Notes de sécurité :
 * - Le PIN est envoyé en clair via HTTPS au backend qui fait le BCrypt
 * - Pas de stockage du hash PIN en local (plus de SHA-256)
 * - Token JWT stocké de manière sécurisée (EncryptedSharedPreferences)
 * - Chaque requête API subsequent ajoute "Authorization: Bearer <token>" via l'intercepteur
 */
public class LockViewModel extends AndroidViewModel {

    private final UserRepository userRepository;

    private final MutableLiveData<Event<Boolean>> unlocked = new MutableLiveData<>();
    private final MutableLiveData<Event<String>> errorMessage = new MutableLiveData<>();
    private final MutableLiveData<Boolean> hasAccount = new MutableLiveData<>();
    private final MutableLiveData<Boolean> biometricAvailable = new MutableLiveData<>();
    private final MutableLiveData<Boolean> isLoading = new MutableLiveData<>();

    public LockViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
    }

    // ──────────────────────────────────────────────────────────
    // LiveData observables
    // ──────────────────────────────────────────────────────────

    public LiveData<Event<Boolean>> getUnlocked() {
        return unlocked;
    }

    public LiveData<Event<String>> getErrorMessage() {
        return errorMessage;
    }

    public LiveData<Boolean> getHasAccount() {
        return hasAccount;
    }

    public LiveData<Boolean> getBiometricAvailable() {
        return biometricAvailable;
    }

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    // ──────────────────────────────────────────────────────────
    // Initialisation (appel depuis LockActivity.onCreate())
    // ──────────────────────────────────────────────────────────

    /**
     * Détermine si un compte utilisateur existe déjà en local.
     * Utilisé pour décider entre l'écran de création de compte ou de saisie du PIN.
     *
     * Note : après la Phase 2, si l'utilisateur a un compte local mais pas encore synchronisé
     * avec le serveur, `hasAccount` sera true mais `serverId` sera 0. Lors du prochain login,
     * l'utilisateur sera synchronisé avec le backend.
     */
    public void checkHasAccount() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            boolean hasAccount = userRepository.hasAccountSync();
            this.hasAccount.postValue(hasAccount);
        });
    }

    /**
     * Détermine si l'utilisateur a activé la biométrie.
     * Utilisé pour afficher le bouton "Utiliser la biométrie" si disponible.
     */
    public void checkBiometricAvailable() {
        AppExecutors.getInstance().diskIO().execute(() -> {
            User user = userRepository.getCurrentUserSync();
            biometricAvailable.postValue(user != null && user.isBiometricEnabled());
        });
    }

    // ──────────────────────────────────────────────────────────
    // Authentification API (Phase 2)
    // ──────────────────────────────────────────────────────────

    /**
     * Inscription : créer un nouveau compte et le synchroniser avec le backend.
     *
     * Flux :
     * 1. Afficher un indicateur de chargement
     * 2. Appeler userRepository.registerUser(username, rawPin)
     * 3. En cas de succès : token JWT + User sauvegardés, déverrouiller
     * 4. En cas d'erreur : afficher le message d'erreur
     *
     * @param username Nom d'utilisateur
     * @param rawPin PIN brut (6 chiffres)
     */
    public void createAccount(String username, String rawPin) {
        isLoading.setValue(true);

        userRepository.registerUser(username, rawPin, new UserRepository.AuthCallback() {
            @Override
            public void onSuccess(String message) {
                isLoading.postValue(false);
                unlocked.postValue(new Event<>(true));
            }

            @Override
            public void onError(String errorMessage) {
                isLoading.postValue(false);
                LockViewModel.this.errorMessage.postValue(new Event<>(errorMessage));
            }
        });
    }

    /**
     * Connexion : vérifier les identifiants et synchroniser avec le backend.
     *
     * Flux :
     * 1. Afficher un indicateur de chargement
     * 2. Lire l'utilisateur courant depuis la DB locale pour obtenir son username
     * 3. Appeler userRepository.loginUser(username, rawPin)
     * 4. En cas de succès : token JWT + User mis à jour, déverrouiller
     * 5. En cas d'erreur : afficher le message d'erreur
     *
     * Note : on suppose qu'il n'y a qu'un seul utilisateur par app. Le username est lu depuis Room.
     *
     * @param rawPin PIN brut (6 chiffres)
     */
    public void verifyPin(String rawPin) {
        isLoading.setValue(true);

        // Lire l'utilisateur courant pour obtenir son username
        AppExecutors.getInstance().diskIO().execute(() -> {
            User user = userRepository.getCurrentUserSync();
            if (user == null) {
                isLoading.postValue(false);
                errorMessage.postValue(new Event<>("Aucun compte local. Créez-en un d'abord."));
                return;
            }

            userRepository.loginUser(user.getUsername(), rawPin, new UserRepository.AuthCallback() {
                @Override
                public void onSuccess(String message) {
                    isLoading.postValue(false);
                    unlocked.postValue(new Event<>(true));
                }

                @Override
                public void onError(String errorMessage) {
                    isLoading.postValue(false);
                    LockViewModel.this.errorMessage.postValue(new Event<>(errorMessage));
                }
            });
        });
    }

    /**
     * Appelé après un succès du BiometricPrompt (Phase 3 optionnelle).
     * Déverrouille directement sans appel API (la biométrie valide uniquement le capteur,
     * pas une nouvelle authentification auprès du serveur).
     */
    public void onBiometricSuccess() {
        unlocked.setValue(new Event<>(true));
    }

    // ──────────────────────────────────────────────────────────
    // Utilitaires
    // ──────────────────────────────────────────────────────────

    /**
     * Lance les vérifications initiales (hasAccount, biometricAvailable).
     * Doit être appelé depuis LockActivity.onCreate() après le ViewModelProvider.
     */
    public void init() {
        checkHasAccount();
        checkBiometricAvailable();
    }
}
