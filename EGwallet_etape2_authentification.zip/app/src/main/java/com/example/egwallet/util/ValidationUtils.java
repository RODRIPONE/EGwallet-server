package com.example.egwallet.util;

import java.util.Date;

// Regles de validation communes a tous les formulaires (cahier des charges section 7).
// Chaque methode renvoie null si le champ est valide, ou un message d'erreur explicite sinon.
public class ValidationUtils {

    public static final int MIN_TEXT_LENGTH = 3;

    public static String validateAmount(String rawAmount) {
        if (rawAmount == null || rawAmount.trim().isEmpty()) {
            return "Le montant est obligatoire";
        }
        double amount;
        try {
            amount = Double.parseDouble(rawAmount.trim().replace(" ", ""));
        } catch (NumberFormatException e) {
            return "Montant invalide";
        }
        if (amount <= 0) {
            return "Le montant doit etre superieur a 0";
        }
        return null;
    }

    public static String validateText(String text, String fieldLabel) {
        if (text == null || text.trim().length() < MIN_TEXT_LENGTH) {
            return fieldLabel + " doit contenir au moins " + MIN_TEXT_LENGTH + " caracteres";
        }
        return null;
    }

    // Pour un revenu/depense deja survenu : pas de date future
    public static String validatePastOrTodayDate(Date date) {
        if (date == null) {
            return "La date est obligatoire";
        }
        if (date.after(new Date())) {
            return "La date ne peut pas etre dans le futur";
        }
        return null;
    }

    // Pour le remboursement d'une dette/d'un du (diagramme d'activite RembourserDette)
    public static String validateRepaymentAmount(double amount, double remainingAmount) {
        if (amount <= 0) {
            return "Montant invalide";
        }
        if (amount > remainingAmount) {
            return "Montant superieur au solde restant";
        }
        return null;
    }
}
