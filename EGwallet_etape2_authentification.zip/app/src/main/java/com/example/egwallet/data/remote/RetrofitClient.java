package com.example.egwallet.data.remote;

import android.content.Context;
import android.util.Log;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Singleton Retrofit.
 *
 * BASE_URL : à ajuster selon l'environnement.
 *   - Émulateur Android Studio → "http://10.0.2.2:8080/"
 *   - Appareil physique sur même WiFi → "http://<IP_machine>:8080/"
 *   - Production → URL HTTPS du serveur
 *
 * Architecture :
 *   AuthInterceptor injecte "Authorization: Bearer <token>" sur chaque requête.
 *   HttpLoggingInterceptor logue les échanges HTTP (désactivé en release via BuildConfig).
 */
public class RetrofitClient {

    private static final String TAG = "RetrofitClient";

    /**
     * ⚠️  CONFIGURER ICI l'adresse du backend.
     *
     * Émulateur  → "http://10.0.2.2:8080/"
     * WiFi local → "http://192.168.x.x:8080/"   (remplacer par l'IP de la machine)
     */
    public static final String BASE_URL = "http://10.0.2.2:8080/";

    private static volatile RetrofitClient INSTANCE;
    private final ApiService apiService;

    private RetrofitClient(Context context) {
        // Intercepteur JWT : ajoute Authorization: Bearer <token> si un token est disponible
        SecurePreferences securePrefs = SecurePreferences.getInstance(context);
        Interceptor authInterceptor = new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request original = chain.request();
                String token = securePrefs.getToken();
                if (token != null && !token.isEmpty()) {
                    Request authenticated = original.newBuilder()
                            .header("Authorization", "Bearer " + token)
                            .build();
                    return chain.proceed(authenticated);
                }
                return chain.proceed(original);
            }
        };

        // Intercepteur de logs HTTP (utile en debug)
        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor(
                message -> Log.d(TAG, message)
        );
        loggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(authInterceptor)
                .addInterceptor(loggingInterceptor)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        apiService = retrofit.create(ApiService.class);
    }

    public static RetrofitClient getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (RetrofitClient.class) {
                if (INSTANCE == null) {
                    INSTANCE = new RetrofitClient(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    public ApiService getApiService() {
        return apiService;
    }
}
