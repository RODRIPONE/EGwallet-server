package com.example.egwallet.data.remote;

import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Convertit les formats de dates du backend (ISO-8601 String) en java.util.Date
 * utilisé par Room, et vice-versa.
 *
 * Backend → Android :
 *   "2026-07-19"              → Date  (LocalDate)
 *   "2026-07-19T14:30:00"    → Date  (LocalDateTime)
 *
 * Android → Backend (corps des requêtes) :
 *   Date → "2026-07-19"       (pour les champs date)
 */
public class DateMapper {

    private static final String TAG = "DateMapper";

    /** Format LocalDate backend : "yyyy-MM-dd" */
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    /** Format LocalDateTime backend : "yyyy-MM-dd'T'HH:mm:ss" */
    private static final String DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

    // ── Backend → Android ──────────────────────────────────────────────────────

    /**
     * Parse "yyyy-MM-dd" (LocalDate) en Date.
     * @return null si la chaîne est null ou invalide
     */
    public static Date parseDate(String isoDate) {
        if (isoDate == null || isoDate.isEmpty()) return null;
        try {
            return new SimpleDateFormat(DATE_FORMAT, Locale.US).parse(isoDate);
        } catch (ParseException e) {
            Log.w(TAG, "parseDate failed for: " + isoDate, e);
            return null;
        }
    }

    /**
     * Parse "yyyy-MM-dd'T'HH:mm:ss" (LocalDateTime) en Date.
     * @return null si la chaîne est null ou invalide
     */
    public static Date parseDateTime(String isoDateTime) {
        if (isoDateTime == null || isoDateTime.isEmpty()) return null;
        try {
            return new SimpleDateFormat(DATETIME_FORMAT, Locale.US).parse(isoDateTime);
        } catch (ParseException e) {
            Log.w(TAG, "parseDateTime failed for: " + isoDateTime, e);
            return null;
        }
    }

    // ── Android → Backend ──────────────────────────────────────────────────────

    /**
     * Formate une Date en "yyyy-MM-dd" pour l'envoyer au backend.
     * @return null si la date est null
     */
    public static String formatDate(Date date) {
        if (date == null) return null;
        return new SimpleDateFormat(DATE_FORMAT, Locale.US).format(date);
    }
}
