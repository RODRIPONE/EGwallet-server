package com.example.egwallet.data.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.SyncQueueEvent;

import java.util.List;

@Dao
public interface SyncQueueDao {

    @Insert
    long insert(SyncQueueEvent event);

    @Update
    void update(SyncQueueEvent event);

    @Query("SELECT * FROM sync_queue WHERE status = :status ORDER BY createdAt ASC")
    List<SyncQueueEvent> getByStatusSync(String status);
}
