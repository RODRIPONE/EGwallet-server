package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à UserResponse du backend (GET /api/users/me).
 *
 * JSON :
 * {
 *   "id": 1,
 *   "username": "alice",
 *   "biometricEnabled": false,
 *   "isPremium": false,
 *   "createdAt": "2026-07-20T14:30:00"
 * }
 */
public class UserResponseDto {
    private Long id;
    private String username;
    private Boolean biometricEnabled;

    @SerializedName("isPremium")
    private Boolean isPremium;

    private String createdAt;

    public Long getId()               { return id; }
    public String getUsername()       { return username; }
    public Boolean getBiometricEnabled() { return biometricEnabled; }
    public Boolean getIsPremium()     { return isPremium; }
    public String getCreatedAt()      { return createdAt; }
}
