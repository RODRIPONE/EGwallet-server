package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(
        tableName = "expenses",
        foreignKeys = @ForeignKey(
                entity = FixedExpense.class,
                parentColumns = "id",
                childColumns = "fixedExpenseId",
                onDelete = ForeignKey.SET_NULL
        ),
        indices = { @Index("fixedExpenseId") }
)
public class Expense {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private double amount;
    private String reason;
    private String category;
    private Date date;
    private String notes;
    private boolean isFixed;
    private Long fixedExpenseId; // nullable : rempli si generee depuis une FixedExpense

    public Expense(double amount, String reason, String category, Date date, String notes,
                    boolean isFixed, Long fixedExpenseId) {
        this.amount = amount;
        this.reason = reason;
        this.category = category;
        this.date = date;
        this.notes = notes;
        this.isFixed = isFixed;
        this.fixedExpenseId = fixedExpenseId;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public boolean isFixed() { return isFixed; }
    public void setFixed(boolean fixed) { isFixed = fixed; }

    public Long getFixedExpenseId() { return fixedExpenseId; }
    public void setFixedExpenseId(Long fixedExpenseId) { this.fixedExpenseId = fixedExpenseId; }
}
