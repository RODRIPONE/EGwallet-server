package com.example.egwallet.data.remote.dto;

/**
 * Correspond à RevenueResponse du backend.
 *
 * JSON :
 * {
 *   "id": 1,
 *   "userId": 1,
 *   "amount": 150000.00,
 *   "source": "Salaire",
 *   "category": "Emploi",
 *   "date": "2026-07-01",
 *   "createdAt": "2026-07-01T08:00:00"
 * }
 *
 * Les dates sont des String ISO-8601 : "yyyy-MM-dd" pour date,
 * "yyyy-MM-dd'T'HH:mm:ss" pour createdAt.
 * La conversion vers java.util.Date se fait dans le mapper (repository).
 */
public class RevenueDto {
    private Long id;
    private Long userId;
    private Double amount;    // BigDecimal backend → Double Android (suffisant pour FCFA)
    private String source;
    private String category;
    private String date;      // "yyyy-MM-dd"
    private String createdAt; // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()         { return id; }
    public Long getUserId()     { return userId; }
    public Double getAmount()   { return amount; }
    public String getSource()   { return source; }
    public String getCategory() { return category; }
    public String getDate()     { return date; }
    public String getCreatedAt(){ return createdAt; }
}
