package com.example.egwallet.util;

import java.util.Locale;

public class CurrencyFormatter {

    // Montant detaille : 1850000 -> "1 850 000 FCFA" (utilise sur les lignes/details)
    public static String formatFull(double amount) {
        long rounded = Math.round(amount);
        String formatted = String.format(Locale.FRANCE, "%,d", rounded).replace(',', ' ');
        return formatted + " FCFA";
    }

    // Montant abrege : 1400000 -> "1.4M", 431000 -> "431K" (utilise sur les totaux/cartes resume)
    public static String formatAbbreviated(double amount) {
        double abs = Math.abs(amount);
        String sign = amount < 0 ? "-" : "";
        if (abs >= 1_000_000) {
            return sign + trimZero(abs / 1_000_000.0) + "M";
        } else if (abs >= 1_000) {
            return sign + trimZero(abs / 1_000.0) + "K";
        }
        return sign + Math.round(abs);
    }

    private static String trimZero(double value) {
        if (value == Math.floor(value)) {
            return String.valueOf((long) value);
        }
        return String.format(Locale.FRANCE, "%.1f", value);
    }
}
