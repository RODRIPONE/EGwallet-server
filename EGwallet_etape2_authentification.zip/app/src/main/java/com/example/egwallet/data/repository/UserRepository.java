package com.example.egwallet.data.repository;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.example.egwallet.data.AppDatabase;
import com.example.egwallet.data.AppExecutors;
import com.example.egwallet.data.dao.UserDao;
import com.example.egwallet.data.entity.User;
import com.example.egwallet.data.remote.ApiService;
import com.example.egwallet.data.remote.RetrofitClient;
import com.example.egwallet.data.remote.SecurePreferences;
import com.example.egwallet.data.remote.dto.ApiResponseDto;
import com.example.egwallet.data.remote.dto.AuthResponseDto;

import java.util.Date;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Repository pour l'authentification utilisateur (Phase 2).
 *
 * Rôles :
 * 1. Appeler l'API backend pour register/login (envoyer username + PIN en clair via HTTPS)
 * 2. Stocker le token JWT de manière sécurisée (SecurePreferences)
 * 3. Synchroniser l'utilisateur local (Room) avec le backend (persistance du serverId)
 * 4. Continuer à fournir l'accès local à l'utilisateur via LiveData (LockActivity → LockViewModel)
 *
 * Stratégie de sync :
 * - API-first : le backend est la source de vérité
 * - Cache local : Room persévère les données de l'API
 * - Authentification : token JWT attaché à chaque requête subséquente via RetrofitClient.authInterceptor
 */
public class UserRepository {

    private static final String TAG = "UserRepository";

    private final UserDao userDao;
    private final ApiService apiService;
    private final SecurePreferences securePreferences;

    public UserRepository(Application application) {
        userDao = AppDatabase.getInstance(application).userDao();
        apiService = RetrofitClient.getInstance(application).getApiService();
        securePreferences = SecurePreferences.getInstance(application);
    }

    // ──────────────────────────────────────────────────────────
    // Authentification (Phase 2)
    // ──────────────────────────────────────────────────────────

    /**
     * Inscription : envoyer (username, rawPin) à l'API backend.
     *
     * Flux :
     * 1. Appeler /api/auth/register (POST)
     * 2. Backend valide et retourne { userId, username, token, isPremium, ... }
     * 3. Stocker le token JWT de manière sécurisée (SecurePreferences)
     * 4. Insérer l'utilisateur en Room avec serverId du backend
     * 5. Callback : notifier le ViewModel (via LiveData ou Event) — succès ou erreur
     *
     * @param username Nom d'utilisateur
     * @param rawPin PIN brut (envoyé en clair, backend fait le BCrypt)
     * @param callback Callback avec succès ou erreur
     */
    public void registerUser(String username, String rawPin, AuthCallback callback) {
        AppExecutors.getInstance().networkIO().execute(() -> {
            try {
                Call<ApiResponseDto<AuthResponseDto>> call = apiService.register(username, rawPin);
                call.enqueue(new Callback<ApiResponseDto<AuthResponseDto>>() {
                    @Override
                    public void onResponse(Call<ApiResponseDto<AuthResponseDto>> call, Response<ApiResponseDto<AuthResponseDto>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            ApiResponseDto<AuthResponseDto> apiResponse = response.body();
                            if (apiResponse.isSuccess() && apiResponse.getData() != null) {
                                AuthResponseDto authData = apiResponse.getData();

                                // Étape 1 : Stocker le token JWT
                                String token = authData.getToken();
                                securePreferences.saveToken(token);
                                Log.d(TAG, "Token JWT sauvegardé pour " + username);

                                // Étape 2 : Insérer l'utilisateur en Room
                                User user = new User(
                                        authData.getUsername(),
                                        Boolean.TRUE.equals(authData.getBiometricEnabled()),
                                        new Date()
                                );
                                user.setServerId(authData.getUserId());
                                user.setPremium(Boolean.TRUE.equals(authData.getIsPremium()));

                                AppExecutors.getInstance().diskIO().execute(() -> {
                                    userDao.insert(user);
                                    Log.d(TAG, "Utilisateur inséré en Room : " + username + " (serverId=" + authData.getUserId() + ")");
                                });

                                callback.onSuccess("Inscription réussie");
                            } else {
                                callback.onError("Erreur serveur: " + apiResponse.getMessage());
                            }
                        } else {
                            callback.onError("Réponse API invalide (code " + response.code() + ")");
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponseDto<AuthResponseDto>> call, Throwable t) {
                        Log.e(TAG, "Erreur appel register", t);
                        callback.onError("Erreur réseau: " + t.getMessage());
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Exception dans registerUser", e);
                callback.onError("Exception: " + e.getMessage());
            }
        });
    }

    /**
     * Connexion : envoyer (username, rawPin) à l'API backend.
     *
     * Flux :
     * 1. Appeler /api/auth/login (POST)
     * 2. Backend valide et retourne { userId, username, token, isPremium, ... }
     * 3. Stocker le token JWT (SecurePreferences)
     * 4. Insérer ou mettre à jour l'utilisateur en Room
     * 5. Callback : notifier le ViewModel — succès ou erreur
     *
     * @param username Nom d'utilisateur
     * @param rawPin PIN brut (envoyé en clair via HTTPS, backend fait le BCrypt)
     * @param callback Callback avec succès ou erreur
     */
    public void loginUser(String username, String rawPin, AuthCallback callback) {
        AppExecutors.getInstance().networkIO().execute(() -> {
            try {
                Call<ApiResponseDto<AuthResponseDto>> call = apiService.login(username, rawPin);
                call.enqueue(new Callback<ApiResponseDto<AuthResponseDto>>() {
                    @Override
                    public void onResponse(Call<ApiResponseDto<AuthResponseDto>> call, Response<ApiResponseDto<AuthResponseDto>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            ApiResponseDto<AuthResponseDto> apiResponse = response.body();
                            if (apiResponse.isSuccess() && apiResponse.getData() != null) {
                                AuthResponseDto authData = apiResponse.getData();

                                // Étape 1 : Stocker le token JWT
                                String token = authData.getToken();
                                securePreferences.saveToken(token);
                                Log.d(TAG, "Token JWT sauvegardé pour " + username);

                                // Étape 2 : Insérer ou mettre à jour l'utilisateur en Room
                                AppExecutors.getInstance().diskIO().execute(() -> {
                                    User existingUser = userDao.getCurrentUserSync();
                                    User user;
                                    if (existingUser != null) {
                                        // Update
                                        user = existingUser;
                                        user.setServerId(authData.getUserId());
                                        user.setPremium(Boolean.TRUE.equals(authData.getIsPremium()));
                                        userDao.update(user);
                                        Log.d(TAG, "Utilisateur mis à jour : " + username);
                                    } else {
                                        // Insert
                                        user = new User(
                                                authData.getUsername(),
                                                Boolean.TRUE.equals(authData.getBiometricEnabled()),
                                                new Date()
                                        );
                                        user.setServerId(authData.getUserId());
                                        user.setPremium(Boolean.TRUE.equals(authData.getIsPremium()));
                                        userDao.insert(user);
                                        Log.d(TAG, "Utilisateur inséré en Room : " + username);
                                    }
                                });

                                callback.onSuccess("Connexion réussie");
                            } else {
                                callback.onError("Erreur serveur: " + apiResponse.getMessage());
                            }
                        } else {
                            callback.onError("Réponse API invalide (code " + response.code() + ")");
                        }
                    }

                    @Override
                    public void onFailure(Call<ApiResponseDto<AuthResponseDto>> call, Throwable t) {
                        Log.e(TAG, "Erreur appel login", t);
                        callback.onError("Erreur réseau: " + t.getMessage());
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Exception dans loginUser", e);
                callback.onError("Exception: " + e.getMessage());
            }
        });
    }

    // ──────────────────────────────────────────────────────────
    // Accès local (Room) — utilisé par LockActivity/LockViewModel
    // ──────────────────────────────────────────────────────────

    public LiveData<User> getCurrentUser() {
        return userDao.getCurrentUser();
    }

    public User getCurrentUserSync() {
        return userDao.getCurrentUserSync();
    }

    public boolean hasAccountSync() {
        return userDao.countUsers() > 0;
    }

    public void insert(User user) {
        AppExecutors.getInstance().diskIO().execute(() -> userDao.insert(user));
    }

    public void update(User user) {
        AppExecutors.getInstance().diskIO().execute(() -> userDao.update(user));
    }

    // ──────────────────────────────────────────────────────────
    // Callback pour l'authentification
    // ──────────────────────────────────────────────────────────

    public interface AuthCallback {
        void onSuccess(String message);
        void onError(String errorMessage);
    }
}
