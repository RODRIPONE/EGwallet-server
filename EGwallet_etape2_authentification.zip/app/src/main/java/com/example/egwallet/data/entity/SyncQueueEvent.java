package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "sync_queue")
public class SyncQueueEvent {

    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_SYNCED = "synced";

    public static final String TYPE_DEBT_PAYMENT_CREATED = "DEBT_PAYMENT_CREATED";
    public static final String TYPE_DUE_PAYMENT_CREATED = "DUE_PAYMENT_CREATED";
    public static final String TYPE_EXPENSE_CREATED = "EXPENSE_CREATED";
    public static final String TYPE_REVENUE_CREATED = "REVENUE_CREATED";

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String eventType;
    private long relatedEntityId;
    private String status;
    private Date createdAt;

    public SyncQueueEvent(String eventType, long relatedEntityId, String status, Date createdAt) {
        this.eventType = eventType;
        this.relatedEntityId = relatedEntityId;
        this.status = status;
        this.createdAt = createdAt;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }

    public long getRelatedEntityId() { return relatedEntityId; }
    public void setRelatedEntityId(long relatedEntityId) { this.relatedEntityId = relatedEntityId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }
}
