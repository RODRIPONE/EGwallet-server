package com.example.egwallet.data.remote;

import com.example.egwallet.data.remote.dto.ApiResponseDto;
import com.example.egwallet.data.remote.dto.AuthResponseDto;
import com.example.egwallet.data.remote.dto.DebtDto;
import com.example.egwallet.data.remote.dto.DueDto;
import com.example.egwallet.data.remote.dto.ExpenseDto;
import com.example.egwallet.data.remote.dto.GoalDto;
import com.example.egwallet.data.remote.dto.PaymentDto;
import com.example.egwallet.data.remote.dto.RevenueDto;
import com.example.egwallet.data.remote.dto.UserResponseDto;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

/**
 * Interface Retrofit — miroir exact des controllers Spring Boot.
 *
 * Base URL : http://<host>:8080/   (context-path désactivé côté backend)
 * Les controllers portent déjà le préfixe /api/, donc toutes les routes
 * commencent par /api/.
 *
 * Authentification : JWT injecté automatiquement par AuthInterceptor dans RetrofitClient.
 * Endpoints publics : /api/auth/register et /api/auth/login (pas de token requis).
 */
public interface ApiService {

    // ── AUTH ─────────────────────────────────────────────────────────────────

    /** POST /api/auth/register — Body : { "username": "...", "pin": "..." } */
    @POST("api/auth/register")
    Call<ApiResponseDto<AuthResponseDto>> register(@Body Map<String, String> body);

    /** POST /api/auth/login — Body : { "username": "...", "pin": "..." } */
    @POST("api/auth/login")
    Call<ApiResponseDto<AuthResponseDto>> login(@Body Map<String, String> body);

    // ── USERS ─────────────────────────────────────────────────────────────────

    /** GET /api/users/me */
    @GET("api/users/me")
    Call<ApiResponseDto<UserResponseDto>> getMe();

    // ── REVENUES ──────────────────────────────────────────────────────────────

    /** GET /api/revenues */
    @GET("api/revenues")
    Call<ApiResponseDto<List<RevenueDto>>> getRevenues();

    /**
     * POST /api/revenues
     * Body : { "amount": 150000, "source": "Salaire", "category": "Emploi", "date": "2026-07-01", "notes": null }
     */
    @POST("api/revenues")
    Call<ApiResponseDto<RevenueDto>> createRevenue(@Body Map<String, Object> body);

    /**
     * PUT /api/revenues/{revenueId}
     * Body : { "amount": 160000, "source": "Salaire", "category": "Emploi" }
     */
    @PUT("api/revenues/{revenueId}")
    Call<ApiResponseDto<RevenueDto>> updateRevenue(
            @Path("revenueId") long revenueId,
            @Body Map<String, Object> body);

    /** DELETE /api/revenues/{revenueId} */
    @DELETE("api/revenues/{revenueId}")
    Call<ApiResponseDto<String>> deleteRevenue(@Path("revenueId") long revenueId);

    // ── EXPENSES ──────────────────────────────────────────────────────────────

    /** GET /api/expenses */
    @GET("api/expenses")
    Call<ApiResponseDto<List<ExpenseDto>>> getExpenses();

    /**
     * POST /api/expenses
     * Body : { "amount": 5000, "reason": "Courses", "category": "Alimentation",
     *          "date": "2026-07-10", "notes": null, "fixedExpenseId": null }
     */
    @POST("api/expenses")
    Call<ApiResponseDto<ExpenseDto>> createExpense(@Body Map<String, Object> body);

    /**
     * PUT /api/expenses/{expenseId}
     * Body : { "amount": 6000, "reason": "Courses", "category": "Alimentation" }
     */
    @PUT("api/expenses/{expenseId}")
    Call<ApiResponseDto<ExpenseDto>> updateExpense(
            @Path("expenseId") long expenseId,
            @Body Map<String, Object> body);

    /** DELETE /api/expenses/{expenseId} */
    @DELETE("api/expenses/{expenseId}")
    Call<ApiResponseDto<String>> deleteExpense(@Path("expenseId") long expenseId);

    // ── DEBTS ─────────────────────────────────────────────────────────────────

    /** GET /api/debts */
    @GET("api/debts")
    Call<ApiResponseDto<List<DebtDto>>> getDebts();

    /** GET /api/debts/{debtId} */
    @GET("api/debts/{debtId}")
    Call<ApiResponseDto<DebtDto>> getDebt(@Path("debtId") long debtId);

    /**
     * POST /api/debts
     * Body : { "creditor": "Jean", "amount": 50000, "reason": "Prêt",
     *          "dueDate": "2026-12-01", "notes": null }
     */
    @POST("api/debts")
    Call<ApiResponseDto<DebtDto>> createDebt(@Body Map<String, Object> body);

    /**
     * POST /api/debts/{debtId}/pay
     * Body : { "amount": 10000 }
     */
    @POST("api/debts/{debtId}/pay")
    Call<ApiResponseDto<DebtDto>> payDebt(
            @Path("debtId") long debtId,
            @Body Map<String, Object> body);

    /** GET /api/debts/{debtId}/payments */
    @GET("api/debts/{debtId}/payments")
    Call<ApiResponseDto<List<PaymentDto>>> getDebtPayments(@Path("debtId") long debtId);

    /** DELETE /api/debts/{debtId} */
    @DELETE("api/debts/{debtId}")
    Call<ApiResponseDto<String>> deleteDebt(@Path("debtId") long debtId);

    // ── DUES ──────────────────────────────────────────────────────────────────

    /** GET /api/dues */
    @GET("api/dues")
    Call<ApiResponseDto<List<DueDto>>> getDues();

    /** GET /api/dues/{dueId} */
    @GET("api/dues/{dueId}")
    Call<ApiResponseDto<DueDto>> getDue(@Path("dueId") long dueId);

    /**
     * POST /api/dues
     * Body : { "debtorName": "Pierre", "amount": 20000, "reason": "Prêt ami",
     *          "dueDate": "2026-09-01", "notes": null }
     */
    @POST("api/dues")
    Call<ApiResponseDto<DueDto>> createDue(@Body Map<String, Object> body);

    /**
     * POST /api/dues/{dueId}/receive
     * Body : { "amount": 5000 }
     */
    @POST("api/dues/{dueId}/receive")
    Call<ApiResponseDto<DueDto>> receiveDue(
            @Path("dueId") long dueId,
            @Body Map<String, Object> body);

    /** GET /api/dues/{dueId}/payments */
    @GET("api/dues/{dueId}/payments")
    Call<ApiResponseDto<List<PaymentDto>>> getDuePayments(@Path("dueId") long dueId);

    /** DELETE /api/dues/{dueId} */
    @DELETE("api/dues/{dueId}")
    Call<ApiResponseDto<String>> deleteDue(@Path("dueId") long dueId);

    // ── GOALS ─────────────────────────────────────────────────────────────────

    /** GET /api/goals */
    @GET("api/goals")
    Call<ApiResponseDto<List<GoalDto>>> getGoals();

    /**
     * POST /api/goals
     * Body : { "title": "Vacances", "emoji": "✈️", "targetAmount": 300000,
     *          "deadline": "2026-12-31", "category": null, "notes": null }
     */
    @POST("api/goals")
    Call<ApiResponseDto<GoalDto>> createGoal(@Body Map<String, Object> body);

    /**
     * POST /api/goals/{goalId}/contribute
     * Body : { "amount": 10000 }
     */
    @POST("api/goals/{goalId}/contribute")
    Call<ApiResponseDto<GoalDto>> contributeGoal(
            @Path("goalId") long goalId,
            @Body Map<String, Object> body);

    /** DELETE /api/goals/{goalId} */
    @DELETE("api/goals/{goalId}")
    Call<ApiResponseDto<String>> deleteGoal(@Path("goalId") long goalId);
}
