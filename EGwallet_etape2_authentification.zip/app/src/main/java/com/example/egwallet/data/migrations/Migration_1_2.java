package com.example.egwallet.data.migrations;

import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

/**
 * Migration Room v1 → v2
 *
 * Modifications :
 * 1. Ajouter colonne `serverId` (Long, NOT NULL DEFAULT 0) — stocke l'ID utilisateur du backend
 * 2. Supprimer colonne `pinCodeHash` — on ne hachera plus le PIN localement, il sera envoyé en clair via HTTPS au backend qui fait le BCrypt
 *
 * Rationale :
 * - Avant Phase 2 : authentification 100% locale (SHA-256 local)
 * - Après Phase 2 : authentification via API backend (BCrypt serveur)
 * - serverId permet de synchroniser l'utilisateur local avec le serveur
 * - Pas besoin de stocker le hash PIN en local (il ne sera jamais réutilisé après le premier login)
 */
public class Migration_1_2 extends Migration {

    public Migration_1_2() {
        super(1, 2);
    }

    @Override
    public void migrate(SupportSQLiteDatabase database) {
        // Étape 1 : Ajouter la colonne serverId
        // SQLite ne support pas ALTER TABLE pour ajouter une colonne NOT NULL sans DEFAULT,
        // donc on doit fournir une valeur par défaut (0 pour "pas encore synchronisé")
        database.execSQL(
                "ALTER TABLE users ADD COLUMN serverId INTEGER NOT NULL DEFAULT 0"
        );

        // Étape 2 : Supprimer la colonne pinCodeHash
        // SQLite ne supporte pas DROP COLUMN directement, donc on utilise la stratégie
        // de recréer la table sans cette colonne. Cependant, comme c'est un peu complexe,
        // on peut laisser la colonne et la marquer comme dépréciée. Mais pour être propre,
        // on la supprime vraiment.

        // Option simple : on ne peut pas facilement supprimer une colonne en SQLite,
        // donc on la laisse. Elle ne sera jamais utilisée après cette migration.
        // Le Dao ne la lira plus (pas d'@ColumnInfo pour elle).

        // Option propre (recommandée) : recréer la table
        database.execSQL(
                "CREATE TABLE users_new (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                "serverId INTEGER NOT NULL DEFAULT 0, " +
                "username TEXT NOT NULL, " +
                "biometricEnabled INTEGER NOT NULL, " +
                "createdAt INTEGER NOT NULL, " +
                "isPremium INTEGER NOT NULL DEFAULT 0)"
        );

        database.execSQL(
                "INSERT INTO users_new (id, serverId, username, biometricEnabled, createdAt, isPremium) " +
                "SELECT id, 0, username, biometricEnabled, createdAt, isPremium FROM users"
        );

        database.execSQL("DROP TABLE users");
        database.execSQL("ALTER TABLE users_new RENAME TO users");
    }
}
