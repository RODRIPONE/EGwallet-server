package com.example.egwallet.data.remote.dto;

/**
 * Wrapper générique qui correspond exactement à com.egwallet.server.common.response.ApiResponse<T>.
 *
 * JSON exemple :
 * {
 *   "success": true,
 *   "message": "Revenue created",
 *   "data": { ... },
 *   "errorCode": null,
 *   "timestamp": "2026-07-20T14:30:00"
 * }
 */
public class ApiResponseDto<T> {
    private boolean success;
    private String message;
    private T data;
    private String errorCode;
    private String timestamp;   // LocalDateTime sérialisé en String, ignoré côté Android

    public boolean isSuccess()       { return success; }
    public String getMessage()       { return message; }
    public T getData()               { return data; }
    public String getErrorCode()     { return errorCode; }
}
