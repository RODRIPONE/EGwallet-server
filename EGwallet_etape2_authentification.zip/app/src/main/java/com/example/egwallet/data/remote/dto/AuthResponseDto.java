package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à AuthController.AuthResponse du backend.
 *
 * JSON :
 * {
 *   "userId": 1,
 *   "username": "alice",
 *   "token": "eyJ...",
 *   "biometricEnabled": false,
 *   "isPremium": false,
 *   "createdAt": "2026-07-20T14:30:00"
 * }
 */
public class AuthResponseDto {
    private Long userId;
    private String username;
    private String token;
    private Boolean biometricEnabled;

    // Gson ne mappe pas automatiquement "isPremium" → isPremium à cause du préfixe "is"
    // On force le nom JSON avec @SerializedName
    @SerializedName("isPremium")
    private Boolean isPremium;

    private String createdAt;   // "yyyy-MM-dd'T'HH:mm:ss" — conservé en String

    public Long getUserId()           { return userId; }
    public String getUsername()       { return username; }
    public String getToken()          { return token; }
    public Boolean getBiometricEnabled() { return biometricEnabled; }
    public Boolean getIsPremium()     { return isPremium; }
    public String getCreatedAt()      { return createdAt; }
}
