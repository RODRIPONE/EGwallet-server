package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.egwallet.data.entity.DebtPayment;

import java.util.List;

@Dao
public interface DebtPaymentDao {

    @Insert
    long insert(DebtPayment payment);

    @Query("SELECT * FROM debt_payments WHERE debtId = :debtId ORDER BY paymentDate DESC")
    LiveData<List<DebtPayment>> getForDebt(long debtId);

    @Query("SELECT IFNULL(SUM(amountPaid), 0) FROM debt_payments WHERE debtId = :debtId")
    double getTotalPaidSync(long debtId);
}
