package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à DebtResponse du backend.
 *
 * JSON :
 * {
 *   "id": 1,
 *   "userId": 1,
 *   "creditor": "Jean",
 *   "initialAmount": 50000.00,
 *   "remainingAmount": 30000.00,
 *   "reason": "Prêt personnel",
 *   "dueDate": "2026-12-01",
 *   "isFullyPaid": false,
 *   "status": "partiellement_payee",
 *   "createdAt": "2026-07-01T08:00:00"
 * }
 */
public class DebtDto {
    private Long id;
    private Long userId;
    private String creditor;
    private Double initialAmount;
    private Double remainingAmount;
    private String reason;
    private String dueDate;     // "yyyy-MM-dd" nullable

    @SerializedName("isFullyPaid")
    private Boolean isFullyPaid;

    private String status;
    private String createdAt;   // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()               { return id; }
    public Long getUserId()           { return userId; }
    public String getCreditor()       { return creditor; }
    public Double getInitialAmount()  { return initialAmount; }
    public Double getRemainingAmount(){ return remainingAmount; }
    public String getReason()         { return reason; }
    public String getDueDate()        { return dueDate; }
    public Boolean getIsFullyPaid()   { return isFullyPaid; }
    public String getStatus()         { return status; }
    public String getCreatedAt()      { return createdAt; }
}
