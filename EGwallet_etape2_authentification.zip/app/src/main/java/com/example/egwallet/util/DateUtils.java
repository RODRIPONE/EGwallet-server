package com.example.egwallet.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtils {

    public static Date startOfMonth(Date reference) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(reference);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    public static Date endOfMonth(Date reference) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(reference);
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);
        return cal.getTime();
    }

    public static Date monthsAgo(int months) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -months);
        return cal.getTime();
    }

    // Nombre de mois calendaires entre deux dates (jamais negatif). Utilise pour
    // "mois restants" et "epargne/mois necessaire" sur les objectifs.
    public static int monthsBetween(Date from, Date to) {
        Calendar start = Calendar.getInstance();
        start.setTime(from);
        Calendar end = Calendar.getInstance();
        end.setTime(to);
        int months = (end.get(Calendar.YEAR) - start.get(Calendar.YEAR)) * 12
                + (end.get(Calendar.MONTH) - start.get(Calendar.MONTH));
        return Math.max(months, 0);
    }
}
