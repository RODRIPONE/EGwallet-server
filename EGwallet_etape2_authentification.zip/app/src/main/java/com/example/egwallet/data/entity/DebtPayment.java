package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(
        tableName = "debt_payments",
        foreignKeys = @ForeignKey(
                entity = Debt.class,
                parentColumns = "id",
                childColumns = "debtId",
                onDelete = ForeignKey.CASCADE
        ),
        indices = { @Index("debtId") }
)
public class DebtPayment {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private long debtId;
    private double amountPaid;
    private Date paymentDate;
    private String notes;

    public DebtPayment(long debtId, double amountPaid, Date paymentDate, String notes) {
        this.debtId = debtId;
        this.amountPaid = amountPaid;
        this.paymentDate = paymentDate;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getDebtId() { return debtId; }
    public void setDebtId(long debtId) { this.debtId = debtId; }

    public double getAmountPaid() { return amountPaid; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }

    public Date getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
