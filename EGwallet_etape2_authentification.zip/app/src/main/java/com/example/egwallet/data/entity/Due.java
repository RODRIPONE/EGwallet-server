package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(tableName = "dues")
public class Due {

    public static final String STATUS_ACTIVE = "active";
    public static final String STATUS_PARTIALLY_RECEIVED = "partiellement_payee";
    public static final String STATUS_RECEIVED = "soldee";
    public static final String STATUS_LATE = "en_retard";

    @PrimaryKey(autoGenerate = true)
    private long id;

    private double initialAmount;
    private String debtorName;
    private String reason;
    private Date dueDate;
    private String notes;
    private String status;

    public Due(double initialAmount, String debtorName, String reason, Date dueDate,
               String notes, String status) {
        this.initialAmount = initialAmount;
        this.debtorName = debtorName;
        this.reason = reason;
        this.dueDate = dueDate;
        this.notes = notes;
        this.status = status;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public double getInitialAmount() { return initialAmount; }
    public void setInitialAmount(double initialAmount) { this.initialAmount = initialAmount; }

    public String getDebtorName() { return debtorName; }
    public void setDebtorName(String debtorName) { this.debtorName = debtorName; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
