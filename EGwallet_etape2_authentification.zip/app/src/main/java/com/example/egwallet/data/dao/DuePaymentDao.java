package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.egwallet.data.entity.DuePayment;

import java.util.List;

@Dao
public interface DuePaymentDao {

    @Insert
    long insert(DuePayment payment);

    @Query("SELECT * FROM due_payments WHERE dueId = :dueId ORDER BY paymentDate DESC")
    LiveData<List<DuePayment>> getForDue(long dueId);

    @Query("SELECT IFNULL(SUM(amountReceived), 0) FROM due_payments WHERE dueId = :dueId")
    double getTotalReceivedSync(long dueId);
}
