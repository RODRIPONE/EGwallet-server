package com.example.egwallet.data.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity(
        tableName = "due_payments",
        foreignKeys = @ForeignKey(
                entity = Due.class,
                parentColumns = "id",
                childColumns = "dueId",
                onDelete = ForeignKey.CASCADE
        ),
        indices = { @Index("dueId") }
)
public class DuePayment {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private long dueId;
    private double amountReceived;
    private Date paymentDate;
    private String notes;

    public DuePayment(long dueId, double amountReceived, Date paymentDate, String notes) {
        this.dueId = dueId;
        this.amountReceived = amountReceived;
        this.paymentDate = paymentDate;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getDueId() { return dueId; }
    public void setDueId(long dueId) { this.dueId = dueId; }

    public double getAmountReceived() { return amountReceived; }
    public void setAmountReceived(double amountReceived) { this.amountReceived = amountReceived; }

    public Date getPaymentDate() { return paymentDate; }
    public void setPaymentDate(Date paymentDate) { this.paymentDate = paymentDate; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
