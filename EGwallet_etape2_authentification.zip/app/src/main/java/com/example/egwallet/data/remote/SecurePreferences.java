package com.example.egwallet.data.remote;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/**
 * Stockage sécurisé du token JWT et des métadonnées de session.
 *
 * Utilise EncryptedSharedPreferences (Jetpack Security) :
 * les clés et valeurs sont chiffrées avec AES-256-GCM via le Keystore Android.
 *
 * Usage :
 *   SecurePreferences prefs = SecurePreferences.getInstance(context);
 *   prefs.saveToken("eyJ...");
 *   String token = prefs.getToken();
 *   prefs.clear(); // à la déconnexion
 */
public class SecurePreferences {

    private static final String TAG = "SecurePreferences";
    private static final String FILE_NAME = "egwallet_secure_prefs";

    private static final String KEY_TOKEN         = "jwt_token";
    private static final String KEY_USER_ID       = "user_id";
    private static final String KEY_USERNAME      = "username";
    private static final String KEY_IS_PREMIUM    = "is_premium";
    private static final String KEY_BIOMETRIC     = "biometric_enabled";

    private static volatile SecurePreferences INSTANCE;
    private final SharedPreferences sharedPreferences;

    private SecurePreferences(Context context) {
        SharedPreferences sp;
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            sp = EncryptedSharedPreferences.create(
                    context,
                    FILE_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            // Fallback non chiffré uniquement en cas d'échec d'initialisation du Keystore
            // (rare : appareils très anciens sans Keystore hardware)
            Log.e(TAG, "EncryptedSharedPreferences init failed, using plain fallback", e);
            sp = context.getSharedPreferences(FILE_NAME + "_plain", Context.MODE_PRIVATE);
        }
        this.sharedPreferences = sp;
    }

    public static SecurePreferences getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SecurePreferences.class) {
                if (INSTANCE == null) {
                    INSTANCE = new SecurePreferences(context.getApplicationContext());
                }
            }
        }
        return INSTANCE;
    }

    // ── Token JWT ────────────────────────────────────────────────────────────

    public void saveToken(String token) {
        sharedPreferences.edit().putString(KEY_TOKEN, token).apply();
    }

    public String getToken() {
        return sharedPreferences.getString(KEY_TOKEN, null);
    }

    public boolean hasToken() {
        return getToken() != null;
    }

    // ── Session utilisateur ───────────────────────────────────────────────────

    public void saveSession(long userId, String username, boolean isPremium, boolean biometricEnabled) {
        sharedPreferences.edit()
                .putLong(KEY_USER_ID, userId)
                .putString(KEY_USERNAME, username)
                .putBoolean(KEY_IS_PREMIUM, isPremium)
                .putBoolean(KEY_BIOMETRIC, biometricEnabled)
                .apply();
    }

    public long getUserId()           { return sharedPreferences.getLong(KEY_USER_ID, -1L); }
    public String getUsername()       { return sharedPreferences.getString(KEY_USERNAME, null); }
    public boolean getIsPremium()     { return sharedPreferences.getBoolean(KEY_IS_PREMIUM, false); }
    public boolean getBiometricEnabled() { return sharedPreferences.getBoolean(KEY_BIOMETRIC, false); }

    // ── Nettoyage (déconnexion) ───────────────────────────────────────────────

    public void clear() {
        sharedPreferences.edit().clear().apply();
    }
}
