package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à ExpenseResponse du backend.
 *
 * JSON :
 * {
 *   "id": 1,
 *   "userId": 1,
 *   "amount": 5000.00,
 *   "reason": "Courses",
 *   "category": "Alimentation",
 *   "date": "2026-07-10",
 *   "isFixed": false,
 *   "fixedExpenseId": null,
 *   "createdAt": "2026-07-10T12:00:00"
 * }
 */
public class ExpenseDto {
    private Long id;
    private Long userId;
    private Double amount;
    private String reason;
    private String category;
    private String date;      // "yyyy-MM-dd"

    @SerializedName("isFixed")
    private Boolean isFixed;

    private Long fixedExpenseId;
    private String createdAt; // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()           { return id; }
    public Long getUserId()       { return userId; }
    public Double getAmount()     { return amount; }
    public String getReason()     { return reason; }
    public String getCategory()   { return category; }
    public String getDate()       { return date; }
    public Boolean getIsFixed()   { return isFixed; }
    public Long getFixedExpenseId() { return fixedExpenseId; }
    public String getCreatedAt()  { return createdAt; }
}
