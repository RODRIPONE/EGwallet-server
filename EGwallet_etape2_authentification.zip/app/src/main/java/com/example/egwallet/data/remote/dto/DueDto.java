package com.example.egwallet.data.remote.dto;

import com.google.gson.annotations.SerializedName;

/**
 * Correspond à DueResponse du backend.
 *
 * JSON :
 * {
 *   "id": 1,
 *   "userId": 1,
 *   "debtorName": "Pierre",
 *   "initialAmount": 20000.00,
 *   "remainingAmount": 20000.00,
 *   "reason": "Prêt ami",
 *   "dueDate": "2026-09-01",
 *   "isFullyReceived": false,
 *   "status": "active",
 *   "createdAt": "2026-07-15T10:00:00"
 * }
 */
public class DueDto {
    private Long id;
    private Long userId;
    private String debtorName;
    private Double initialAmount;
    private Double remainingAmount;
    private String reason;
    private String dueDate;     // "yyyy-MM-dd" nullable

    @SerializedName("isFullyReceived")
    private Boolean isFullyReceived;

    private String status;
    private String createdAt;   // "yyyy-MM-dd'T'HH:mm:ss"

    public Long getId()                 { return id; }
    public Long getUserId()             { return userId; }
    public String getDebtorName()       { return debtorName; }
    public Double getInitialAmount()    { return initialAmount; }
    public Double getRemainingAmount()  { return remainingAmount; }
    public String getReason()           { return reason; }
    public String getDueDate()          { return dueDate; }
    public Boolean getIsFullyReceived() { return isFullyReceived; }
    public String getStatus()           { return status; }
    public String getCreatedAt()        { return createdAt; }
}
