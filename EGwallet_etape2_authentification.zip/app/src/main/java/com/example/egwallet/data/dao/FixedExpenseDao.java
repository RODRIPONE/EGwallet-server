package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.FixedExpense;

import java.util.List;

@Dao
public interface FixedExpenseDao {

    @Insert
    long insert(FixedExpense fixedExpense);

    @Update
    void update(FixedExpense fixedExpense);

    @Delete
    void delete(FixedExpense fixedExpense);

    @Query("SELECT * FROM fixed_expenses ORDER BY label ASC")
    LiveData<List<FixedExpense>> getAll();

    @Query("SELECT * FROM fixed_expenses WHERE id = :id")
    FixedExpense getByIdSync(long id);
}
