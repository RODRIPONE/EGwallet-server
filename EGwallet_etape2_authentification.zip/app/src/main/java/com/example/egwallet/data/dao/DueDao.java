package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.Due;

import java.util.Date;
import java.util.List;

@Dao
public interface DueDao {

    @Insert
    long insert(Due due);

    @Update
    void update(Due due);

    @Delete
    void delete(Due due);

    @Query("SELECT * FROM dues ORDER BY dueDate ASC")
    LiveData<List<Due>> getAll();

    @Query("SELECT * FROM dues WHERE id = :id")
    LiveData<Due> getById(long id);

    @Query("SELECT * FROM dues WHERE id = :id")
    Due getByIdSync(long id);

    // Somme des soldes restants sur tous les dus (meme principe que DebtDao.getTotalRemaining)
    @Query("SELECT (SELECT IFNULL(SUM(initialAmount),0) FROM dues) - " +
           "(SELECT IFNULL(SUM(amountReceived),0) FROM due_payments)")
    LiveData<Double> getTotalRemaining();

    @Query("SELECT d.*, IFNULL(SUM(p.amountReceived), 0) AS totalReceived " +
           "FROM dues d LEFT JOIN due_payments p ON p.dueId = d.id " +
           "GROUP BY d.id ORDER BY d.dueDate ASC")
    LiveData<List<DueWithRemaining>> getAllWithRemaining();

    class DueWithRemaining {
        public long id;
        public double initialAmount;
        public String debtorName;
        public String reason;
        public Date dueDate;
        public String notes;
        public String status;
        public double totalReceived;

        public double getRemainingAmount() {
            return initialAmount - totalReceived;
        }

        public boolean isFullyReceived() {
            return getRemainingAmount() <= 0.0001;
        }
    }
}
