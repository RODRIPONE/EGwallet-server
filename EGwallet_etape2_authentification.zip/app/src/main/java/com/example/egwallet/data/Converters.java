package com.example.egwallet.data;

import androidx.room.TypeConverter;

import java.util.Date;

/**
 * TypeConverters pour Room.
 *
 * Room ne peut pas stocker les types complexes nativement.
 * Ces convertisseurs transforment java.util.Date en Long (timestamp) pour la persévérance SQLite.
 */
public class Converters {

    @TypeConverter
    public static Date fromTimestamp(Long value) {
        return value == null ? null : new Date(value);
    }

    @TypeConverter
    public static Long dateToTimestamp(Date date) {
        return date == null ? null : date.getTime();
    }
}
