package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.Debt;

import java.util.Date;
import java.util.List;

@Dao
public interface DebtDao {

    @Insert
    long insert(Debt debt);

    @Update
    void update(Debt debt);

    @Delete
    void delete(Debt debt);

    @Query("SELECT * FROM debts ORDER BY dueDate ASC")
    LiveData<List<Debt>> getAll();

    @Query("SELECT * FROM debts WHERE id = :id")
    LiveData<Debt> getById(long id);

    @Query("SELECT * FROM debts WHERE id = :id")
    Debt getByIdSync(long id);

    // Somme des soldes restants sur toutes les dettes : (SUM initial) - (SUM paye), ce qui
    // equivaut a SUM(initial_i - paye_i) sans avoir besoin de jointure/groupement.
    @Query("SELECT (SELECT IFNULL(SUM(initialAmount),0) FROM debts) - " +
           "(SELECT IFNULL(SUM(amountPaid),0) FROM debt_payments)")
    LiveData<Double> getTotalRemaining();

    // Vue combinant chaque dette avec le total deja rembourse (jointure avec debt_payments).
    // getRemainingAmount()/isFullyPaid() de l'UML vivent ici plutot que sur l'entity Debt,
    // car ils necessitent d'agreger une autre table -> impossible sur un simple POJO Room
    // sans acces DB.
    @Query("SELECT d.*, IFNULL(SUM(p.amountPaid), 0) AS totalPaid " +
           "FROM debts d LEFT JOIN debt_payments p ON p.debtId = d.id " +
           "GROUP BY d.id ORDER BY d.dueDate ASC")
    LiveData<List<DebtWithRemaining>> getAllWithRemaining();

    class DebtWithRemaining {
        public long id;
        public double initialAmount;
        public String creditor;
        public String reason;
        public Date dueDate;
        public String notes;
        public String status;
        public double totalPaid;

        public double getRemainingAmount() {
            return initialAmount - totalPaid;
        }

        public boolean isFullyPaid() {
            return getRemainingAmount() <= 0.0001;
        }
    }
}
