package com.example.egwallet.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

// Hachage du code PIN (SHA-256) : jamais stocke en clair (cf. User.pinCodeHash).
// Remarque honnete : pour une vraie appli de production avec des enjeux de securite plus
// forts, prefere un hachage avec sel + fonction lente (BCrypt/Argon2). SHA-256 seul est un
// compromis raisonnable ici : PIN local a 6 chiffres, aucune base distante a proteger.
public class PinHasher {

    public static String hash(String rawPin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(rawPin.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format(Locale.US, "%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            throw new RuntimeException("Erreur de hachage du PIN", e);
        }
    }

    public static boolean matches(String rawPin, String storedHash) {
        return hash(rawPin).equals(storedHash);
    }
}
