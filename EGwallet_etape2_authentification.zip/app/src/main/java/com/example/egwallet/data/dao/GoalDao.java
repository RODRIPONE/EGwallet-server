package com.example.egwallet.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.egwallet.data.entity.Goal;

import java.util.List;

@Dao
public interface GoalDao {

    @Insert
    long insert(Goal goal);

    @Update
    void update(Goal goal);

    @Delete
    void delete(Goal goal);

    @Query("SELECT * FROM goals ORDER BY deadline ASC")
    LiveData<List<Goal>> getAll();

    @Query("SELECT * FROM goals WHERE id = :id")
    LiveData<Goal> getById(long id);

    @Query("SELECT COUNT(*) FROM goals")
    int countSync();

    // Somme de l'epargne deja accumulee sur tous les objectifs (carte "Epargne" du Home)
    @Query("SELECT IFNULL(SUM(currentAmount), 0) FROM goals")
    LiveData<Double> getTotalCurrentAmount();
}
